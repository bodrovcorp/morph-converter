// Morph — пункт «Конвертировать в…» в новом контекстном меню Проводника Windows 11.
//
// Windows 11 показывает в новом меню только команды IExplorerCommand из пакетов с «идентичностью»
// (MSIX / sparse package). Эта DLL регистрируется через AppxManifest.xml (com:SurrogateServer)
// и при выборе пункта запускает Morph.exe --menu <все выделенные файлы>.
//
// Сборка: см. build-modern-menu.ps1 (MSVC, C++17, WRL — входит в Windows SDK).

#include <windows.h>
#include <shobjidl_core.h>
#include <shlwapi.h>
#include <wrl/module.h>
#include <wrl/implements.h>
#include <wrl/client.h>
#include <string>
#include <vector>

#pragma comment(lib, "shlwapi.lib")
#pragma comment(lib, "runtimeobject.lib")

using namespace Microsoft::WRL;

static HMODULE g_module = nullptr;

// Папка, где лежит эта DLL, — там же Morph.exe (внешнее расположение sparse-пакета)
static std::wstring ModuleDir() {
    wchar_t buf[MAX_PATH * 4] = {};
    GetModuleFileNameW(g_module, buf, ARRAYSIZE(buf));
    PathRemoveFileSpecW(buf);
    return buf;
}

static std::wstring Quote(const std::wstring& s) {
    std::wstring r = L"\"";
    for (wchar_t c : s) {
        if (c == L'"') r += L'\\';
        r += c;
    }
    // завершающий обратный слэш перед кавычкой нужно удвоить (C:\ → "C:\\")
    if (!s.empty() && s.back() == L'\\') r += L'\\';
    r += L'"';
    return r;
}

class __declspec(uuid("6E2F2B7A-3D44-4E8C-9C1B-7A5D0F4C2B91")) MorphCommand final
    : public RuntimeClass<RuntimeClassFlags<ClassicCom>, IExplorerCommand, IObjectWithSite> {
public:
    // IExplorerCommand
    IFACEMETHODIMP GetTitle(IShellItemArray*, LPWSTR* name) override {
        return SHStrDupW(L"Конвертировать в…", name);
    }
    IFACEMETHODIMP GetIcon(IShellItemArray*, LPWSTR* icon) override {
        std::wstring p = ModuleDir() + L"\\Morph.exe,0";
        return SHStrDupW(p.c_str(), icon);
    }
    IFACEMETHODIMP GetToolTip(IShellItemArray*, LPWSTR* tip) override {
        *tip = nullptr;
        return E_NOTIMPL;
    }
    IFACEMETHODIMP GetCanonicalName(GUID* guid) override {
        *guid = __uuidof(MorphCommand);
        return S_OK;
    }
    IFACEMETHODIMP GetState(IShellItemArray*, BOOL, EXPCMDSTATE* state) override {
        *state = ECS_ENABLED;
        return S_OK;
    }
    IFACEMETHODIMP GetFlags(EXPCMDFLAGS* flags) override {
        *flags = ECF_DEFAULT;
        return S_OK;
    }
    IFACEMETHODIMP EnumSubCommands(IEnumExplorerCommand** e) override {
        *e = nullptr;
        return E_NOTIMPL;
    }
    IFACEMETHODIMP Invoke(IShellItemArray* items, IBindCtx*) override {
        if (!items) return S_OK;
        DWORD count = 0;
        if (FAILED(items->GetCount(&count))) return S_OK;
        std::wstring cmd = Quote(ModuleDir() + L"\\Morph.exe") + L" --menu";
        for (DWORD i = 0; i < count; i++) {
            ComPtr<IShellItem> item;
            if (FAILED(items->GetItemAt(i, &item))) continue;
            LPWSTR path = nullptr;
            if (SUCCEEDED(item->GetDisplayName(SIGDN_FILESYSPATH, &path)) && path) {
                cmd += L" " + Quote(path);
                CoTaskMemFree(path);
            }
        }
        // Ограничение командной строки Windows — 32 767 символов; для огромных выделений
        // Morph всё равно покажет меню (лишние пути отбрасываются с конца).
        if (cmd.size() > 32000) cmd.resize(cmd.rfind(L" \"", 32000));
        STARTUPINFOW si{sizeof(si)};
        PROCESS_INFORMATION pi{};
        std::vector<wchar_t> buf(cmd.begin(), cmd.end());
        buf.push_back(0);
        if (CreateProcessW(nullptr, buf.data(), nullptr, nullptr, FALSE, 0, nullptr, nullptr, &si, &pi)) {
            AllowSetForegroundWindow(pi.dwProcessId);
            CloseHandle(pi.hThread);
            CloseHandle(pi.hProcess);
        }
        return S_OK;
    }

    // IObjectWithSite
    IFACEMETHODIMP SetSite(IUnknown* site) override {
        m_site = site;
        return S_OK;
    }
    IFACEMETHODIMP GetSite(REFIID riid, void** out) override {
        return m_site.CopyTo(riid, out);
    }

private:
    ComPtr<IUnknown> m_site;
};

CoCreatableClass(MorphCommand)
CoCreatableClassWrlCreatorMapInclude(MorphCommand)

STDAPI DllGetActivationFactory(HSTRING id, IActivationFactory** factory) {
    return Module<ModuleType::InProc>::GetModule().GetActivationFactory(id, factory);
}
STDAPI DllCanUnloadNow() {
    return Module<InProc>::GetModule().GetObjectCount() == 0 ? S_OK : S_FALSE;
}
STDAPI DllGetClassObject(REFCLSID rclsid, REFIID riid, LPVOID* ppv) {
    return Module<InProc>::GetModule().GetClassObject(rclsid, riid, ppv);
}

BOOL APIENTRY DllMain(HMODULE module, DWORD reason, LPVOID) {
    if (reason == DLL_PROCESS_ATTACH) {
        g_module = module;
        DisableThreadLibraryCalls(module);
    }
    return TRUE;
}
