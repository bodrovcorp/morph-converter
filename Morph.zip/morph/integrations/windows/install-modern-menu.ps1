# Включает пункт «Конвертировать в…» в новом контекстном меню Windows 11.
# Запускается из Morph (Настройки → Интеграция) с правами администратора — они нужны только
# для того, чтобы добавить самоподписанный сертификат Morph в «Доверенные лица» компьютера.
param([Parameter(Mandatory = $true)][string]$InstallDir)

$ErrorActionPreference = 'Stop'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$dist = Join-Path $here 'dist'
$msix = Join-Path $dist 'MorphContextMenu.msix'
$cer = Join-Path $dist 'Morph.cer'
if (-not (Test-Path $msix)) { throw "Нет $msix — пакет собирается в CI (build-modern-menu.ps1)" }

# DLL обработчика должна лежать рядом с Morph.exe (внешнее расположение пакета)
Copy-Item (Join-Path $dist 'MorphContextMenu.dll') $InstallDir -Force

Import-Certificate -FilePath $cer -CertStoreLocation 'Cert:\LocalMachine\TrustedPeople' | Out-Null
Get-AppxPackage -Name MorphContextMenu | Remove-AppxPackage -ErrorAction SilentlyContinue
Add-AppxPackage -Path $msix -ExternalLocation $InstallDir
Write-Host 'Готово. Если пункт не появился — перезапустите Проводник (Диспетчер задач → Проводник → Перезапустить).'
