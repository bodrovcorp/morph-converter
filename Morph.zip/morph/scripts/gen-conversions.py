#!/usr/bin/env python3
"""Генерирует docs/CONVERSIONS.md — таблицу «из чего → во что» прямо из реестра ядра (morph-cli sample-offers)."""
import json, os, subprocess, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CLI = os.path.join(ROOT, "core", "target", "debug", "morph-cli")
KINDS = [("image", "Изображения"), ("video", "Видео"), ("audio", "Аудио"), ("document", "Документы"),
         ("spreadsheet", "Таблицы и данные"), ("presentation", "Презентации"), ("ebook", "Электронные книги"),
         ("archive", "Архивы"), ("folder", "Папки"), ("other", "Любой другой файл")]
# формат → (тип, расширения)
FORMATS = json.loads(subprocess.check_output([sys.executable, "-c", """
import re,json
src=open('%s/core/src/formats.rs',encoding='utf-8').read()
out=[]
for m in re.finditer(r'f!\\("([^"]+)", \\[([^\\]]+)\\], (\\w+), "([^"]+)"', src):
    out.append([m.group(1), [x.strip().strip('"') for x in m.group(2).split(',')], m.group(3).lower(), m.group(4)])
print(json.dumps(out))
""" % ROOT]))
ids = [f[0] for f in FORMATS]
offers = json.loads(subprocess.check_output([CLI, "sample-offers", *ids]))
ENGINE = {"image": "ImageMagick · sips · FFmpeg", "video": "FFmpeg", "audio": "FFmpeg", "document": "LibreOffice · Pandoc",
          "pdf": "Poppler · qpdf · LibreOffice", "sheet": "встроено · LibreOffice", "slides": "LibreOffice · Poppler",
          "ebook": "Pandoc · Calibre", "archive": "bsdtar · 7-Zip"}
SPECIAL = {"png_pages": "PNG (страницы)", "jpg_pages": "JPG (страницы)", "png_slides": "PNG (слайды)", "jpg_slides": "JPG (слайды)",
           "unpack": "распаковать", "mp4_small": "сжатое MP4", "pdf_compress": "сжатый PDF", "pdf_split": "PDF по страницам"}
ARCH = {"zip", "7z", "targz"}

def label(o):
    if o["id"] in SPECIAL:
        return SPECIAL[o["id"]]
    t = o["title"].replace("-архив", "")
    return t

pairs = 0
lines = ["# Поддерживаемые конвертации", "",
         "Таблица собрана автоматически из реестра ядра (`python3 scripts/gen-conversions.py`). **Жирным** выделены цели, которые меню показывает в «Популярных», остальные лежат в «Ещё».", "",
         "Кроме того, **любой файл или папку можно упаковать в ZIP, 7Z или TAR.GZ**, а при выделении нескольких файлов доступны:",
         "- **Объединить** — несколько PDF в один;",
         "- **Один PDF** — несколько изображений страницами одного PDF;",
         "- **ZIP / 7Z / TAR.GZ из всех** — один архив из выделенного.", ""]
for kind, title in KINDS:
    rows = [f for f in FORMATS if f[2] == kind]
    if not rows:
        continue
    lines += [f"## {title}", "", "| Из | Во что | Движок |", "|---|---|---|"]
    for fid, exts, _, ftitle in rows:
        os_ = offers.get(fid, [])
        conv = sorted({o["converter"] for o in os_ if o["id"] not in ARCH})
        main = [o for o in os_ if o["id"] not in ARCH or kind in ("archive", "folder", "other")]
        pairs += len(os_)
        if not main:
            continue
        cells = ", ".join(("**%s**" % label(o)) if o["popular"] else label(o) for o in main)
        eng = " · ".join(dict.fromkeys(" · ".join(ENGINE.get(c, c) for c in conv).split(" · "))) or "bsdtar · 7-Zip"
        ext = ", ".join("." + e for e in exts if e not in ("*", "folder")) or "—"
        lines.append(f"| {ftitle} ({ext}) | {cells} | {eng} |")
    lines.append("")
lines += [f"Итого: **{len(FORMATS) - 2} входных форматов** и **{pairs} пар «из → в»** (вместе с упаковкой в архивы).", "",
          "Пометки о движках: «встроено» — работает без внешних программ (CSV/JSON/TSV). LibreOffice и Pandoc ставятся по кнопке, когда понадобятся. Calibre нужен только для MOBI/AZW3."]
open(os.path.join(ROOT, "docs", "CONVERSIONS.md"), "w", encoding="utf-8").write("\n".join(lines) + "\n")
print(f"docs/CONVERSIONS.md: {pairs} пар")
