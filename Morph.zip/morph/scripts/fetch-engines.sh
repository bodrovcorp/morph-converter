#!/usr/bin/env bash
# Собирает встроенные движки для macOS в app/engines/ (их упакует .app/.dmg).
#   bash scripts/fetch-engines.sh
#
# Берём сборки Homebrew и делаем их переносимыми через dylibbundler: все зависимые .dylib
# копируются в app/engines/lib, пути переписываются на @executable_path/../lib.
# Запускайте на той архитектуре, для которой собираете (arm64 — Apple Silicon, x86_64 — Intel).
#
# Без ImageMagick приложение всё равно работает с фото: JPG/PNG/HEIC/TIFF/GIF/BMP/RAW — через
# встроенный в macOS sips, WEBP/AVIF — через FFmpeg. ImageMagick добавляет SVG, ICO, PSD, TGA.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
ENG="$ROOT/app/engines"
BIN="$ENG/bin"
LIB="$ENG/lib"
rm -rf "$ENG" && mkdir -p "$BIN" "$LIB"

command -v brew >/dev/null || { echo "Нужен Homebrew: https://brew.sh"; exit 1; }
brew install ffmpeg qpdf poppler dylibbundler ${WITH_MAGICK:+imagemagick}

bundle() { # bundle <путь к бинарнику>
  local src="$1" name
  name="$(basename "$src")"
  cp -L "$src" "$BIN/$name"
  chmod u+w "$BIN/$name"
  dylibbundler -of -b -x "$BIN/$name" -d "$LIB" -p "@executable_path/../lib/" >/dev/null
}

PREFIX="$(brew --prefix)"
for b in ffmpeg ffprobe qpdf pdftoppm pdftotext; do
  bundle "$PREFIX/bin/$b"
done
if [ -n "${WITH_MAGICK:-}" ]; then
  # ImageMagick грузит кодеки модулями — копируем их и конфигурацию рядом
  bundle "$PREFIX/bin/magick"
  MAGICK_LIB="$(dirname "$(readlink -f "$PREFIX/bin/magick")")/../lib"
  cp -R "$MAGICK_LIB"/ImageMagick-7* "$LIB/" 2>/dev/null || true
  cp -R "$(dirname "$(readlink -f "$PREFIX/bin/magick")")/../etc/ImageMagick-7" "$ENG/magick-config" 2>/dev/null || true
fi

# ad-hoc подпись: без неё на Apple Silicon бинарники не запустятся
codesign --force -s - "$BIN"/* "$LIB"/*.dylib 2>/dev/null || true
du -sh "$ENG"
echo "Готово. Проверка: $BIN/ffmpeg -version | head -1"
"$BIN/ffmpeg" -version | head -1
