//! Настройки приложения: JSON-файл в папке конфигурации пользователя.

use serde::{Deserialize, Serialize};
use std::path::{Path, PathBuf};

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase", default)]
pub struct Quality {
    pub image: u8,
    pub video: String,
    pub audio_bitrate: u32,
    pub strip_metadata: bool,
    pub csv_bom: bool,
    pub dpi: u32,
}

impl Default for Quality {
    fn default() -> Self {
        Quality { image: 85, video: "balanced".into(), audio_bitrate: 192, strip_metadata: false, csv_bom: true, dpi: 150 }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase", default)]
pub struct Appearance {
    /// "glass" | "minimal"
    pub style: String,
    /// "system" | "light" | "dark"
    pub theme: String,
    /// 0…100: насколько прозрачна подложка стекла
    pub glass_transparency: u8,
    /// "soft" | "medium" | "strong"
    pub blur: String,
    pub reduce_transparency: bool,
    pub follow_system: bool,
    pub motion: bool,
}

impl Default for Appearance {
    fn default() -> Self {
        Appearance {
            style: "glass".into(),
            theme: "system".into(),
            glass_transparency: 50,
            blur: "medium".into(),
            reduce_transparency: false,
            follow_system: true,
            motion: true,
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase", default)]
pub struct Settings {
    pub autostart: bool,
    pub notify: bool,
    pub language: String,
    /// "A" | "B" | "C" | "custom"
    pub hotkey_preset: String,
    /// Акселератор Tauri, например "Control+Alt+Super+X". Пусто — без глобальной клавиши.
    pub hotkey: String,
    /// "beside" | "folder"
    pub save_mode: String,
    pub save_folder: Option<String>,
    /// "suffix" | "overwrite" | "ask"
    pub conflict: String,
    pub quality: Quality,
    pub favorites: Vec<String>,
    pub appearance: Appearance,
    pub progress_delay_ms: u64,
    /// Пути к движкам, заданные вручную: id → путь
    pub engine_paths: std::collections::BTreeMap<String, String>,
}

pub fn default_hotkey() -> &'static str {
    if cfg!(target_os = "macos") {
        "Control+Alt+Super+X"
    } else {
        "Super+Shift+X"
    }
}

impl Default for Settings {
    fn default() -> Self {
        Settings {
            autostart: true,
            notify: true,
            language: "ru".into(),
            hotkey_preset: "A".into(),
            hotkey: default_hotkey().into(),
            save_mode: "beside".into(),
            save_folder: None,
            conflict: "suffix".into(),
            quality: Quality::default(),
            favorites: vec!["jpg".into(), "pdf".into(), "mp4".into(), "mp3".into()],
            appearance: Appearance::default(),
            progress_delay_ms: 1500,
            engine_paths: Default::default(),
        }
    }
}

pub fn path(config_dir: &Path) -> PathBuf {
    config_dir.join("settings.json")
}

/// Загружает настройки. Второе значение — true, если это первый запуск.
pub fn load(config_dir: &Path) -> (Settings, bool) {
    match std::fs::read_to_string(path(config_dir)) {
        Ok(s) => (serde_json::from_str(&s).unwrap_or_default(), false),
        Err(_) => (Settings::default(), true),
    }
}

pub fn save(config_dir: &Path, s: &Settings) -> std::io::Result<()> {
    std::fs::create_dir_all(config_dir)?;
    let tmp = config_dir.join("settings.json.tmp");
    std::fs::write(&tmp, serde_json::to_vec_pretty(s).unwrap_or_default())?;
    std::fs::rename(tmp, path(config_dir))
}
