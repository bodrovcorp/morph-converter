//! Morph — оболочка Tauri: трей/строка меню, глобальная клавиша, окна, команды для интерфейса.

mod platform;
mod selection;
mod settings;

use morph_core::engines::{EngineConfig, EngineId, Engines};
use morph_core::naming::Conflict;
use morph_core::options::Options;
use morph_core::queue::{self, Dest, JobInfo, JobRequest, Queue, Status};
use morph_core::text::json as cj;
use serde::{Deserialize, Serialize};
use serde_json::{json, Value};
use settings::Settings;
use std::collections::HashMap;
use std::path::{Path, PathBuf};
use std::sync::{Arc, Mutex};
use std::time::{Duration, Instant};
use tauri::menu::{Menu, MenuItem, PredefinedMenuItem};
use tauri::tray::TrayIconBuilder;
use tauri::window::{Effect, EffectState, EffectsBuilder};
use tauri::{AppHandle, Emitter, LogicalSize, Manager, PhysicalPosition, RunEvent, State, WebviewUrl, WebviewWindow, WebviewWindowBuilder, WindowEvent};
use tauri_plugin_autostart::{MacosLauncher, ManagerExt};
use tauri_plugin_dialog::DialogExt;
use tauri_plugin_global_shortcut::{GlobalShortcutExt, ShortcutState};
use tauri_plugin_notification::NotificationExt;
use tauri_plugin_opener::OpenerExt;

const MENU_W: f64 = 340.0;
const PROGRESS_W: f64 = 392.0;

#[derive(Debug, Clone, Serialize, Deserialize)]
struct HistoryItem {
    name: String,
    src: String,
    dst: String,
    path: String,
    time: u64,
}

struct BatchTrack {
    total: usize,
    finished: usize,
    failed: usize,
    started: Instant,
    first_output: Option<String>,
}

pub struct AppState {
    queue: Queue,
    settings: Mutex<Settings>,
    config_dir: PathBuf,
    history: Mutex<Vec<HistoryItem>>,
    batches: Mutex<HashMap<u64, BatchTrack>>,
    /// Пути из контекстного меню Проводника приходят по одному процессу на файл — собираем их
    pending: Mutex<(Vec<PathBuf>, Option<Instant>)>,
    initial_menu: Mutex<Option<Value>>,
    picking: Mutex<bool>,
    quitting: Mutex<bool>,
}

fn to_value(j: &cj::Json) -> Value {
    serde_json::from_str(&cj::to_string(j)).unwrap_or(Value::Null)
}
fn from_value(v: &Value) -> cj::Json {
    cj::parse(&v.to_string()).unwrap_or(cj::Json::Null)
}

fn engine_config(app: &AppHandle, s: &Settings) -> EngineConfig {
    let mut dirs = Vec::new();
    if let Ok(res) = app.path().resource_dir() {
        dirs.push(res.join("engines").join("bin"));
        dirs.push(res.join("engines"));
    }
    if let Ok(data) = app.path().app_data_dir() {
        dirs.push(data.join("engines"));
    }
    if let Ok(exe) = std::env::current_exe() {
        if let Some(d) = exe.parent() {
            dirs.push(d.to_path_buf());
        }
    }
    let overrides = s.engine_paths.iter().filter_map(|(k, v)| EngineId::from_id(k).map(|id| (id, PathBuf::from(v)))).collect();
    EngineConfig { bundled_dirs: dirs, overrides, no_path: false }
}

fn now_ms() -> u64 {
    std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).map(|d| d.as_millis() as u64).unwrap_or(0)
}

// ---------------------------------------------------------------------------
// Окна

fn make_windows(app: &AppHandle) -> tauri::Result<()> {
    let menu = WebviewWindowBuilder::new(app, "menu", WebviewUrl::App("menu.html".into()))
        .title("Конвертировать в…")
        .inner_size(MENU_W, 520.0)
        .resizable(false)
        .decorations(false)
        .transparent(true)
        .shadow(true)
        .always_on_top(true)
        .skip_taskbar(true)
        .visible(false)
        .build()?;
    let h = app.clone();
    menu.on_window_event(move |e| {
        if let WindowEvent::Focused(false) = e {
            // клик мимо меню или переключение на другое окно — закрываем (кроме открытого диалога выбора файлов)
            if !*h.state::<AppState>().picking.lock().unwrap() {
                if let Some(w) = h.get_webview_window("menu") {
                    let _ = w.hide();
                }
            }
        }
    });
    WebviewWindowBuilder::new(app, "progress", WebviewUrl::App("progress.html".into()))
        .title("Morph — конвертация")
        .inner_size(PROGRESS_W, 420.0)
        .resizable(false)
        .decorations(false)
        .transparent(true)
        .shadow(true)
        .always_on_top(true)
        .skip_taskbar(true)
        .visible(false)
        .build()?;
    apply_effects(app);
    Ok(())
}

/// Нативное размытие под стеклом (NSVisualEffectView / Mica-Acrylic) или его отсутствие
fn apply_effects(app: &AppHandle) {
    let s = app.state::<AppState>().settings.lock().unwrap().clone();
    let sys = platform::system_appearance();
    let sys_reduce = s.appearance.follow_system && sys.get("reduceTransparency").and_then(Value::as_bool).unwrap_or(false);
    let glass = s.appearance.style == "glass" && !s.appearance.reduce_transparency && !sys_reduce;
    for label in ["menu", "progress", "settings"] {
        let Some(w) = app.get_webview_window(label) else { continue };
        if glass {
            let effect = if cfg!(target_os = "macos") {
                match s.appearance.blur.as_str() {
                    "soft" => Effect::Popover,
                    "strong" => Effect::UnderWindowBackground,
                    _ => Effect::Menu,
                }
            } else {
                match s.appearance.blur.as_str() {
                    "soft" => Effect::Mica,
                    _ => Effect::Acrylic,
                }
            };
            let radius = if label == "settings" { 0.0 } else { 22.0 };
            let _ = w.set_effects(EffectsBuilder::new().effect(effect).state(EffectState::Active).radius(radius).build());
        } else {
            let _ = w.set_effects(None::<tauri::utils::config::WindowEffectsConfig>);
        }
    }
}

fn place_near_cursor(app: &AppHandle, w: &WebviewWindow, width: f64, height: f64) {
    let Ok(cur) = app.cursor_position() else { return };
    let mon = app.monitor_from_point(cur.x, cur.y).ok().flatten().or_else(|| app.primary_monitor().ok().flatten());
    let (mx, my, mw, mh, scale) = match &mon {
        Some(m) => (m.position().x as f64, m.position().y as f64, m.size().width as f64, m.size().height as f64, m.scale_factor()),
        None => (0.0, 0.0, 1920.0, 1080.0, 1.0),
    };
    let (pw, ph) = (width * scale, height * scale);
    let off = 6.0 * scale;
    let mut x = cur.x + off;
    let mut y = cur.y + off;
    // не вылезаем за край экрана: при нехватке места — по другую сторону от курсора
    if x + pw > mx + mw - 8.0 {
        x = (cur.x - pw - off).max(mx + 8.0);
    }
    if y + ph > my + mh - 48.0 {
        y = (cur.y - ph - off).max(my + 8.0);
    }
    let _ = w.set_position(PhysicalPosition::new(x.round() as i32, y.round() as i32));
}

fn show_menu(app: &AppHandle, paths: Vec<PathBuf>) {
    let state = app.state::<AppState>();
    let data = to_value(&morph_core::menu_json(&paths, &state.queue.engines()));
    *state.initial_menu.lock().unwrap() = Some(data.clone());
    let Some(w) = app.get_webview_window("menu") else { return };
    place_near_cursor(app, &w, MENU_W, 520.0);
    let _ = w.emit("menu:open", data);
    let _ = w.show();
    let _ = w.set_focus();
}

fn trigger_menu(app: &AppHandle) {
    if let Some(w) = app.get_webview_window("menu") {
        if w.is_visible().unwrap_or(false) {
            let _ = w.hide();
            return;
        }
    }
    let paths = selection::selected_files();
    show_menu(app, paths);
}

fn show_progress(app: &AppHandle) {
    let Some(w) = app.get_webview_window("progress") else { return };
    if w.is_visible().unwrap_or(false) {
        return;
    }
    if let Ok(Some(m)) = app.primary_monitor() {
        let s = m.scale_factor();
        let x = m.position().x as f64 + m.size().width as f64 - (PROGRESS_W + 24.0) * s;
        let y = m.position().y as f64 + m.size().height as f64 - (420.0 + 72.0) * s;
        let _ = w.set_position(PhysicalPosition::new(x as i32, y as i32));
    }
    let _ = w.show();
}

fn open_settings_window(app: &AppHandle, tab: Option<String>, highlight: Option<String>) {
    if let Some(w) = app.get_webview_window("settings") {
        let _ = w.emit("settings:open-tab", json!({ "tab": tab, "highlight": highlight }));
        let _ = w.show();
        let _ = w.unminimize();
        let _ = w.set_focus();
        return;
    }
    let mut url = String::from("settings.html");
    if let Some(t) = &tab {
        url.push_str(&format!("?tab={t}&highlight={}", highlight.clone().unwrap_or_default()));
    }
    #[allow(unused_mut)]
    let mut b = WebviewWindowBuilder::new(app, "settings", WebviewUrl::App(url.into()))
        .title("Morph — Настройки")
        .inner_size(860.0, 600.0)
        .min_inner_size(720.0, 480.0)
        .transparent(true)
        .center();
    #[cfg(target_os = "macos")]
    {
        b = b.title_bar_style(tauri::TitleBarStyle::Overlay).hidden_title(true);
    }
    if b.build().is_ok() {
        apply_effects(app);
    }
}

// ---------------------------------------------------------------------------
// Горячая клавиша

fn register_hotkey(app: &AppHandle, accel: &str) -> Result<(), String> {
    let gs = app.global_shortcut();
    let _ = gs.unregister_all();
    if accel.is_empty() {
        return Ok(());
    }
    gs.register(accel).map_err(|e| format!("сочетание занято другой программой или не распознано ({e})"))
}

// ---------------------------------------------------------------------------
// Очередь: события → интерфейс, история, уведомления

fn on_job(app: &AppHandle, j: &JobInfo) {
    let _ = app.emit("job", to_value(&j.to_json()));
    if !j.status.finished() {
        return;
    }
    let state = app.state::<AppState>();
    if j.status == Status::Done {
        if let Some(out) = j.outputs.first() {
            let mut h = state.history.lock().unwrap();
            h.insert(
                0,
                HistoryItem {
                    name: out.file_name().map(|s| s.to_string_lossy().to_string()).unwrap_or_default(),
                    src: j.src_title.clone(),
                    dst: j.target_title.clone(),
                    path: out.to_string_lossy().to_string(),
                    time: now_ms(),
                },
            );
            h.truncate(200);
            let _ = std::fs::write(state.config_dir.join("history.json"), serde_json::to_vec(&*h).unwrap_or_default());
        }
    }
    // Итог пакета — одно уведомление на всё выделение
    let mut batches = state.batches.lock().unwrap();
    if let Some(b) = batches.get_mut(&j.batch) {
        b.finished += 1;
        if j.status == Status::Failed {
            b.failed += 1;
        }
        if b.first_output.is_none() {
            b.first_output = j.outputs.first().map(|p| p.file_name().unwrap_or_default().to_string_lossy().to_string());
        }
        if b.finished >= b.total {
            let s = state.settings.lock().unwrap().clone();
            let long = b.started.elapsed() > Duration::from_secs(10);
            if s.notify && (long || b.failed > 0) && j.status != Status::Cancelled {
                let title = if b.failed == 0 {
                    if b.total == 1 {
                        format!("Готово: {}", b.first_output.clone().unwrap_or_default())
                    } else {
                        format!("Готово: {} файлов", b.total)
                    }
                } else {
                    format!("Готово с ошибками: {} из {}", b.total - b.failed, b.total)
                };
                let body = if b.failed == 0 { "Нажмите, чтобы открыть список задач".to_string() } else { j.error.clone().unwrap_or_default() };
                let _ = app.notification().builder().title(title).body(body).show();
            }
            batches.remove(&j.batch);
        }
    }
}

// ---------------------------------------------------------------------------
// Команды для интерфейса

#[tauri::command]
fn get_settings(state: State<'_, AppState>) -> Settings {
    state.settings.lock().unwrap().clone()
}

#[tauri::command]
fn set_settings(app: AppHandle, state: State<'_, AppState>, settings: Settings) -> Value {
    let old = state.settings.lock().unwrap().clone();
    let mut hotkey_error = None;
    if old.hotkey != settings.hotkey || old.hotkey_preset != settings.hotkey_preset {
        let accel = if settings.hotkey_preset == "C" { "" } else { settings.hotkey.as_str() };
        if let Err(e) = register_hotkey(&app, accel) {
            hotkey_error = Some(e);
            let _ = register_hotkey(&app, &old.hotkey);
        }
    }
    if old.autostart != settings.autostart {
        let al = app.autolaunch();
        let _ = if settings.autostart { al.enable() } else { al.disable() };
    }
    let appearance_changed = serde_json::to_string(&old.appearance).ok() != serde_json::to_string(&settings.appearance).ok();
    let engines_changed = old.engine_paths != settings.engine_paths;
    let mut s = settings;
    if hotkey_error.is_some() {
        s.hotkey = old.hotkey.clone();
        s.hotkey_preset = old.hotkey_preset.clone();
    }
    *state.settings.lock().unwrap() = s.clone();
    let _ = settings::save(&state.config_dir, &s);
    let _ = app.emit("settings:changed", &s);
    if appearance_changed {
        apply_effects(&app);
    }
    if engines_changed {
        rediscover(&app);
    }
    json!({ "ok": hotkey_error.is_none(), "hotkeyError": hotkey_error })
}

#[tauri::command]
fn system_appearance() -> Value {
    platform::system_appearance()
}

#[tauri::command]
fn menu_data(state: State<'_, AppState>, paths: Vec<String>) -> Value {
    let p: Vec<PathBuf> = paths.into_iter().map(PathBuf::from).collect();
    to_value(&morph_core::menu_json(&p, &state.queue.engines()))
}

#[tauri::command]
fn initial_menu(state: State<'_, AppState>) -> Value {
    state.initial_menu.lock().unwrap().clone().unwrap_or_else(|| json!({ "files": [], "unknown": [], "offers": [] }))
}

#[tauri::command]
async fn pick_files(app: AppHandle) -> Vec<String> {
    let st = app.state::<AppState>();
    *st.picking.lock().unwrap() = true;
    let picked = app.dialog().file().set_title("Выберите файлы для конвертации").blocking_pick_files();
    *st.picking.lock().unwrap() = false;
    if let Some(w) = app.get_webview_window("menu") {
        let _ = w.show();
        let _ = w.set_focus();
    }
    picked.unwrap_or_default().into_iter().filter_map(|f| f.into_path().ok()).map(|p| p.to_string_lossy().to_string()).collect()
}

#[tauri::command]
fn convert(app: AppHandle, state: State<'_, AppState>, paths: Vec<String>, target: String, options: Value, conflict: Option<String>) -> Value {
    let s = state.settings.lock().unwrap().clone();
    let inputs: Vec<PathBuf> = paths.iter().map(PathBuf::from).collect();
    let dest = match (&s.save_mode[..], &s.save_folder) {
        ("folder", Some(f)) if Path::new(f).is_dir() => Dest::Folder(PathBuf::from(f)),
        _ => Dest::Beside,
    };
    let policy = conflict.clone().unwrap_or_else(|| s.conflict.clone());
    if policy == "ask" && !queue::is_combine(&target) {
        for p in &inputs {
            if let Some(out) = state.queue.predicted_output(p, &target, &dest) {
                if out.exists() {
                    return json!({ "conflict": { "name": out.file_name().map(|n| n.to_string_lossy().to_string()) } });
                }
            }
        }
    }
    let conflict = if policy == "overwrite" { Conflict::Overwrite } else { Conflict::Suffix };
    let options = Options::from_json(&from_value(&options));
    let count = if queue::is_combine(&target) { 1 } else { inputs.len() };
    let batch = state.queue.submit(JobRequest { inputs, target, options, dest, conflict });
    state.batches.lock().unwrap().insert(batch, BatchTrack { total: count, finished: 0, failed: 0, started: Instant::now(), first_output: None });
    // Панель прогресса — только если задача не уложилась в 1,5 с
    let delay = s.progress_delay_ms;
    let h = app.clone();
    std::thread::spawn(move || {
        std::thread::sleep(Duration::from_millis(delay));
        let st = h.state::<AppState>();
        let busy = st.queue.snapshot().iter().any(|j| j.batch == batch && !j.status.finished());
        if busy {
            let h2 = h.clone();
            let _ = h.run_on_main_thread(move || show_progress(&h2));
        }
    });
    json!({ "batch": batch })
}

#[tauri::command]
fn cancel(state: State<'_, AppState>, id: u64) {
    state.queue.cancel(id);
}

#[tauri::command]
fn cancel_all(state: State<'_, AppState>) {
    state.queue.cancel_all();
}

#[tauri::command]
fn retry(state: State<'_, AppState>, id: u64) {
    let Some(j) = state.queue.snapshot().into_iter().find(|j| j.id == id) else { return };
    let s = state.settings.lock().unwrap().clone();
    let opts = json!({ "quality": s.quality.image, "videoQuality": s.quality.video, "audioBitrate": s.quality.audio_bitrate, "stripMetadata": s.quality.strip_metadata, "csvBom": s.quality.csv_bom, "dpi": s.quality.dpi });
    let batch = state.queue.submit(JobRequest { inputs: j.inputs, target: j.target, options: Options::from_json(&from_value(&opts)), dest: Dest::Beside, conflict: Conflict::Suffix });
    state.batches.lock().unwrap().insert(batch, BatchTrack { total: 1, finished: 0, failed: 0, started: Instant::now(), first_output: None });
}

#[tauri::command]
fn clear_finished(app: AppHandle, state: State<'_, AppState>) {
    state.queue.clear_finished();
    let list: Vec<Value> = state.queue.snapshot().iter().map(|j| to_value(&j.to_json())).collect();
    let _ = app.emit("jobs:reset", list);
}

#[tauri::command]
fn jobs(state: State<'_, AppState>) -> Vec<Value> {
    state.queue.snapshot().iter().map(|j| to_value(&j.to_json())).collect()
}

#[tauri::command]
fn reveal(app: AppHandle, path: String) {
    let _ = app.opener().reveal_item_in_dir(PathBuf::from(path));
}

#[tauri::command]
fn hide_menu(app: AppHandle) {
    if let Some(w) = app.get_webview_window("menu") {
        let _ = w.hide();
    }
}

#[tauri::command]
fn resize_menu(app: AppHandle, height: f64) {
    if let Some(w) = app.get_webview_window("menu") {
        let h = height.clamp(160.0, 640.0);
        let _ = w.set_size(LogicalSize::new(MENU_W, h));
        if let (Ok(pos), Ok(scale)) = (w.outer_position(), w.scale_factor()) {
            // после изменения высоты проверяем, что меню не ушло за нижний край
            if let Ok(Some(m)) = w.current_monitor() {
                let bottom = m.position().y as f64 + m.size().height as f64 - 48.0;
                let ph = h * scale;
                if pos.y as f64 + ph > bottom {
                    let _ = w.set_position(PhysicalPosition::new(pos.x, (bottom - ph).max(m.position().y as f64) as i32));
                }
            }
        }
    }
}

#[tauri::command]
fn hide_progress(app: AppHandle) {
    if let Some(w) = app.get_webview_window("progress") {
        let _ = w.hide();
    }
}

#[tauri::command]
fn open_settings(app: AppHandle, tab: Option<String>, highlight: Option<String>) {
    open_settings_window(&app, tab, highlight);
}

#[tauri::command]
fn engines(state: State<'_, AppState>) -> Value {
    to_value(&morph_core::engines_json(&state.queue.engines()))
}

fn rediscover(app: &AppHandle) {
    let state = app.state::<AppState>();
    let s = state.settings.lock().unwrap().clone();
    let cfg = engine_config(app, &s);
    let e = Arc::new(Engines::discover(&cfg));
    state.queue.set_engines(e);
    let _ = app.emit("engines:changed", json!({}));
}

#[tauri::command]
async fn install_engine(app: AppHandle, id: String) -> Value {
    let r = tauri::async_runtime::spawn_blocking(move || platform::install_engine(&id)).await;
    let r = r.unwrap_or(platform::InstallResult { ok: false, message: "Ошибка установки".into(), url: None });
    rediscover(&app);
    json!({ "ok": r.ok, "message": r.message, "url": r.url })
}

#[tauri::command]
fn set_engine_path(app: AppHandle, state: State<'_, AppState>, id: String, path: String) -> Value {
    {
        let mut s = state.settings.lock().unwrap();
        s.engine_paths.insert(id, path);
        let _ = settings::save(&state.config_dir, &s);
    }
    rediscover(&app);
    json!({ "ok": true })
}

#[tauri::command]
async fn pick_engine_path(app: AppHandle) -> Option<String> {
    app.dialog().file().set_title("Укажите исполняемый файл компонента").blocking_pick_file().and_then(|f| f.into_path().ok()).map(|p| p.to_string_lossy().to_string())
}

#[tauri::command]
async fn pick_folder(app: AppHandle) -> Option<String> {
    app.dialog().file().set_title("Папка для результатов").blocking_pick_folder().and_then(|f| f.into_path().ok()).map(|p| p.to_string_lossy().to_string())
}

#[tauri::command]
fn history(state: State<'_, AppState>) -> Vec<HistoryItem> {
    state.history.lock().unwrap().clone()
}

#[tauri::command]
fn clear_history(state: State<'_, AppState>) {
    state.history.lock().unwrap().clear();
    let _ = std::fs::remove_file(state.config_dir.join("history.json"));
}

#[tauri::command]
fn check_hotkey(app: AppHandle, state: State<'_, AppState>, accel: String) -> Value {
    let current = state.settings.lock().unwrap().hotkey.clone();
    if accel == current {
        return json!({ "ok": true });
    }
    // Пробуем зарегистрировать: если другая программа уже держит сочетание, система откажет
    let gs = app.global_shortcut();
    match gs.register(accel.as_str()) {
        Ok(()) => {
            let _ = gs.unregister(accel.as_str());
            json!({ "ok": true })
        }
        Err(e) => json!({ "ok": false, "reason": format!("занято другой программой ({e})") }),
    }
}

#[tauri::command]
fn integration_status(app: AppHandle) -> Value {
    let res = app.path().resource_dir().unwrap_or_default();
    platform::integration_status(&res)
}

#[tauri::command]
async fn install_integration(app: AppHandle, kind: String) -> Value {
    let res = app.path().resource_dir().unwrap_or_default();
    let exe = std::env::current_exe().unwrap_or_default();
    let r = tauri::async_runtime::spawn_blocking(move || platform::install_integration(&kind, &res, &exe)).await;
    match r {
        Ok(Ok(m)) => json!({ "ok": true, "message": m }),
        Ok(Err(m)) => json!({ "ok": false, "message": m }),
        Err(_) => json!({ "ok": false, "message": "Ошибка" }),
    }
}

#[tauri::command]
fn uninstall_integration(kind: String) -> Value {
    match platform::uninstall_integration(&kind) {
        Ok(m) => json!({ "ok": true, "message": m }),
        Err(m) => json!({ "ok": false, "message": m }),
    }
}

#[tauri::command]
fn open_url(app: AppHandle, url: String) {
    if url.starts_with("https://") {
        let _ = app.opener().open_url(url, None::<&str>);
    }
}

// ---------------------------------------------------------------------------
// Запуск

/// Пути после «--menu» в аргументах (из контекстного меню Finder/Проводника)
fn menu_args(argv: &[String]) -> Option<Vec<PathBuf>> {
    let i = argv.iter().position(|a| a == "--menu")?;
    Some(argv[i + 1..].iter().filter(|a| !a.starts_with("--")).map(PathBuf::from).collect())
}

/// Проводник запускает по процессу на каждый файл — собираем пути 350 мс и показываем одно меню
fn collect_and_show(app: &AppHandle, paths: Vec<PathBuf>) {
    let state = app.state::<AppState>();
    let first = {
        let mut p = state.pending.lock().unwrap();
        p.0.extend(paths);
        let first = p.1.is_none();
        p.1 = Some(Instant::now());
        first
    };
    if !first {
        return;
    }
    let h = app.clone();
    std::thread::spawn(move || loop {
        std::thread::sleep(Duration::from_millis(120));
        let st = h.state::<AppState>();
        let mut p = st.pending.lock().unwrap();
        if p.1.map(|t| t.elapsed() >= Duration::from_millis(350)).unwrap_or(true) {
            let mut paths = std::mem::take(&mut p.0);
            p.1 = None;
            drop(p);
            paths.sort();
            paths.dedup();
            let h2 = h.clone();
            let _ = h.run_on_main_thread(move || show_menu(&h2, paths));
            break;
        }
    });
}

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    let app = tauri::Builder::default()
        // Должен быть первым: второй запуск передаёт аргументы уже работающему экземпляру
        .plugin(tauri_plugin_single_instance::init(|app, argv, _cwd| {
            if let Some(paths) = menu_args(&argv) {
                collect_and_show(app, paths);
            } else {
                open_settings_window(app, None, None);
            }
        }))
        .plugin(tauri_plugin_autostart::init(MacosLauncher::LaunchAgent, Some(vec!["--hidden"])))
        .plugin(tauri_plugin_notification::init())
        .plugin(tauri_plugin_dialog::init())
        .plugin(tauri_plugin_opener::init())
        .plugin(
            tauri_plugin_global_shortcut::Builder::new()
                .with_handler(|app, _shortcut, event| {
                    if event.state() == ShortcutState::Pressed {
                        trigger_menu(app);
                    }
                })
                .build(),
        )
        .setup(|app| {
            let handle = app.handle().clone();
            let config_dir = app.path().app_config_dir().unwrap_or_else(|_| std::env::temp_dir().join("morph"));
            let (settings, first_run) = settings::load(&config_dir);
            let history: Vec<HistoryItem> = std::fs::read(config_dir.join("history.json")).ok().and_then(|b| serde_json::from_slice(&b).ok()).unwrap_or_default();
            let engines = Arc::new(Engines::discover(&engine_config(&handle, &settings)));
            let h2 = handle.clone();
            let queue = Queue::new(engines, 3, Arc::new(move |j: &JobInfo| on_job(&h2, j)));
            app.manage(AppState {
                queue,
                settings: Mutex::new(settings.clone()),
                config_dir: config_dir.clone(),
                history: Mutex::new(history),
                batches: Mutex::new(HashMap::new()),
                pending: Mutex::new((Vec::new(), None)),
                initial_menu: Mutex::new(None),
                picking: Mutex::new(false),
                quitting: Mutex::new(false),
            });

            #[cfg(target_os = "macos")]
            app.set_activation_policy(tauri::ActivationPolicy::Accessory);

            make_windows(&handle)?;
            if settings.hotkey_preset != "C" {
                if let Err(e) = register_hotkey(&handle, &settings.hotkey) {
                    eprintln!("Morph: горячая клавиша не зарегистрирована: {e}");
                }
            }
            if first_run && settings.autostart {
                let _ = handle.autolaunch().enable();
            }
            selection::warm_up();

            // Трей / строка меню
            let i_convert = MenuItem::with_id(app, "convert", "Конвертировать файлы…", true, None::<&str>)?;
            let i_jobs = MenuItem::with_id(app, "jobs", "Задачи", true, None::<&str>)?;
            let i_settings = MenuItem::with_id(app, "settings", "Настройки…", true, None::<&str>)?;
            let sep = PredefinedMenuItem::separator(app)?;
            let i_quit = MenuItem::with_id(app, "quit", "Выйти из Morph", true, None::<&str>)?;
            let menu = Menu::with_items(app, &[&i_convert, &i_jobs, &i_settings, &sep, &i_quit])?;
            let mut tray = TrayIconBuilder::with_id("main").tooltip("Morph — конвертер файлов").menu(&menu);
            // macOS: монохромный «шаблон» — система сама красит под светлую/тёмную строку меню.
            // Windows: цветная иконка приложения (чёрный шаблон потерялся бы на тёмной панели задач).
            #[cfg(target_os = "macos")]
            {
                tray = tray.icon(tauri::image::Image::from_bytes(include_bytes!("../icons/tray.png"))?).icon_as_template(true);
            }
            #[cfg(not(target_os = "macos"))]
            if let Some(icon) = app.default_window_icon() {
                tray = tray.icon(icon.clone());
            }
            tray.on_menu_event(|app, e| match e.id.as_ref() {
                "convert" => show_menu(app, Vec::new()),
                "jobs" => show_progress(app),
                "settings" => open_settings_window(app, None, None),
                "quit" => {
                    *app.state::<AppState>().quitting.lock().unwrap() = true;
                    app.state::<AppState>().queue.shutdown();
                    app.exit(0);
                }
                _ => {}
            })
            .build(app)?;

            // Запуск из контекстного меню / первый запуск
            let argv: Vec<String> = std::env::args().collect();
            if let Some(paths) = menu_args(&argv) {
                collect_and_show(&handle, paths);
            } else if first_run || !argv.iter().any(|a| a == "--hidden") {
                open_settings_window(&handle, if first_run { Some("integration".into()) } else { None }, None);
            }
            Ok(())
        })
        .invoke_handler(tauri::generate_handler![
            get_settings,
            set_settings,
            system_appearance,
            menu_data,
            initial_menu,
            pick_files,
            convert,
            cancel,
            cancel_all,
            retry,
            clear_finished,
            jobs,
            reveal,
            hide_menu,
            resize_menu,
            hide_progress,
            open_settings,
            engines,
            install_engine,
            set_engine_path,
            pick_engine_path,
            pick_folder,
            history,
            clear_history,
            check_hotkey,
            integration_status,
            install_integration,
            uninstall_integration,
            open_url
        ])
        .build(tauri::generate_context!())
        .expect("не удалось запустить Morph");

    app.run(|app, event| {
        // Закрытие окон не завершает приложение: оно живёт в трее
        if let RunEvent::ExitRequested { api, code, .. } = event {
            if code.is_none() && !*app.state::<AppState>().quitting.lock().unwrap() {
                api.prevent_exit();
            }
        }
    });
}
