//! Платформенные мелочи: системные настройки внешнего вида, установка компонентов,
//! пункты контекстного меню Finder/Проводника.

use serde_json::{json, Value};
use std::path::{Path, PathBuf};
use std::process::Command;

fn run(cmd: &str, args: &[&str]) -> Option<String> {
    let mut c = Command::new(cmd);
    c.args(args);
    #[cfg(windows)]
    {
        use std::os::windows::process::CommandExt;
        c.creation_flags(0x0800_0000);
    }
    let o = c.output().ok()?;
    if o.status.success() {
        Some(String::from_utf8_lossy(&o.stdout).trim().to_string())
    } else {
        None
    }
}

/// Системные «Уменьшить прозрачность», «Уменьшить движение», тёмная тема, контраст
pub fn system_appearance() -> Value {
    #[cfg(target_os = "macos")]
    {
        let ua = |k: &str| run("defaults", &["read", "com.apple.universalaccess", k]).map(|s| s == "1").unwrap_or(false);
        let dark = run("defaults", &["read", "-g", "AppleInterfaceStyle"]).map(|s| s == "Dark").unwrap_or(false);
        return json!({ "reduceTransparency": ua("reduceTransparency"), "reduceMotion": ua("reduceMotion"), "highContrast": ua("increaseContrast"), "dark": dark });
    }
    #[cfg(windows)]
    {
        let reg = |key: &str, val: &str| -> Option<u32> {
            let out = run("reg", &["query", key, "/v", val])?;
            let hex = out.split_whitespace().last()?;
            u32::from_str_radix(hex.trim_start_matches("0x"), 16).ok()
        };
        let p = r"HKCU\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize";
        let transparency = reg(p, "EnableTransparency").unwrap_or(1);
        let light = reg(p, "AppsUseLightTheme").unwrap_or(1);
        let anim = run("reg", &["query", r"HKCU\Control Panel\Desktop\WindowMetrics", "/v", "MinAnimate"]).map(|s| !s.trim_end().ends_with('0')).unwrap_or(true);
        return json!({ "reduceTransparency": transparency == 0, "reduceMotion": !anim, "highContrast": false, "dark": light == 0 });
    }
    #[allow(unreachable_code)]
    json!({})
}

// ---------------------------------------------------------------------------
// Установка компонентов (LibreOffice, Pandoc, Calibre, ImageMagick на macOS)

pub struct InstallResult {
    pub ok: bool,
    pub message: String,
    pub url: Option<String>,
}

fn official_url(id: &str) -> &'static str {
    match id {
        "libreoffice" => "https://www.libreoffice.org/download/download-libreoffice/",
        "pandoc" => "https://pandoc.org/installing.html",
        "calibre" => "https://calibre-ebook.com/download",
        "magick" => "https://imagemagick.org/script/download.php",
        "7zip" => "https://www.7-zip.org/download.html",
        _ => "https://github.com",
    }
}

/// Устанавливает компонент пакетным менеджером системы (winget / Homebrew). Блокирующий вызов.
pub fn install_engine(id: &str) -> InstallResult {
    #[cfg(windows)]
    {
        let pkg = match id {
            "libreoffice" => Some("TheDocumentFoundation.LibreOffice"),
            "pandoc" => Some("JohnMacFarlane.Pandoc"),
            "calibre" => Some("calibre.calibre"),
            "7zip" => Some("7zip.7zip"),
            "magick" => Some("ImageMagick.ImageMagick"),
            _ => None,
        };
        if let (Some(pkg), Some(_)) = (pkg, run("where", &["winget"])) {
            let ok = Command::new("winget")
                .args(["install", "--id", pkg, "-e", "--silent", "--accept-package-agreements", "--accept-source-agreements"])
                .status()
                .map(|s| s.success())
                .unwrap_or(false);
            return InstallResult {
                ok,
                message: if ok { "Установлено".into() } else { "winget не смог установить компонент. Откроется официальный сайт.".into() },
                url: if ok { None } else { Some(official_url(id).into()) },
            };
        }
    }
    #[cfg(target_os = "macos")]
    {
        let brew = ["/opt/homebrew/bin/brew", "/usr/local/bin/brew"].into_iter().find(|p| Path::new(p).exists());
        let args: Option<&[&str]> = match id {
            "libreoffice" => Some(&["install", "--cask", "libreoffice"]),
            "pandoc" => Some(&["install", "pandoc"]),
            "calibre" => Some(&["install", "--cask", "calibre"]),
            "magick" => Some(&["install", "imagemagick"]),
            "7zip" => Some(&["install", "sevenzip"]),
            _ => None,
        };
        if let (Some(brew), Some(args)) = (brew, args) {
            let ok = Command::new(brew).args(args).env("HOMEBREW_NO_AUTO_UPDATE", "1").status().map(|s| s.success()).unwrap_or(false);
            return InstallResult {
                ok,
                message: if ok { "Установлено".into() } else { "Homebrew не смог установить компонент. Откроется официальный сайт.".into() },
                url: if ok { None } else { Some(official_url(id).into()) },
            };
        }
    }
    InstallResult { ok: false, message: "Автоматическая установка недоступна — откроется официальный сайт.".into(), url: Some(official_url(id).into()) }
}

// ---------------------------------------------------------------------------
// Контекстное меню

const VERB: &str = "Конвертировать в…";

pub fn integration_status(resources: &Path) -> Value {
    let _ = resources;
    #[cfg(target_os = "macos")]
    {
        let wf = home().join("Library/Services/Конвертировать в Morph.workflow");
        return json!({ "platform": "mac", "finder": wf.exists(), "automation": "unknown" });
    }
    #[cfg(windows)]
    {
        let classic = run("reg", &["query", r"HKCU\Software\Classes\*\shell\Morph"]).is_some();
        let modern = run("powershell", &["-NoProfile", "-Command", "if (Get-AppxPackage -Name MorphContextMenu) { 'yes' }"]).map(|s| s.contains("yes")).unwrap_or(false);
        return json!({ "platform": "win", "explorerClassic": classic, "explorerModern": modern });
    }
    #[allow(unreachable_code)]
    json!({ "platform": "other" })
}

#[allow(dead_code)]
fn home() -> PathBuf {
    std::env::var_os("HOME").map(PathBuf::from).unwrap_or_default()
}

/// kind: "finder" | "automation" | "explorerClassic" | "explorerModern"
pub fn install_integration(kind: &str, resources: &Path, exe: &Path) -> Result<String, String> {
    let _ = (resources, exe);
    match kind {
        #[cfg(target_os = "macos")]
        "finder" => {
            let src = resources.join("integrations/macos/Конвертировать в Morph.workflow");
            let dst_dir = home().join("Library/Services");
            std::fs::create_dir_all(&dst_dir).map_err(|e| e.to_string())?;
            let dst = dst_dir.join("Конвертировать в Morph.workflow");
            let _ = std::fs::remove_dir_all(&dst);
            morph_core::naming::copy_dir(&src, &dst).map_err(|e| format!("Не удалось скопировать быстрое действие: {e}"))?;
            // Путь к приложению в скрипте действия
            let wflow = dst.join("Contents/document.wflow");
            if let Ok(s) = std::fs::read_to_string(&wflow) {
                // путь вставляется внутрь XML — экранируем спецсимволы
                let p = exe.display().to_string().replace('&', "&amp;").replace('<', "&lt;").replace('>', "&gt;").replace('"', "\\\"");
                let _ = std::fs::write(&wflow, s.replace("__MORPH_EXE__", &p));
            }
            let _ = Command::new("/System/Library/CoreServices/pbs").arg("-update").status();
            Ok("Готово".into())
        }
        #[cfg(target_os = "macos")]
        "automation" => {
            if crate::selection::request_automation() {
                let _ = Command::new("open").arg("x-apple.systempreferences:com.apple.preference.security?Privacy_Automation").status();
                Ok("Готово".into())
            } else {
                let _ = Command::new("open").arg("x-apple.systempreferences:com.apple.preference.security?Privacy_Automation").status();
                Ok("Разрешите Morph управлять Finder в открывшихся настройках".into())
            }
        }
        #[cfg(windows)]
        "explorerClassic" => {
            let exe_s = exe.display().to_string();
            let cmd = format!("\"{exe_s}\" --menu \"%1\"");
            for base in [r"HKCU\Software\Classes\*\shell\Morph", r"HKCU\Software\Classes\Directory\shell\Morph"] {
                let ok = run("reg", &["add", base, "/v", "MUIVerb", "/d", VERB, "/f"]).is_some()
                    && run("reg", &["add", base, "/v", "Icon", "/d", &format!("{exe_s},0"), "/f"]).is_some()
                    && run("reg", &["add", base, "/v", "MultiSelectModel", "/d", "Player", "/f"]).is_some()
                    && run("reg", &["add", &format!(r"{base}\command"), "/ve", "/d", &cmd, "/f"]).is_some();
                if !ok {
                    return Err("Не удалось записать пункт меню в реестр".into());
                }
            }
            Ok("Готово".into())
        }
        #[cfg(windows)]
        "explorerModern" => {
            let script = resources.join(r"integrations\windows\install-modern-menu.ps1");
            let install_dir = exe.parent().map(|p| p.display().to_string()).unwrap_or_default();
            // Импорт сертификата требует прав администратора — Windows спросит подтверждение
            let ps = format!(
                "Start-Process powershell -Verb RunAs -Wait -ArgumentList '-NoProfile','-ExecutionPolicy','Bypass','-File','\"{}\"','-InstallDir','\"{}\"'",
                script.display(),
                install_dir
            );
            let ok = Command::new("powershell").args(["-NoProfile", "-Command", &ps]).status().map(|s| s.success()).unwrap_or(false);
            if ok {
                Ok("Готово. Если пункта нет — перезапустите Проводник.".into())
            } else {
                Err("Не удалось зарегистрировать пакет. Подробности — README, раздел «Новое меню Windows 11».".into())
            }
        }
        _ => Err("Недоступно на этой системе".into()),
    }
}

pub fn uninstall_integration(kind: &str) -> Result<String, String> {
    match kind {
        #[cfg(target_os = "macos")]
        "finder" => {
            let _ = std::fs::remove_dir_all(home().join("Library/Services/Конвертировать в Morph.workflow"));
            let _ = Command::new("/System/Library/CoreServices/pbs").arg("-update").status();
            Ok("Готово".into())
        }
        #[cfg(windows)]
        "explorerClassic" => {
            let _ = run("reg", &["delete", r"HKCU\Software\Classes\*\shell\Morph", "/f"]);
            let _ = run("reg", &["delete", r"HKCU\Software\Classes\Directory\shell\Morph", "/f"]);
            Ok("Готово".into())
        }
        #[cfg(windows)]
        "explorerModern" => {
            let _ = run("powershell", &["-NoProfile", "-Command", "Get-AppxPackage -Name MorphContextMenu | Remove-AppxPackage"]);
            Ok("Готово".into())
        }
        _ => Err("Недоступно на этой системе".into()),
    }
}
