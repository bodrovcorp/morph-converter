//! Какие файлы выделены в Finder / Проводнике в момент нажатия горячей клавиши.
//!
//! macOS: AppleScript к Finder. Нужно одно разрешение «Автоматизация → Finder»; Accessibility не нужен.
//! Windows: COM-объект Shell.Application через заранее запущенный PowerShell (ответ ~20–40 мс).
//!          Для вкладок Проводника Windows 11 выбирается активная — по заголовку окна.

use std::path::PathBuf;

#[cfg(target_os = "macos")]
pub fn selected_files() -> Vec<PathBuf> {
    const SCRIPT: &str = r#"
tell application "Finder"
  if not frontmost then return ""
  set sel to selection as alias list
end tell
set out to ""
repeat with f in sel
  set out to out & POSIX path of f & linefeed
end repeat
return out"#;
    let out = std::process::Command::new("/usr/bin/osascript").arg("-e").arg(SCRIPT).output();
    match out {
        Ok(o) if o.status.success() => String::from_utf8_lossy(&o.stdout)
            .lines()
            .map(|l| l.trim_end())
            .filter(|l| !l.is_empty())
            // «/Users/me/Папка/» → без завершающего слэша, чтобы имя папки определилось верно
            .map(|l| PathBuf::from(if l.len() > 1 { l.trim_end_matches('/') } else { l }))
            .collect(),
        _ => Vec::new(),
    }
}

/// Запросить разрешение «Автоматизация → Finder» (система покажет диалог один раз)
#[cfg(target_os = "macos")]
pub fn request_automation() -> bool {
    std::process::Command::new("/usr/bin/osascript")
        .args(["-e", "tell application \"Finder\" to get name of startup disk"])
        .output()
        .map(|o| o.status.success())
        .unwrap_or(false)
}

#[cfg(windows)]
mod win {
    use std::io::{BufRead, BufReader, Write};
    use std::os::windows::process::CommandExt;
    use std::path::PathBuf;
    use std::process::{Child, ChildStdin, ChildStdout, Command, Stdio};
    use std::sync::mpsc;
    use std::sync::Mutex;
    use std::time::Duration;

    const PRELUDE: &str = r#"
$ErrorActionPreference = 'SilentlyContinue'
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
Add-Type -Namespace MorphNative -Name W -MemberDefinition @'
[DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
[DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern int GetWindowText(IntPtr h, System.Text.StringBuilder s, int n);
'@
$global:MorphShell = New-Object -ComObject Shell.Application
function Get-MorphSelection {
  $fg = [MorphNative.W]::GetForegroundWindow()
  $sb = New-Object System.Text.StringBuilder 1024
  [void][MorphNative.W]::GetWindowText($fg, $sb, 1024)
  $title = $sb.ToString()
  $c = @($global:MorphShell.Windows() | Where-Object { $_.HWND -eq [long]$fg })
  if ($c.Count -gt 1) { $m = @($c | Where-Object { $title.StartsWith([string]$_.LocationName) }); if ($m.Count -ge 1) { $c = $m } }
  if ($c.Count -ge 1) { foreach ($i in $c[0].Document.SelectedItems()) { [Console]::WriteLine($i.Path) } }
  [Console]::WriteLine('<<MORPH-END>>')
}
[Console]::WriteLine('<<MORPH-READY>>')
"#;

    struct Helper {
        _child: Child,
        stdin: ChildStdin,
        lines: mpsc::Receiver<String>,
    }

    static HELPER: Mutex<Option<Helper>> = Mutex::new(None);

    fn spawn() -> Option<Helper> {
        let mut child = Command::new("powershell.exe")
            .args(["-NoLogo", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command", "-"])
            .stdin(Stdio::piped())
            .stdout(Stdio::piped())
            .stderr(Stdio::null())
            .creation_flags(0x0800_0000) // без мигающего окна консоли
            .spawn()
            .ok()?;
        let mut stdin = child.stdin.take()?;
        let stdout: ChildStdout = child.stdout.take()?;
        let (tx, rx) = mpsc::channel();
        std::thread::spawn(move || {
            for line in BufReader::new(stdout).lines().map_while(Result::ok) {
                if tx.send(line).is_err() {
                    break;
                }
            }
        });
        stdin.write_all(PRELUDE.as_bytes()).ok()?;
        stdin.write_all(b"\n").ok()?;
        stdin.flush().ok()?;
        // ждём готовности (компиляция Add-Type — один раз, около секунды)
        loop {
            match rx.recv_timeout(Duration::from_secs(15)) {
                Ok(l) if l.contains("<<MORPH-READY>>") => break,
                Ok(_) => continue,
                Err(_) => return None,
            }
        }
        Some(Helper { _child: child, stdin, lines: rx })
    }

    /// Запускается при старте приложения в фоне — чтобы первое нажатие было мгновенным
    pub fn warm_up() {
        std::thread::spawn(|| {
            let mut g = HELPER.lock().unwrap();
            if g.is_none() {
                *g = spawn();
            }
        });
    }

    pub fn selected_files() -> Vec<PathBuf> {
        let mut g = HELPER.lock().unwrap();
        if g.is_none() {
            *g = spawn();
        }
        let Some(h) = g.as_mut() else { return Vec::new() };
        while h.lines.try_recv().is_ok() {}
        if h.stdin.write_all(b"Get-MorphSelection\n").and_then(|_| h.stdin.flush()).is_err() {
            *g = None;
            return Vec::new();
        }
        let mut out = Vec::new();
        loop {
            match h.lines.recv_timeout(Duration::from_millis(2500)) {
                Ok(l) if l.contains("<<MORPH-END>>") => break,
                Ok(l) if !l.trim().is_empty() => out.push(PathBuf::from(l.trim())),
                Ok(_) => {}
                Err(_) => {
                    *g = None; // помощник завис — перезапустим при следующем вызове
                    break;
                }
            }
        }
        out
    }
}

#[cfg(windows)]
pub use win::{selected_files, warm_up};

#[cfg(not(windows))]
pub fn warm_up() {}

#[cfg(not(any(target_os = "macos", windows)))]
pub fn selected_files() -> Vec<PathBuf> {
    Vec::new()
}
