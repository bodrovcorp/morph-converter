// Без консольного окна в Windows (release)
#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

fn main() {
    morph_app::run()
}
