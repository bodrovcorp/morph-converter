; Дополнительные шаги установщика Windows (NSIS)
!macro NSIS_HOOK_POSTUNINSTALL
  ; убрать пункт «Конвертировать в…» из контекстного меню Проводника
  DeleteRegKey HKCU "Software\Classes\*\shell\Morph"
  DeleteRegKey HKCU "Software\Classes\Directory\shell\Morph"
  nsExec::Exec 'powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-AppxPackage -Name MorphContextMenu | Remove-AppxPackage"'
!macroend
