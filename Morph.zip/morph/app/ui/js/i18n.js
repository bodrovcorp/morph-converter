// Строки интерфейса. Русский — основной, английский — дополнительный.
const RU = {
  "menu.title": "Конвертировать в…",
  "menu.search": "Конвертировать в… начните печатать",
  "menu.fav": "Избранное",
  "menu.popular": "Популярные",
  "menu.more": "Ещё",
  "menu.moreN": (n) => `Ещё ${n} ${plural(n, "формат", "формата", "форматов")}`,
  "menu.found": "Найдено",
  "menu.nothing": "Ничего не нашлось. Попробуйте «jpg», «pdf» или «mp3».",
  "menu.needs": (e) => `нужен ${e}`,
  "menu.convert": (x) => `В ${x}`,
  "menu.hints": "↑↓ выбор · Tab параметры · Esc",
  "menu.empty.title": "Нет выделенных файлов",
  "menu.empty.text": "Выделите файлы в Finder или Проводнике и нажмите сочетание ещё раз — или перетащите их сюда.",
  "menu.pick": "Выбрать файлы…",
  "menu.files": (n) => `${n} ${plural(n, "файл", "файла", "файлов")}`,
  "menu.mixed": "разные типы",
  "menu.conflict": (n) => `Файл «${n}» уже есть.`,
  "menu.replace": "Заменить",
  "menu.keepBoth": "Сохранить оба",
  "menu.cancel": "Отмена",
  "menu.star": "В избранное",
  "menu.unstar": "Убрать из избранного",
  "menu.installHint": "Откроются Настройки → Компоненты",
  "opt.quality": "Качество",
  "opt.resize": "Размер",
  "opt.resize.none": "Как у исходника",
  "opt.strip": "Убрать метаданные (EXIF, GPS)",
  "opt.vq": "Качество видео",
  "opt.vq.high": "Высокое",
  "opt.vq.balanced": "Баланс",
  "opt.vq.small": "Меньше размер",
  "opt.height": "Разрешение",
  "opt.noAudio": "Без звука",
  "opt.gifFps": "Кадров в секунду",
  "opt.gifWidth": "Ширина",
  "opt.bitrate": "Битрейт",
  "opt.dpi": "Чёткость страниц",
  "opt.bom": "CSV для Excel (UTF-8 с BOM)",
  "prog.title": "Конвертация",
  "prog.summary": (done, total) => `${done} из ${total} готово`,
  "prog.left": (s) => `осталось ${s}`,
  "prog.queued": "В очереди",
  "prog.waiting": (e) => `ждёт ${e}`,
  "prog.done": "Готово",
  "prog.cancelled": "Отменено, временные файлы удалены",
  "prog.reveal": "Показать в папке",
  "prog.details": "Подробнее",
  "prog.retry": "Повторить",
  "prog.cancelAll": "Отменить всё",
  "prog.clear": "Очистить завершённые",
  "prog.minimize": "Свернуть панель",
  "prog.cancel": "Отменить конвертацию",
  "prog.batch": (n, t) => `${n} ${plural(n, "файл", "файла", "файлов")} → ${t}`,
  "prog.idle": "Нет активных задач",
  "set.title": "Настройки",
  "set.general": "Основные",
  "set.hotkey": "Горячая клавиша",
  "set.quality": "Качество",
  "set.formats": "Форматы",
  "set.look": "Внешний вид",
  "set.integration": "Интеграция",
  "set.engines": "Компоненты",
  "set.history": "История",
  "set.footer": "Morph 1.0 · всё локально",
};

const EN = {
  "menu.title": "Convert to…",
  "menu.search": "Convert to… start typing",
  "menu.fav": "Favorites",
  "menu.popular": "Popular",
  "menu.more": "More",
  "menu.moreN": (n) => `${n} more formats`,
  "menu.found": "Found",
  "menu.nothing": "Nothing found. Try “jpg”, “pdf” or “mp3”.",
  "menu.needs": (e) => `needs ${e}`,
  "menu.convert": (x) => `To ${x}`,
  "menu.hints": "↑↓ select · Tab options · Esc",
  "menu.empty.title": "No files selected",
  "menu.empty.text": "Select files in Finder or Explorer and press the shortcut again — or drop them here.",
  "menu.pick": "Choose files…",
  "menu.files": (n) => `${n} file${n === 1 ? "" : "s"}`,
  "menu.mixed": "mixed types",
  "menu.conflict": (n) => `“${n}” already exists.`,
  "menu.replace": "Replace",
  "menu.keepBoth": "Keep both",
  "menu.cancel": "Cancel",
  "prog.title": "Converting",
  "prog.summary": (d, t) => `${d} of ${t} done`,
  "prog.left": (s) => `${s} left`,
  "prog.reveal": "Show in folder",
  "prog.cancelAll": "Cancel all",
  "prog.clear": "Clear finished",
  "set.title": "Settings",
};

let lang = "ru";
export function setLang(l) {
  lang = l === "en" ? "en" : "ru";
  document.documentElement.lang = lang;
}
export function t(key, ...args) {
  const v = (lang === "en" && EN[key] !== undefined ? EN[key] : RU[key]) ?? key;
  return typeof v === "function" ? v(...args) : v;
}

export function plural(n, one, few, many) {
  const m10 = n % 10,
    m100 = n % 100;
  if (m10 === 1 && m100 !== 11) return one;
  if (m10 >= 2 && m10 <= 4 && (m100 < 12 || m100 > 14)) return few;
  return many;
}

export function fmtBytes(b) {
  if (!b && b !== 0) return "";
  const u = ["Б", "КБ", "МБ", "ГБ", "ТБ"];
  let i = 0;
  let v = b;
  while (v >= 1000 && i < u.length - 1) {
    v /= 1024;
    i++;
  }
  const s = v >= 10 || i === 0 ? Math.round(v).toString() : v.toFixed(1).replace(".", ",");
  return `${s} ${u[i]}`;
}

export function fmtEta(sec) {
  if (sec == null || !isFinite(sec)) return "";
  sec = Math.max(1, Math.round(sec));
  if (sec < 60) return `~${sec} с`;
  const m = Math.floor(sec / 60),
    s = sec % 60;
  if (m < 60) return s ? `~${m} мин ${s} с` : `~${m} мин`;
  const h = Math.floor(m / 60);
  return `~${h} ч ${m % 60} мин`;
}

// Раскладка: «озп» (набрано в русской раскладке) → «jpg»
const RU_KEYS = "йцукенгшщзхъфывапролджэячсмитьбю";
const EN_KEYS = "qwertyuiop[]asdfghjkl;'zxcvbnm,.";
export function swapLayout(s) {
  let out = "";
  for (const ch of s.toLowerCase()) {
    const i = RU_KEYS.indexOf(ch);
    if (i >= 0) {
      out += EN_KEYS[i];
      continue;
    }
    const j = EN_KEYS.indexOf(ch);
    out += j >= 0 ? RU_KEYS[j] : ch;
  }
  return out;
}

export const isMac = /Mac|iPhone|iPad/.test(navigator.platform || navigator.userAgent);
export const modKey = isMac ? "⌘" : "Ctrl+";

/** Человекочитаемое сочетание из строки-акселератора Tauri */
export function prettyAccel(acc) {
  if (!acc) return "";
  const parts = acc.split("+");
  const mac = { Control: "⌃", Ctrl: "⌃", Alt: "⌥", Option: "⌥", Super: "⌘", Command: "⌘", Cmd: "⌘", Shift: "⇧", CommandOrControl: "⌘" };
  const win = { Control: "Ctrl", Ctrl: "Ctrl", Alt: "Alt", Option: "Alt", Super: "Win", Command: "Win", Cmd: "Win", Shift: "Shift", CommandOrControl: "Ctrl" };
  return parts.map((p) => (isMac ? mac[p] : win[p]) || p.replace(/^Key/, "").replace(/^Digit/, ""));
}
