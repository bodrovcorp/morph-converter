// Мост к оболочке Tauri. В обычном браузере (просмотр макета, UI-тесты) подключается имитация бэкенда.
let api;
if (window.__TAURI__) {
  const T = window.__TAURI__;
  api = {
    real: true,
    invoke: (cmd, args = {}) => T.core.invoke(cmd, args),
    listen: (ev, cb) => T.event.listen(ev, (e) => cb(e.payload)),
  };
} else {
  api = (await import("./mock.js")).mockApi;
}
export { api };

// Применение внешнего вида: стиль, тема, прозрачность, движение, системные настройки доступности
export function applyAppearance(settings, system = {}) {
  const a = settings.appearance || {};
  const root = document.documentElement;
  const darkSys = window.matchMedia("(prefers-color-scheme: dark)").matches || system.dark;
  const theme = a.theme === "system" || !a.theme ? (darkSys ? "dark" : "light") : a.theme;
  root.dataset.style = a.style || "glass";
  root.dataset.theme = theme;
  const follow = a.followSystem !== false;
  const sysReduce = follow && (system.reduceTransparency || window.matchMedia("(prefers-reduced-transparency: reduce)").matches);
  root.dataset.reduceTransparency = String(!!(a.reduceTransparency || sysReduce));
  const sysMotion = follow && system.reduceMotion;
  root.dataset.motion = String(a.motion !== false && !sysMotion);
  // «Прозрачность стекла» 0…100 → плотность подложки 0.92…0.52 (ниже — текст хуже читается)
  const tr = Math.min(100, Math.max(0, a.glassTransparency ?? 50));
  root.style.setProperty("--tint-a", (0.92 - 0.4 * (tr / 100)).toFixed(3));
  const blur = { soft: 14, medium: 30, strong: 48 }[a.blur || "medium"];
  root.style.setProperty("--blur", root.dataset.reduceTransparency === "true" || root.dataset.style !== "glass" ? "0px" : `${blur}px`);
  if (api.real) {
    // В приложении окно = панель; размытие и тень даёт система, CSS-поля и тень не нужны
    root.dataset.native = "true";
    root.dataset.platform = /Mac/.test(navigator.platform) ? "mac" : "win";
  }
}

export async function initAppearance() {
  const s = await api.invoke("get_settings");
  let sys = {};
  try {
    sys = await api.invoke("system_appearance");
  } catch {}
  applyAppearance(s, sys);
  window.matchMedia("(prefers-color-scheme: dark)").addEventListener("change", () => applyAppearance(s, sys));
  api.listen("settings:changed", (ns) => applyAppearance(ns, sys));
  return s;
}

export function esc(s) {
  return String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
}

export const ICONS = {
  search: '<svg aria-hidden="true" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/></svg>',
  x: '<svg aria-hidden="true" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg>',
  check: '<svg aria-hidden="true" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>',
  warn: '<svg aria-hidden="true" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M12 3l9.5 17h-19z"/><path d="M12 10v4.5M12 17.5v.5"/></svg>',
  chev: '<svg aria-hidden="true" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 6l6 6-6 6"/></svg>',
  minus: '<svg aria-hidden="true" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M5 12h14"/></svg>',
  star: '<svg aria-hidden="true" width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><path d="M12 3.5l2.6 5.3 5.9.9-4.3 4.1 1 5.8L12 16.9l-5.2 2.7 1-5.8-4.3-4.1 5.9-.9z"/></svg>',
  starOff: '<svg aria-hidden="true" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M12 3.5l2.6 5.3 5.9.9-4.3 4.1 1 5.8L12 16.9l-5.2 2.7 1-5.8-4.3-4.1 5.9-.9z"/></svg>',
  retry: '<svg aria-hidden="true" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M4 12a8 8 0 1 0 2.4-5.7M4 4v4h4"/></svg>',
};

/** Пиктограмма файла по типу: простая форма, без эмодзи */
export function fileGlyph(kind) {
  const mark = {
    image: '<circle cx="11" cy="19" r="2.6" fill="var(--accent)"/><path d="M6 29l6-6 4 4 3-3 5 5" stroke="var(--accent)" stroke-width="1.6" stroke-linejoin="round" fill="none"/>',
    video: '<path d="M11 18v9l8-4.5z" fill="var(--accent)"/>',
    audio: '<path d="M12 27a2.5 2.5 0 1 1-1-2V16l9-2v10a2.5 2.5 0 1 1-1-2v-6l-7 1.5" stroke="var(--accent)" stroke-width="1.4" fill="none"/>',
    document: '<path d="M8 17h14M8 21h14M8 25h9" stroke="var(--accent)" stroke-width="1.6" stroke-linecap="round"/>',
    spreadsheet: '<path d="M7 16h16v12H7zM7 20h16M7 24h16M13 16v12" stroke="var(--accent)" stroke-width="1.3" fill="none"/>',
    presentation: '<rect x="7" y="16" width="16" height="10" rx="1.5" stroke="var(--accent)" stroke-width="1.4" fill="none"/><path d="M15 26v3" stroke="var(--accent)" stroke-width="1.4"/>',
    ebook: '<path d="M8 16h6a2 2 0 0 1 2 2v11a2 2 0 0 0-2-2H8zM22 16h-6v13a2 2 0 0 1 2-2h4z" stroke="var(--accent)" stroke-width="1.3" fill="none"/>',
    archive: '<path d="M15 14v2m0 2v2m0 2v2" stroke="var(--accent)" stroke-width="2"/><rect x="12.5" y="24" width="5" height="5" rx="1" stroke="var(--accent)" stroke-width="1.4" fill="none"/>',
  }[kind] || '<path d="M9 22h12" stroke="var(--accent)" stroke-width="1.6" stroke-linecap="round"/>';
  return `<svg aria-hidden="true" width="30" height="36" viewBox="0 0 30 36" fill="none"><path d="M4 1.5h15l9 9V32a2.5 2.5 0 0 1-2.5 2.5h-21A2.5 2.5 0 0 1 2 32V4a2.5 2.5 0 0 1 2-2.5z" fill="var(--chip)" stroke="var(--faint)" stroke-width="1.2"/><path d="M19 1.5V9a1.5 1.5 0 0 0 1.5 1.5H28" stroke="var(--faint)" stroke-width="1.2"/>${mark}</svg>`;
}
