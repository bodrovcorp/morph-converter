// Панель прогресса: задачи очереди, проценты, оставшееся время, отмена, «Показать в папке».
import { api, initAppearance, esc, ICONS } from "./bridge.js";
import { t, setLang, fmtBytes, fmtEta } from "./i18n.js";

const $ = (s) => document.querySelector(s);
const jobs = new Map();
const openDetails = new Set();
const openBatches = new Set();

const settings = await initAppearance();
setLang(settings.language);
$("#title").textContent = t("prog.title");
$("#min").innerHTML = ICONS.minus;
$("#min").setAttribute("aria-label", t("prog.minimize"));
$("#cancelAll").textContent = t("prog.cancelAll");
$("#clear").textContent = t("prog.clear");

const active = (j) => j.status === "running" || j.status === "queued";
const chip = (s) => `<span class="ext sm">${esc(s)}</span>`;

function statusLine(j) {
  switch (j.status) {
    case "running": {
      const eta = j.eta != null ? ` · ${t("prog.left", fmtEta(j.eta))}` : "";
      const size = j.srcBytes ? `<span>${fmtBytes(j.srcBytes)}</span>` : "";
      return `<div class="st"><span>${Math.floor(j.progress * 100)}%${eta}</span>${size}</div>`;
    }
    case "queued":
      return `<div class="st"><span>${esc(t("prog.queued"))}${j.waiting ? " · " + esc(t("prog.waiting", j.waiting)) : ""}</span></div>`;
    case "done": {
      const sizes = j.srcBytes && j.outBytes ? ` · ${fmtBytes(j.srcBytes)} → ${fmtBytes(j.outBytes)}` : "";
      return `<div class="st"><span class="ok">${ICONS.check}${esc(t("prog.done"))}${sizes}</span><button class="link" data-reveal="${j.id}">${esc(t("prog.reveal"))}</button></div>`;
    }
    case "failed":
      return `<div class="st"><span class="err">${ICONS.warn}<span>${esc(j.error)}</span></span><button class="link" data-details="${j.id}" aria-expanded="${openDetails.has(j.id)}">${esc(t("prog.details"))}</button></div>${openDetails.has(j.id) ? `<pre class="details">${esc(j.details)}</pre>` : ""}`;
    case "cancelled":
      return `<div class="st"><span>${esc(t("prog.cancelled"))}</span><button class="link" data-retry="${j.id}">${esc(t("prog.retry"))}</button></div>`;
  }
  return "";
}

function jobRow(j) {
  const bar = j.status === "running" ? `<div class="bar" role="progressbar" aria-valuenow="${Math.round(j.progress * 100)}" aria-valuemin="0" aria-valuemax="100"><i style="width:${(j.progress * 100).toFixed(1)}%"></i></div>` : "";
  const cancel = active(j) ? `<button class="icon-btn" data-cancel="${j.id}" aria-label="${esc(t("prog.cancel"))}: ${esc(j.name)}">${ICONS.x}</button>` : "";
  return `<div class="job" data-job="${j.id}"><div class="body"><div class="line"><span class="name" title="${esc(j.name)}">${esc(j.name)}</span>${chip(j.srcTitle || "")}<span class="arrow" aria-hidden="true">→</span>${chip(j.targetTitle || j.target.toUpperCase())}</div>${bar}${statusLine(j)}</div>${cancel}</div>`;
}

function batchRow(id, list) {
  const done = list.filter((j) => j.status === "done").length;
  const failed = list.filter((j) => j.status === "failed").length;
  const prog = list.reduce((s, j) => s + (j.status === "done" ? 1 : j.status === "running" ? j.progress : 0), 0) / list.length;
  const running = list.some(active);
  const etas = list.filter((j) => j.status === "running" && j.eta != null).map((j) => j.eta);
  const queued = list.filter((j) => j.status === "queued").length;
  // грубая оценка: текущее ETA + среднее время на файл × очередь
  const avg = list.filter((j) => j.status === "done" && j.elapsed).reduce((s, j, _, a) => s + j.elapsed / a.length, 0);
  const eta = etas.length ? Math.max(...etas) + avg * queued : null;
  const open = openBatches.has(id);
  const head = `<div class="job" data-batch="${id}"><div class="body"><div class="line"><span class="name">${esc(t("prog.batch", list.length, list[0].targetTitle))}</span><button class="link" data-toggle="${id}" aria-expanded="${open}">${open ? "Свернуть" : "Все файлы"}</button></div>
    ${running ? `<div class="bar" role="progressbar" aria-valuenow="${Math.round(prog * 100)}"><i style="width:${(prog * 100).toFixed(1)}%"></i></div>` : ""}
    <div class="st"><span class="${!running && !failed ? "ok" : ""}">${!running && !failed ? ICONS.check : ""}${done} из ${list.length}${failed ? ` · <span class="err">ошибок: ${failed}</span>` : ""}${running && eta != null ? ` · ${t("prog.left", fmtEta(eta))}` : ""}</span>
    ${!running && done ? `<button class="link" data-reveal="${list.find((j) => j.status === "done").id}">${esc(t("prog.reveal"))}</button>` : ""}</div></div>
    ${running ? `<button class="icon-btn" data-cancel="${id}" aria-label="${esc(t("prog.cancel"))}">${ICONS.x}</button>` : ""}</div>`;
  return head + (open ? list.map(jobRow).join("") : "");
}

function render() {
  const all = [...jobs.values()].sort((a, b) => a.created - b.created || a.id - b.id);
  const groups = new Map();
  for (const j of all) {
    if (!groups.has(j.batch)) groups.set(j.batch, []);
    groups.get(j.batch).push(j);
  }
  let html = "";
  for (const [id, list] of groups) html += list.length > 3 ? batchRow(id, list) : list.map(jobRow).join("");
  $("#list").innerHTML = html || `<div class="idle">${esc(t("prog.idle"))}</div>`;
  const total = all.length;
  const done = all.filter((j) => j.status === "done").length;
  const running = all.filter(active);
  const progress = total ? all.reduce((s, j) => s + (j.status === "running" ? j.progress : j.status === "queued" ? 0 : 1), 0) / total : 0;
  const etas = running.filter((j) => j.eta != null).map((j) => j.eta);
  $("#sum").textContent = total ? `${t("prog.summary", done, total)}${etas.length ? " · " + t("prog.left", fmtEta(Math.max(...etas))) : ""}` : "";
  $("#total i").style.width = `${(progress * 100).toFixed(1)}%`;
  $("#total").setAttribute("aria-valuenow", String(Math.round(progress * 100)));
  $("#total").parentElement.hidden = !running.length;
  $("#cancelAll").hidden = !running.length;
}

let raf = 0;
function schedule() {
  if (!raf) raf = requestAnimationFrame(() => ((raf = 0), render()));
}

api.listen("job", (j) => {
  jobs.set(j.id, j);
  schedule();
});
api.listen("jobs:reset", (list) => {
  jobs.clear();
  list.forEach((j) => jobs.set(j.id, j));
  schedule();
});

document.addEventListener("click", async (e) => {
  const b = e.target.closest("button");
  if (!b) return;
  if (b.dataset.cancel) await api.invoke("cancel", { id: Number(b.dataset.cancel) });
  else if (b.dataset.reveal) {
    const j = jobs.get(Number(b.dataset.reveal));
    if (j && j.outputs[0]) await api.invoke("reveal", { path: j.outputs[0] });
  } else if (b.dataset.details) {
    const id = Number(b.dataset.details);
    openDetails.has(id) ? openDetails.delete(id) : openDetails.add(id);
    render();
  } else if (b.dataset.retry) await api.invoke("retry", { id: Number(b.dataset.retry) });
  else if (b.dataset.toggle) {
    const id = Number(b.dataset.toggle);
    openBatches.has(id) ? openBatches.delete(id) : openBatches.add(id);
    render();
  } else if (b.id === "cancelAll") await api.invoke("cancel_all");
  else if (b.id === "clear") await api.invoke("clear_finished");
  else if (b.id === "min") await api.invoke("hide_progress").catch(() => {});
});

document.addEventListener("keydown", (e) => {
  if (e.key === "Escape") api.invoke("hide_progress").catch(() => {});
});

(await api.invoke("jobs")).forEach((j) => jobs.set(j.id, j));
if (!api.real && new URLSearchParams(location.search).get("demo") !== "0") api.demoJobs();
render();
