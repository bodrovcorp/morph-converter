// Окно настроек. Каждое изменение сохраняется сразу (без кнопки «Сохранить»).
import { api, initAppearance, applyAppearance, esc, ICONS } from "./bridge.js";
import { t, setLang, isMac, prettyAccel } from "./i18n.js";

const $ = (s) => document.querySelector(s);
let S = await initAppearance();
setLang(S.language);
const params = new URLSearchParams(location.search);
if (!api.real) document.documentElement.dataset.preview = params.get("embed") === "1" ? "false" : "true";

const TABS = ["general", "hotkey", "quality", "formats", "look", "integration", "engines", "history"];
let tab = params.get("tab") || "general";
let highlight = params.get("highlight") || null;

const PRESETS = isMac
  ? { A: "Control+Alt+Super+X", B: "Control+Super+X", C: "" }
  : { A: "Super+Shift+X", B: "Control+Super+X", C: "" };

async function save(patch) {
  S = deepMerge(S, patch);
  const res = await api.invoke("set_settings", { settings: S });
  applyAppearance(S);
  return res;
}
function deepMerge(a, b) {
  const out = Array.isArray(a) ? [...a] : { ...a };
  for (const [k, v] of Object.entries(b)) out[k] = v && typeof v === "object" && !Array.isArray(v) ? deepMerge(a[k] || {}, v) : v;
  return out;
}

// ---------- Элементы управления ----------
const sw = (key, value, label, hint = "") =>
  `<div class="row"><div class="l"><span id="l-${key}">${esc(label)}</span>${hint ? `<span class="h">${esc(hint)}</span>` : ""}</div><button class="switch" role="switch" aria-labelledby="l-${key}" aria-checked="${!!value}" data-sw="${key}"></button></div>`;
const seg = (key, value, label, items, hint = "") =>
  `<div class="row col"><div class="l"><span>${esc(label)}</span>${hint ? `<span class="h">${esc(hint)}</span>` : ""}</div><div class="seg" role="group" aria-label="${esc(label)}">${items.map(([v, l]) => `<button type="button" data-seg="${key}" data-val="${v}" aria-pressed="${String(value) === String(v)}">${esc(l)}</button>`).join("")}</div></div>`;
const sel = (key, value, label, items, hint = "") =>
  `<div class="row"><div class="l"><label for="s-${key}">${esc(label)}</label>${hint ? `<span class="h">${esc(hint)}</span>` : ""}</div><select class="select" id="s-${key}" data-sel="${key}">${items.map(([v, l]) => `<option value="${v}" ${String(v) === String(value) ? "selected" : ""}>${esc(l)}</option>`).join("")}</select></div>`;
const kbd = (k) => `<span class="kbd">${esc(k)}</span>`;

// путь вида "quality.image" → значение
const get = (path) => path.split(".").reduce((o, k) => (o ? o[k] : undefined), S);
const patchOf = (path, value) => path.split(".").reduceRight((acc, k) => ({ [k]: acc }), value);

// ---------- Разделы ----------
const views = {
  general() {
    return `<h2>${t("set.general")}</h2>
    ${sw("autostart", S.autostart, "Запускать при входе в систему", "Morph живёт в строке меню / трее и почти не тратит ресурсы в простое")}
    ${seg("saveMode", S.saveMode, "Куда сохранять результат", [["beside", "Рядом с исходником"], ["folder", "В выбранную папку"]])}
    ${S.saveMode === "folder" ? `<div class="row"><div class="l"><span>Папка</span><span class="h">${esc(S.saveFolder || "не выбрана")}</span></div><button class="btn" id="pickFolder">Выбрать…</button></div>` : ""}
    ${seg("conflict", S.conflict, "Если файл с таким именем уже есть", [["suffix", "Добавить « (1)»"], ["overwrite", "Перезаписать"], ["ask", "Спросить"]], "Исходный файл не перезаписывается никогда")}
    ${sw("notify", S.notify, "Уведомлять о завершении", "Системное уведомление, когда задача длилась дольше 10 секунд")}
    ${sel("language", S.language, "Язык интерфейса", [["ru", "Русский"], ["en", "English"]])}`;
  },
  hotkey() {
    const cur = S.hotkey;
    const card = (id, keysMac, keysWin, title, why) => {
      const keys = (isMac ? keysMac : keysWin).map(kbd).join("");
      return `<button type="button" class="card" data-preset="${id}" aria-pressed="${S.hotkeyPreset === id}"><div class="keys">${keys}</div><div class="info"><b>${esc(title)}</b><span>${esc(why)}</span></div></button>`;
    };
    return `<h2>${t("set.hotkey")}</h2>
    <p class="lead">Выделите файлы в ${isMac ? "Finder" : "Проводнике"} и нажмите сочетание — меню появится у курсора. Все варианты нажимаются левой рукой.</p>
    ${card("A", ["⌃", "⌥", "⌘", "X"], ["Win", "Shift", "X"], "Вариант A · рекомендуем", isMac ? "Три модификатора — так почти никто не делает: ни Photoshop, ни браузеры, ни IDE, ни Office." : "Сочетания с Win зарезервированы за системой, и программы их почти не занимают. Win+Shift+X Windows не использует.")}
    ${card("B", ["⌃", "⌘", "X"], ["Ctrl", "Win", "X"], "Вариант B · удобнее", "Две клавиши-модификатора. Небольшой риск совпасть с редкой утилитой — приложение предупредит.")}
    ${isMac ? card("C", ["Только", "Finder"], [], "Вариант C · через «Службы macOS»", "Работает только в Finder, конфликтов нет совсем. Сочетание назначается в Системных настройках → Клавиатура → Сочетания клавиш → Службы.") : ""}
    <div class="row"><div class="l"><span>Своё сочетание</span><span class="h" id="hkState">${S.hotkeyPreset === "C" ? "Сочетание задаётся в системных настройках" : `Сейчас: ${prettyAccel(cur).join(" ")}`}</span></div><button class="btn recorder" id="rec" data-rec="false">Записать…</button></div>
    <p class="lead" style="margin-top:12px">${isMac ? "Не используем ⌃+клик — это правый клик в macOS; ⌃⌥Space и ⌃Space переключают раскладку; ⌥⌘C в Finder копирует путь." : "Не используем Win+Space (раскладка), Ctrl+Alt+буквы (в Word это ©, ®, ™, а в европейских раскладках — AltGr), Win+Shift+S/C/T/V (снимок экрана, Copilot, PowerToys)."}</p>`;
  },
  quality() {
    return `<h2>Качество по умолчанию</h2>
    <p class="lead">Можно поменять и для конкретной конвертации — клавиша Tab в меню.</p>
    <div class="row col"><div class="l"><span>Фото: JPG, WEBP, AVIF</span><span class="h">Чем выше, тем лучше картинка и больше файл</span></div>
      <div style="display:flex;gap:12px;align-items:center"><input type="range" min="40" max="100" step="5" value="${S.quality.image}" data-range="quality.image" style="flex:1" aria-label="Качество фото"><span class="mono" id="v-quality.image" style="width:28px;text-align:right">${S.quality.image}</span></div></div>
    ${seg("quality.video", S.quality.video, "Видео", [["high", "Высокое"], ["balanced", "Баланс"], ["small", "Меньше размер"]], "H.264: CRF 18 / 23 / 28. Если кодеки совместимы, видео перепаковывается без потери качества.")}
    ${sel("quality.audioBitrate", S.quality.audioBitrate, "Аудио MP3 / AAC", [[128, "128 кбит/с"], [192, "192 кбит/с"], [256, "256 кбит/с"], [320, "320 кбит/с"]])}
    ${sel("quality.dpi", S.quality.dpi, "PDF и слайды → картинки", [[72, "72 dpi · экран"], [150, "150 dpi"], [300, "300 dpi · печать"]])}
    ${sw("quality.stripMetadata", S.quality.stripMetadata, "Удалять метаданные фото", "EXIF, геопозиция, модель камеры")}
    ${sw("quality.csvBom", S.quality.csvBom, "CSV для Excel (UTF-8 с BOM)", "Кириллица в Excel откроется без «кракозябр»")}`;
  },
  formats() {
    const groups = [
      ["Изображения", ["jpg", "png", "webp", "avif", "heic", "pdf", "tiff", "gif", "ico"]],
      ["Видео и аудио", ["mp4", "mp4_small", "webm", "gif", "mov", "mp3", "m4a", "wav", "flac"]],
      ["Документы и таблицы", ["pdf", "docx", "odt", "txt", "md", "html", "xlsx", "csv", "json"]],
      ["Архивы и книги", ["zip", "7z", "targz", "unpack", "epub", "fb2"]],
    ];
    const label = { mp4_small: "СЖАТЬ MP4", targz: "TAR.GZ", unpack: "РАСПАКОВАТЬ" };
    const fav = S.favorites || [];
    return `<h2>Избранные форматы</h2>
    <p class="lead">Избранное всегда показывается первым в меню. Добавить можно и прямо в меню: звёздочка у строки или ${isMac ? "⌘D" : "Ctrl+D"}.</p>
    ${groups.map(([title, ids]) => `<div class="group-title">${title}</div><div class="chips">${[...new Set(ids)].map((id) => `<button type="button" class="chip" data-fav="${id}" aria-pressed="${fav.includes(id)}">${esc(label[id] || id.toUpperCase())}${fav.includes(id) ? ` <span style="color:var(--accent)">${ICONS.star}</span>` : ""}</button>`).join("")}</div>`).join("")}`;
  },
  look() {
    const a = S.appearance;
    const glass = a.style === "glass";
    return `<h2>${t("set.look")}</h2>
    ${seg("appearance.style", a.style, "Стиль", [["glass", "Liquid Glass"], ["minimal", "Минимализм"]])}
    ${seg("appearance.theme", a.theme, "Тема", [["light", "Светлая"], ["dark", "Тёмная"], ["system", "Как в системе"]])}
    ${glass ? `<div class="row col"><div class="l"><span>Прозрачность стекла</span><span class="h">Даже на максимуме под текстом остаётся плотная подложка — он читается на любом фоне</span></div>
      <div style="display:flex;gap:12px;align-items:center"><input type="range" min="0" max="100" step="5" value="${a.glassTransparency}" data-range="appearance.glassTransparency" style="flex:1" aria-label="Прозрачность стекла" ${a.reduceTransparency ? "disabled" : ""}><span class="mono" id="v-appearance.glassTransparency" style="width:34px;text-align:right">${a.glassTransparency}%</span></div></div>
    ${seg("appearance.blur", a.blur, "Размытие фона", [["soft", "Мягкое"], ["medium", "Среднее"], ["strong", "Сильное"]], isMac ? "Системные материалы macOS: Popover / HUD / Under Window" : "Windows 11: Mica / Acrylic; в Windows 10 — Acrylic")}
    ${sw("appearance.reduceTransparency", a.reduceTransparency, "Уменьшить прозрачность", "Плотные панели без размытия: лучше читаемость, меньше нагрузка на слабые ПК")}` : ""}
    ${sw("appearance.followSystem", a.followSystem, "Учитывать настройки доступности системы", isMac ? "«Уменьшить прозрачность», «Увеличить контраст», «Уменьшить движение»" : "«Эффекты прозрачности», «Контрастные темы», «Анимация в Windows»")}
    ${sw("appearance.motion", a.motion, "Анимации", "Короткие, 120–180 мс. Выключаются и при системном «Уменьшить движение»")}`;
  },
  async integration() {
    const st = await api.invoke("integration_status");
    const mac = st.platform === "mac";
    const line = (ok, text) => `<span class="status ${ok ? "ok" : "muted"}">${ok ? ICONS.check : ""}${esc(text)}</span>`;
    if (mac)
      return `<h2>${t("set.integration")}</h2>
      <p class="lead">Пункт «Конвертировать в…» в контекстном меню Finder (раздел «Быстрые действия») и в Touch Bar.</p>
      <div class="row"><div class="l"><span>Быстрое действие Finder</span><span class="h">Ставится в ~/Library/Services, без прав администратора</span></div>${line(st.finder, st.finder ? "Установлено" : "Не установлено")}<button class="btn" data-int="${st.finder ? "un:" : ""}finder">${st.finder ? "Удалить" : "Установить"}</button></div>
      <div class="row"><div class="l"><span>Разрешение «Автоматизация → Finder»</span><span class="h">Нужно, чтобы по горячей клавише узнать, какие файлы выделены. Morph читает только список выделенных файлов и ничего не меняет в Finder. Accessibility не требуется.</span></div>${line(st.automation === "granted", st.automation === "granted" ? "Разрешено" : "Не запрошено")}<button class="btn" data-int="automation">${st.automation === "granted" ? "Открыть настройки" : "Запросить"}</button></div>`;
    return `<h2>${t("set.integration")}</h2>
    <p class="lead">Пункт «Конвертировать в…» в контекстном меню Проводника.</p>
    <div class="row"><div class="l"><span>Классическое меню</span><span class="h">Windows 10 и «Показать дополнительные параметры» в Windows 11 (Shift+F10). Только для текущего пользователя, без прав администратора.</span></div>${line(st.explorerClassic, st.explorerClassic ? "Установлено" : "Нет")}<button class="btn" data-int="${st.explorerClassic ? "un:" : ""}explorerClassic">${st.explorerClassic ? "Удалить" : "Установить"}</button></div>
    <div class="row"><div class="l"><span>Новое меню Windows 11</span><span class="h">Windows пускает туда только приложения с «идентичностью» (MSIX-пакет). Без платной подписи нужен включённый режим разработчика или доверенный самоподписанный сертификат — установщик всё сделает, но спросит подтверждение.</span></div>${line(st.explorerModern, st.explorerModern ? "Установлено" : "Нет")}<button class="btn" data-int="${st.explorerModern ? "un:" : ""}explorerModern">${st.explorerModern ? "Удалить" : "Включить"}</button></div>`;
  },
  async engines() {
    const list = await api.invoke("engines");
    const order = ["ffmpeg", "magick", "libreoffice", "pandoc", "qpdf", "pdftoppm", "tar", "7zip", "calibre", "sips", "rsvg"];
    const shown = list.filter((e) => order.includes(e.id) && (e.path || e.delivery !== "system" || e.id === "tar")).sort((a, b) => order.indexOf(a.id) - order.indexOf(b.id));
    const row = (e) => {
      const status = e.path ? `<span class="status ok">${ICONS.check}${e.delivery === "bundled" ? "Встроен" : e.delivery === "system" ? "Есть в системе" : "Установлен"}</span>` : `<span class="status ${e.delivery === "download" ? "warn" : "muted"}">${e.delivery === "download" ? `Не установлен · ${e.downloadMb} МБ` : "Не найден"}</span>`;
      const act = e.path ? "" : `<button class="btn ${e.delivery === "download" ? "primary" : ""}" data-install="${e.id}">${e.delivery === "download" ? "Установить" : "Как установить"}</button><button class="btn ghost" data-path="${e.id}">Указать путь…</button>`;
      return `<div class="row ${highlight === e.id ? "hl" : ""}" id="eng-${e.id}"><div class="l"><span style="font-weight:600">${esc(e.title)}</span><span class="h">${esc(e.purpose)}${e.path ? ` · <span class="mono" style="font-size:11px">${esc(e.path)}</span>` : ""}</span></div><div style="display:flex;gap:8px;align-items:center;flex:none">${status}${act}</div></div>`;
    };
    return `<h2>${t("set.engines")}</h2>
    <p class="lead">Всё работает на этом компьютере, без интернета. Тяжёлые компоненты ставятся только когда понадобятся. Уже установленные LibreOffice и Calibre находятся автоматически.</p>
    ${shown.map(row).join("")}
    <div style="margin-top:14px"><button class="btn" id="recheck">Проверить снова</button></div>`;
  },
  async history() {
    const list = await api.invoke("history");
    const when = (ms) => {
      const d = new Date(ms);
      const today = new Date();
      const hm = d.toLocaleTimeString("ru-RU", { hour: "2-digit", minute: "2-digit" });
      if (d.toDateString() === today.toDateString()) return `сегодня, ${hm}`;
      const y = new Date(today - 864e5);
      if (d.toDateString() === y.toDateString()) return `вчера, ${hm}`;
      return d.toLocaleDateString("ru-RU");
    };
    return `<h2>${t("set.history")}</h2>
    ${list.length ? list.map((h) => `<div class="row"><div class="l"><span>${esc(h.name)}</span><span class="h" style="display:flex;gap:6px;align-items:center"><span class="ext sm">${esc(h.src)}</span>→<span class="ext sm">${esc(h.dst)}</span> · ${when(h.time)}</span></div><button class="link" data-reveal="${esc(h.path)}">Показать в папке</button></div>`).join("") : `<p class="lead">Пока пусто.</p>`}
    ${list.length ? `<div style="margin-top:12px"><button class="link" id="clearHistory" style="color:var(--muted)">Очистить историю</button></div>` : ""}`;
  },
};

async function render() {
  $("#nav").innerHTML =
    TABS.map((id) => `<button type="button" data-tab="${id}" aria-current="${id === tab ? "page" : "false"}">${esc(t("set." + id))}</button>`).join("") + `<div class="foot">${esc(t("set.footer"))}</div>`;
  $("#main").innerHTML = await views[tab]();
  if (highlight) document.getElementById(`eng-${highlight}`)?.scrollIntoView({ block: "center" });
}

// ---------- События ----------
document.addEventListener("click", async (e) => {
  const b = e.target.closest("button");
  if (!b) return;
  const d = b.dataset;
  if (d.tab) {
    tab = d.tab;
    highlight = null;
    await render();
    $("#main").focus();
  } else if (d.sw) {
    const v = !get(d.sw);
    await save(patchOf(d.sw, v));
    b.setAttribute("aria-checked", String(v));
    if (d.sw === "appearance.reduceTransparency") render();
  } else if (d.seg) {
    await save(patchOf(d.seg, d.val));
    render();
  } else if (d.preset) {
    const accel = PRESETS[d.preset];
    if (accel) {
      const chk = await api.invoke("check_hotkey", { accel });
      if (!chk.ok) return showHk(`Не получилось: ${chk.reason}`, true);
    }
    await save({ hotkeyPreset: d.preset, hotkey: accel });
    render();
  } else if (d.fav) {
    const fav = new Set(S.favorites || []);
    fav.has(d.fav) ? fav.delete(d.fav) : fav.add(d.fav);
    await save({ favorites: [...fav] });
    render();
  } else if (d.install) {
    b.disabled = true;
    b.textContent = "Устанавливаю…";
    const r = await api.invoke("install_engine", { id: d.install });
    if (!r.ok && r.url) await api.invoke("open_url", { url: r.url });
    render();
  } else if (d.path) {
    const p = await api.invoke("pick_engine_path", { id: d.path });
    if (p) await api.invoke("set_engine_path", { id: d.path, path: p });
    render();
  } else if (d.int) {
    const un = d.int.startsWith("un:");
    const kind = d.int.replace("un:", "");
    const r = await api.invoke(un ? "uninstall_integration" : "install_integration", { kind });
    if (r && r.message && r.message !== "Готово") alertInline(r.message);
    render();
  } else if (d.reveal) await api.invoke("reveal", { path: d.reveal });
  else if (b.id === "pickFolder") {
    const f = await api.invoke("pick_folder");
    if (f) await save({ saveFolder: f });
    render();
  } else if (b.id === "recheck") render();
  else if (b.id === "clearHistory") {
    await api.invoke("clear_history");
    render();
  } else if (b.id === "rec") startRecording(b);
});

document.addEventListener("input", async (e) => {
  const el = e.target;
  if (el.dataset.range) {
    const v = Number(el.value);
    const out = document.getElementById(`v-${el.dataset.range}`);
    if (out) out.textContent = el.dataset.range.startsWith("appearance") ? `${v}%` : v;
    await save(patchOf(el.dataset.range, v));
  }
});
document.addEventListener("change", async (e) => {
  const el = e.target;
  if (el.dataset.sel) {
    const v = /^\d+$/.test(el.value) ? Number(el.value) : el.value;
    await save(patchOf(el.dataset.sel, v));
    if (el.dataset.sel === "language") {
      setLang(v);
      render();
    }
  }
});

function alertInline(msg) {
  const p = document.createElement("p");
  p.className = "lead warn";
  p.setAttribute("role", "status");
  p.textContent = msg;
  $("#main").prepend(p);
}
function showHk(msg, bad) {
  const el = $("#hkState");
  if (el) {
    el.textContent = msg;
    el.className = `h ${bad ? "err" : "ok"}`;
  }
}

// Запись своего сочетания
function startRecording(btn) {
  btn.dataset.rec = "true";
  btn.textContent = "Нажмите сочетание…";
  const onKey = async (e) => {
    e.preventDefault();
    if (e.key === "Escape") return finish();
    if (["Shift", "Control", "Alt", "Meta"].includes(e.key)) return;
    const mods = [];
    if (e.ctrlKey) mods.push("Control");
    if (e.altKey) mods.push("Alt");
    if (e.shiftKey) mods.push("Shift");
    if (e.metaKey) mods.push("Super");
    if (mods.length < 2 && !/^F\d+$/.test(e.code)) {
      showHk("Нужно минимум два модификатора — иначе сочетание будет мешать в программах", true);
      return;
    }
    const key = e.code.replace(/^Key/, "").replace(/^Digit/, "");
    const accel = [...mods, key].join("+");
    const chk = await api.invoke("check_hotkey", { accel });
    if (!chk.ok) {
      showHk(`${prettyAccel(accel).join(" ")} — ${chk.reason}`, true);
      return finish();
    }
    await save({ hotkey: accel, hotkeyPreset: "custom" });
    finish();
    render();
  };
  const finish = () => {
    window.removeEventListener("keydown", onKey, true);
    btn.dataset.rec = "false";
    btn.textContent = "Записать…";
  };
  window.addEventListener("keydown", onKey, true);
}

api.listen("settings:open-tab", ({ tab: tb, highlight: hl }) => {
  if (TABS.includes(tb)) tab = tb;
  highlight = hl || null;
  render();
});
api.listen("engines:changed", () => tab === "engines" && render());

await render();
