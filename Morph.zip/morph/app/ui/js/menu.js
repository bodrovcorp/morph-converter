// Меню «Конвертировать в…»: поиск при наборе, стрелки, Enter, Tab — параметры, Esc — закрыть.
import { api, initAppearance, esc, ICONS, fileGlyph } from "./bridge.js";
import { t, setLang, fmtBytes, swapLayout, modKey } from "./i18n.js";

const $ = (s) => document.querySelector(s);
const state = {
  files: [],
  offers: [],
  settings: null,
  q: "",
  sel: 0,
  more: false,
  rows: [],
  opts: {},
  conflict: null,
  busy: false,
};

const settings = await initAppearance();
state.settings = settings;
setLang(settings.language);
$("#search-icon").innerHTML = ICONS.search;
$("#q").placeholder = t("menu.search");

function defaultsFor() {
  const q = state.settings.quality || {};
  return {
    quality: q.image ?? 85,
    maxSide: 0,
    stripMetadata: !!q.stripMetadata,
    videoQuality: q.video || "balanced",
    height: 0,
    noAudio: false,
    gifFps: 12,
    gifWidth: 480,
    audioBitrate: q.audioBitrate ?? 192,
    dpi: q.dpi ?? 150,
    csvBom: q.csvBom !== false,
  };
}

function load(data) {
  state.files = data.files || [];
  state.offers = data.offers || [];
  state.q = "";
  state.sel = 0;
  state.more = false;
  state.conflict = null;
  state.busy = false;
  state.opts = defaultsFor();
  $("#q").value = "";
  render();
  requestAnimationFrame(() => $("#q").focus());
  const m = $("#menu");
  m.classList.remove("pop");
  void m.offsetWidth;
  m.classList.add("pop");
}

function matches(o, q) {
  const hay = `${o.id} ${o.ext} ${o.title} ${o.desc} ${o.kindTitle}`.toLowerCase();
  return hay.includes(q) || hay.includes(swapLayout(q));
}

/** Строит список строк: [{type:'label'|'offer'|'more', …}] */
function buildRows() {
  const fav = state.settings.favorites || [];
  const q = state.q.trim().toLowerCase();
  const rows = [];
  if (q) {
    const found = state.offers.filter((o) => matches(o, q));
    if (found.length) rows.push({ type: "label", text: t("menu.found") });
    found.forEach((o) => rows.push({ type: "offer", o }));
    return rows;
  }
  const favs = fav.map((id) => state.offers.find((o) => o.id === id)).filter(Boolean);
  const rest = state.offers.filter((o) => !fav.includes(o.id));
  const pop = rest.filter((o) => o.popular);
  const more = rest.filter((o) => !o.popular);
  if (favs.length) {
    rows.push({ type: "label", text: t("menu.fav") });
    favs.forEach((o) => rows.push({ type: "offer", o }));
  }
  if (pop.length) {
    rows.push({ type: "label", text: t("menu.popular") });
    pop.forEach((o) => rows.push({ type: "offer", o }));
  }
  if (more.length) {
    if (!state.more) rows.push({ type: "more", n: more.length });
    else {
      // «Ещё» — с подзаголовками по типу результата
      let last = null;
      more.forEach((o) => {
        if (o.kindTitle !== last) {
          rows.push({ type: "label", text: `${t("menu.more")} · ${o.kindTitle}` });
          last = o.kindTitle;
        }
        rows.push({ type: "offer", o });
      });
    }
  }
  return rows;
}

function offerRows() {
  return state.rows.filter((r) => r.type === "offer" || r.type === "more");
}

function badge(o) {
  if (!o.ext) return "DIR";
  return o.ext.toUpperCase().replace("TAR.GZ", "TGZ");
}

function renderHead() {
  const f = state.files;
  if (!f.length) {
    $("#head").innerHTML = `${fileGlyph("")}<div><div class="name">${esc(t("menu.empty.title"))}</div><div class="meta">Morph</div></div>`;
    return;
  }
  const total = f.reduce((s, x) => s + (x.size || 0), 0);
  const kinds = new Set(f.map((x) => x.formatTitle));
  const name = f.length === 1 ? f[0].name : t("menu.files", f.length);
  const meta = f.length === 1 ? `${f[0].kindTitle} ${f[0].formatTitle} · ${fmtBytes(total)}` : `${kinds.size === 1 ? f[0].kindTitle + " " + f[0].formatTitle : t("menu.mixed")} · ${fmtBytes(total)}`;
  $("#head").innerHTML = `${fileGlyph(f[0].kind)}<div><div class="name" title="${esc(name)}">${esc(name)}</div><div class="meta">${esc(meta)}</div></div>`;
}

function renderList() {
  const list = $("#list");
  if (!state.files.length) {
    list.innerHTML = `<div class="m-dropzone" id="drop"><div class="muted" style="line-height:1.5">${esc(t("menu.empty.text"))}</div><button class="btn primary" id="pick">${esc(t("menu.pick"))}</button></div>`;
    $("#pick").onclick = pick;
    return;
  }
  state.rows = buildRows();
  const sel = Math.min(state.sel, Math.max(0, offerRows().length - 1));
  state.sel = sel;
  let i = 0;
  let html = "";
  const fav = state.settings.favorites || [];
  for (const r of state.rows) {
    if (r.type === "label") {
      html += `<div class="m-label" role="presentation">${esc(r.text)}</div>`;
      continue;
    }
    const idx = i++;
    const on = idx === sel;
    if (r.type === "more") {
      html += `<button type="button" class="m-row m-morebtn" role="option" id="row-${idx}" data-i="${idx}" aria-selected="${on}">${esc(t("menu.moreN", r.n))} ${ICONS.chev}</button>`;
      continue;
    }
    const o = r.o;
    const missing = o.missing && o.missing.length;
    const isFav = fav.includes(o.id);
    const key = idx < 9 && !state.q ? `${modKey}${idx + 1}` : "";
    html += `<div class="m-row" role="option" id="row-${idx}" data-i="${idx}" aria-selected="${on}" ${missing ? 'aria-disabled="true"' : ""} title="${esc(o.desc)}">
      <span class="ext">${esc(badge(o))}</span>
      <span class="t">${o.title.toUpperCase() === badge(o) ? `<span class="title">${esc(o.desc)}</span>` : `<span class="title">${esc(o.title)}</span><span class="desc">${esc(o.desc)}</span>`}</span>
      ${missing ? `<span class="need">${esc(t("menu.needs", o.missingTitles[0]))}</span>` : ""}
      <button type="button" class="star" tabindex="-1" aria-pressed="${isFav}" aria-label="${esc(isFav ? t("menu.unstar") : t("menu.star"))}" data-star="${esc(o.id)}">${isFav ? ICONS.star : ICONS.starOff}</button>
      ${key && !missing ? `<span class="key">${key}</span>` : ""}
    </div>`;
  }
  if (!i) html = `<div class="m-empty">${esc(t("menu.nothing"))}</div>`;
  list.innerHTML = html;
  $("#q").setAttribute("aria-activedescendant", `row-${sel}`);
  const el = $(`#row-${sel}`);
  if (el) el.scrollIntoView({ block: "nearest" });
}

function current() {
  const r = offerRows()[state.sel];
  return r && r.type === "offer" ? r.o : null;
}

function optRow(label, control) {
  return `<div class="m-opt"><span>${esc(label)}</span>${control}</div>`;
}
function selectCtl(name, items, value) {
  return `<select class="select" data-opt="${name}">${items.map(([v, l]) => `<option value="${v}" ${String(v) === String(value) ? "selected" : ""}>${esc(l)}</option>`).join("")}</select>`;
}
function switchCtl(name, value, label) {
  return `<button type="button" class="switch sm" role="switch" aria-label="${esc(label)}" aria-checked="${!!value}" data-opt="${name}"></button>`;
}

function renderOpts() {
  const o = current();
  const box = $("#opts");
  if (!o || !o.options || !o.options.length || state.conflict) {
    box.hidden = true;
    box.innerHTML = "";
    return;
  }
  const v = state.opts;
  let h = "";
  for (const k of o.options) {
    if (k === "quality") h += optRow(t("opt.quality"), `<span style="display:flex;align-items:center;gap:10px"><input type="range" min="10" max="100" step="5" value="${v.quality}" data-opt="quality" aria-label="${esc(t("opt.quality"))}"><span class="val">${v.quality}</span></span>`);
    if (k === "resize") h += optRow(t("opt.resize"), selectCtl("maxSide", [[0, t("opt.resize.none")], [3840, "до 3840 px"], [2560, "до 2560 px"], [1920, "до 1920 px"], [1280, "до 1280 px"], [800, "до 800 px"]], v.maxSide));
    if (k === "stripMetadata") h += optRow(t("opt.strip"), switchCtl("stripMetadata", v.stripMetadata, t("opt.strip")));
    if (k === "videoQuality")
      h += optRow(t("opt.vq"), `<div class="seg" role="group" aria-label="${esc(t("opt.vq"))}">${["high", "balanced", "small"].map((q) => `<button type="button" data-opt="videoQuality" data-val="${q}" aria-pressed="${v.videoQuality === q}">${esc(t("opt.vq." + q))}</button>`).join("")}</div>`);
    if (k === "height") h += optRow(t("opt.height"), selectCtl("height", [[0, t("opt.resize.none")], [2160, "4K · 2160p"], [1080, "1080p"], [720, "720p"], [480, "480p"]], v.height));
    if (k === "noAudio") h += optRow(t("opt.noAudio"), switchCtl("noAudio", v.noAudio, t("opt.noAudio")));
    if (k === "gif") {
      h += optRow(t("opt.gifFps"), selectCtl("gifFps", [[8, "8"], [12, "12"], [15, "15"], [24, "24"]], v.gifFps));
      h += optRow(t("opt.gifWidth"), selectCtl("gifWidth", [[320, "320 px"], [480, "480 px"], [640, "640 px"], [800, "800 px"]], v.gifWidth));
    }
    if (k === "audioBitrate") h += optRow(t("opt.bitrate"), selectCtl("audioBitrate", [[96, "96 кбит/с"], [128, "128 кбит/с"], [192, "192 кбит/с"], [256, "256 кбит/с"], [320, "320 кбит/с"]], v.audioBitrate));
    if (k === "dpi") h += optRow(t("opt.dpi"), selectCtl("dpi", [[72, "72 dpi · экран"], [150, "150 dpi"], [300, "300 dpi · печать"]], v.dpi));
    if (k === "csvBom") h += optRow(t("opt.bom"), switchCtl("csvBom", v.csvBom, t("opt.bom")));
  }
  box.innerHTML = h;
  box.hidden = false;
}

function renderFoot() {
  const foot = $("#foot");
  if (state.conflict) {
    foot.innerHTML = `<div class="m-conflict" role="alertdialog" aria-label="${esc(t("menu.conflict", state.conflict.name))}">
      <div>${esc(t("menu.conflict", state.conflict.name))}</div>
      <div class="row"><button class="btn" data-c="cancel">${esc(t("menu.cancel"))}</button><button class="btn" data-c="overwrite">${esc(t("menu.replace"))}</button><button class="btn primary" data-c="suffix">${esc(t("menu.keepBoth"))}</button></div></div>`;
    foot.querySelector('[data-c="suffix"]').focus();
    return;
  }
  const o = current();
  if (!state.files.length) {
    foot.innerHTML = `<span class="hints">Esc</span>`;
    return;
  }
  const label = o ? t("menu.convert", o.ext ? o.title : o.title) : "";
  foot.innerHTML = `<span class="hints">${esc(t("menu.hints"))}</span>${o ? `<button class="btn primary" id="go" ${state.busy ? "disabled" : ""}>${esc(label)} ↵</button>` : ""}`;
  const go = $("#go");
  if (go) go.onclick = () => convert();
}

async function sizeWindow() {
  const margin = document.documentElement.dataset.native === "true" ? 0 : 48;
  const h = Math.ceil($("#menu").getBoundingClientRect().height) + margin;
  try {
    await api.invoke("resize_menu", { height: h });
  } catch {}
}

function render() {
  renderHead();
  renderList();
  renderOpts();
  renderFoot();
  sizeWindow();
}

function move(d) {
  const n = offerRows().length;
  if (!n) return;
  state.sel = (state.sel + d + n) % n;
  renderList();
  renderOpts();
  renderFoot();
  sizeWindow();
}

async function toggleFav(id) {
  const fav = new Set(state.settings.favorites || []);
  fav.has(id) ? fav.delete(id) : fav.add(id);
  state.settings.favorites = [...fav];
  await api.invoke("set_settings", { settings: state.settings });
  render();
}

async function close() {
  await api.invoke("hide_menu");
}

async function convert(conflict) {
  const row = offerRows()[state.sel];
  if (!row) return;
  if (row.type === "more") {
    state.more = true;
    render();
    return;
  }
  const o = row.o;
  if (o.missing && o.missing.length) {
    await api.invoke("open_settings", { tab: "engines", highlight: o.missing[0] });
    await close();
    return;
  }
  if (state.busy) return;
  state.busy = true;
  const options = { ...state.opts };
  if (!options.maxSide) delete options.maxSide;
  if (!options.height) delete options.height;
  const res = await api.invoke("convert", { paths: state.files.map((f) => f.path), target: o.id, options, conflict: conflict || null });
  state.busy = false;
  if (res && res.conflict) {
    state.conflict = res.conflict;
    render();
    return;
  }
  await close();
}

async function pick() {
  const paths = await api.invoke("pick_files");
  if (paths && paths.length) load(await api.invoke("menu_data", { paths }));
}

// ---------- События ----------
$("#q").addEventListener("input", (e) => {
  state.q = e.target.value;
  state.sel = 0;
  render();
});

document.addEventListener("keydown", (e) => {
  if (state.conflict) {
    if (e.key === "Escape") {
      state.conflict = null;
      render();
      e.preventDefault();
    }
    return;
  }
  const inOpts = e.target.closest && e.target.closest("#opts");
  const mod = e.metaKey || e.ctrlKey;
  if (e.key === "ArrowDown" && !inOpts) {
    move(1);
    e.preventDefault();
  } else if (e.key === "ArrowUp" && !inOpts) {
    move(-1);
    e.preventDefault();
  } else if (e.key === "ArrowRight" && !inOpts && offerRows()[state.sel]?.type === "more") {
    state.more = true;
    render();
    e.preventDefault();
  } else if (e.key === "Enter" && !(inOpts && e.target.tagName === "BUTTON")) {
    convert();
    e.preventDefault();
  } else if (e.key === "Escape") {
    e.preventDefault();
    if (inOpts) $("#q").focus();
    else if (state.q) {
      state.q = "";
      $("#q").value = "";
      render();
    } else close();
  } else if (e.key === "Tab" && !e.shiftKey && !inOpts) {
    const first = $("#opts:not([hidden]) [data-opt]");
    if (first) {
      first.focus();
      e.preventDefault();
    }
  } else if (mod && /^[1-9]$/.test(e.key)) {
    const idx = Number(e.key) - 1;
    if (idx < offerRows().length) {
      state.sel = idx;
      convert();
    }
    e.preventDefault();
  } else if (mod && (e.key === "d" || e.key === "в")) {
    const o = current();
    if (o) toggleFav(o.id);
    e.preventDefault();
  } else if (e.key.length === 1 && !mod && document.activeElement !== $("#q") && !inOpts) {
    // набор текста в любом месте — в поиск
    $("#q").focus();
  }
});

$("#list").addEventListener("click", (e) => {
  const star = e.target.closest("[data-star]");
  if (star) {
    toggleFav(star.dataset.star);
    e.stopPropagation();
    return;
  }
  const row = e.target.closest("[data-i]");
  if (!row) return;
  state.sel = Number(row.dataset.i);
  convert();
});
$("#list").addEventListener("mousemove", (e) => {
  const row = e.target.closest("[data-i]");
  if (row && Number(row.dataset.i) !== state.sel) {
    state.sel = Number(row.dataset.i);
    document.querySelectorAll(".m-row[aria-selected]").forEach((el) => el.setAttribute("aria-selected", String(Number(el.dataset.i) === state.sel)));
    $("#q").setAttribute("aria-activedescendant", `row-${state.sel}`);
    renderOpts();
    renderFoot();
  }
});

$("#opts").addEventListener("input", (e) => {
  const k = e.target.dataset.opt;
  if (!k) return;
  state.opts[k] = e.target.type === "range" || e.target.tagName === "SELECT" ? Number(e.target.value) : e.target.value;
  if (e.target.type === "range") e.target.nextElementSibling.textContent = e.target.value;
});
$("#opts").addEventListener("click", (e) => {
  const b = e.target.closest("[data-opt]");
  if (!b || b.tagName !== "BUTTON") return;
  const k = b.dataset.opt;
  if (b.getAttribute("role") === "switch") state.opts[k] = !state.opts[k];
  else if (b.dataset.val) state.opts[k] = b.dataset.val;
  renderOpts();
  const again = document.querySelector(`#opts [data-opt="${k}"]${b.dataset.val ? `[data-val="${b.dataset.val}"]` : ""}`);
  if (again) again.focus();
});

$("#foot").addEventListener("click", (e) => {
  const c = e.target.closest("[data-c]");
  if (!c) return;
  if (c.dataset.c === "cancel") {
    state.conflict = null;
    render();
  } else convert(c.dataset.c);
});

// Клик мимо меню (в прозрачной области окна) — закрыть. Потерю фокуса окна обрабатывает оболочка.
document.addEventListener("mousedown", (e) => {
  if (!e.target.closest("#menu")) close();
});

// Перетаскивание файлов на пустое меню (в Tauri приходит событие с путями)
document.addEventListener("dragover", (e) => {
  e.preventDefault();
  $("#drop")?.classList.add("drag");
});
document.addEventListener("dragleave", () => $("#drop")?.classList.remove("drag"));
document.addEventListener("drop", (e) => e.preventDefault());

api.listen("menu:open", (data) => load(data));
api.listen("menu:drop", async (paths) => load(await api.invoke("menu_data", { paths })));
api.listen("settings:changed", (s) => {
  state.settings = s;
  setLang(s.language);
});

load(await api.invoke("initial_menu"));
window.__menuState = state;
