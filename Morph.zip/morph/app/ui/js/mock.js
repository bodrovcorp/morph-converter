// Имитация бэкенда для просмотра в браузере и UI-тестов (Playwright).
// Цели берутся из настоящего ядра (mock-data.js), задачи «выполняются» по таймеру.
import { SAMPLE_OFFERS } from "./mock-data.js";

const listeners = {};
function emit(ev, payload) {
  (listeners[ev] || []).forEach((cb) => cb(payload));
  // Окна в iframe предпросмотра слушают друг друга через родителя
  try {
    if (window.parent !== window) window.parent.postMessage({ morph: ev, payload }, "*");
  } catch {}
}
window.addEventListener("message", (e) => {
  if (e.data && e.data.morph && e.source !== window) (listeners[e.data.morph] || []).forEach((cb) => cb(e.data.payload));
});

const params = new URLSearchParams(location.search);
const KEY = "morph-mock-settings";
const defaults = {
  autostart: true,
  notify: true,
  language: "ru",
  hotkeyPreset: "A",
  hotkey: /Mac/.test(navigator.platform) ? "Control+Alt+Super+X" : "Super+Shift+X",
  saveMode: "beside",
  saveFolder: null,
  conflict: "suffix",
  quality: { image: 85, video: "balanced", audioBitrate: 192, stripMetadata: false, csvBom: true, dpi: 150 },
  favorites: ["jpg", "pdf", "mp4", "mp3"],
  appearance: { style: params.get("style") || "glass", theme: params.get("theme") || "light", glassTransparency: 50, blur: "medium", reduceTransparency: params.get("reduce") === "1", followSystem: true, motion: true },
  progressDelayMs: 1500,
};
let settings;
try {
  settings = JSON.parse(sessionStorage.getItem(KEY)) || structuredClone(defaults);
} catch {
  settings = structuredClone(defaults);
}
if (params.get("style")) settings.appearance.style = params.get("style");
if (params.get("theme")) settings.appearance.theme = params.get("theme");

const SAMPLES = {
  heic: [{ path: "/Users/me/Загрузки/IMG_2048.HEIC", name: "IMG_2048.HEIC", format: "heic", formatTitle: "HEIC", kind: "image", kindTitle: "Изображение", size: 3565158 }],
  mov: [{ path: "/Users/me/Видео/Отпуск_2026.mov", name: "Отпуск_2026.mov", format: "mov", formatTitle: "MOV", kind: "video", kindTitle: "Видео", size: 1932735283 }],
  docx: [{ path: "/Users/me/Документы/Отчёт за квартал.docx", name: "Отчёт за квартал.docx", format: "docx", formatTitle: "DOCX", kind: "document", kindTitle: "Документ", size: 48211 }],
  pdf: [
    { path: "/Users/me/Документы/глава 1.pdf", name: "глава 1.pdf", format: "pdf", formatTitle: "PDF", kind: "document", kindTitle: "Документ", size: 912000 },
    { path: "/Users/me/Документы/глава 2.pdf", name: "глава 2.pdf", format: "pdf", formatTitle: "PDF", kind: "document", kindTitle: "Документ", size: 700000 },
  ],
  csv: [{ path: "/Users/me/Выгрузка 1251.csv", name: "Выгрузка 1251.csv", format: "csv", formatTitle: "CSV", kind: "spreadsheet", kindTitle: "Таблица", size: 2048 }],
  none: [],
};

function offersFor(files) {
  if (!files.length) return [];
  const id = files[0].format;
  let offers = structuredClone(SAMPLE_OFFERS[id] || SAMPLE_OFFERS.zip);
  if (id === "docx") offers.forEach((o) => o.id === "md" && (o.missing = ["pandoc"], o.missingTitles = ["Pandoc"]));
  if (id === "docx") offers.forEach((o) => o.id === "odt" && (o.missing = ["libreoffice"], o.missingTitles = ["LibreOffice"]));
  if (files.length > 1 && id === "pdf") {
    offers.unshift({ id: "merge_pdf", converter: "pdf", ext: "pdf", title: "Объединить", desc: "Все PDF — в один файл по порядку", popular: true, rank: 0, kind: "document", kindTitle: "Документ", missing: [], missingTitles: [], options: [], combine: true });
  }
  return offers;
}

const jobs = new Map();
let nextId = 100;
const history = [
  { name: "IMG_2048.jpg", src: "HEIC", dst: "JPG", path: "/Users/me/Загрузки/IMG_2048.jpg", time: Date.now() - 600000 },
  { name: "Отпуск_2026.mp4", src: "MOV", dst: "MP4", path: "/Users/me/Видео/Отпуск_2026.mp4", time: Date.now() - 1800000 },
  { name: "Бюджет 2026 (1).xlsx", src: "CSV", dst: "XLSX", path: "/Users/me/Бюджет 2026 (1).xlsx", time: Date.now() - 86400000 },
];

function makeJob(name, srcTitle, target, targetTitle, extra = {}) {
  const j = { id: nextId++, batch: extra.batch ?? nextId, name, count: 1, inputs: [`/Users/me/${name}`], target, targetTitle, srcTitle, status: "queued", progress: 0, eta: null, outputs: [], error: null, details: "", srcBytes: extra.srcBytes || 3400000, outBytes: 0, created: Date.now(), elapsed: 0, ...extra };
  jobs.set(j.id, j);
  emit("job", j);
  return j;
}

function simulate(j, seconds, outcome = "done") {
  j.status = "running";
  const start = Date.now();
  const tick = () => {
    if (j.status !== "running") return;
    const el = (Date.now() - start) / 1000;
    j.progress = Math.min(0.999, el / seconds);
    j.elapsed = el;
    j.eta = j.progress > 0.03 ? (el * (1 - j.progress)) / j.progress : null;
    if (el >= seconds) {
      if (outcome === "fail") {
        j.status = "failed";
        j.error = "Не удалось открыть файл: он повреждён или сохранён в неподдерживаемом варианте формата.";
        j.details = "$ pdftoppm -r 150 -png in.pdf out/in\nSyntax Error: Couldn't read xref table\npdftoppm завершился с кодом Some(1)";
      } else {
        j.status = "done";
        j.progress = 1;
        j.outBytes = Math.round(j.srcBytes * 0.3);
        j.outputs = [`/Users/me/${j.name.replace(/\.[^.]+$/, "")}.${j.target.split("_")[0]}`];
      }
      j.eta = null;
      emit("job", { ...j });
      return;
    }
    emit("job", { ...j });
    setTimeout(tick, 200);
  };
  tick();
}

function demoJobs() {
  const a = makeJob("Отпуск_2026.mov", "MOV", "mp4", "MP4", { srcBytes: 1932735283 });
  simulate(a, Number(params.get("slow") || 90));
  const b = makeJob("Отчёт за квартал.docx", "DOCX", "pdf", "PDF", { srcBytes: 48211, waiting: "LibreOffice" });
  const c = makeJob("IMG_2048.HEIC", "HEIC", "jpg", "JPG");
  c.status = "done";
  c.progress = 1;
  c.outBytes = 1150000;
  c.outputs = ["/Users/me/Загрузки/IMG_2048.jpg"];
  const d = makeJob("scan_old.pdf", "PDF", "png_pages", "PNG");
  d.status = "failed";
  d.error = "Не удалось открыть файл: он повреждён или сохранён в неподдерживаемом варианте формата.";
  d.details = "$ pdftoppm -r 150 -png in.pdf out/in\nSyntax Error: Couldn't read xref table\npdftoppm завершился с кодом Some(1)";
  [b, c, d].forEach((j) => emit("job", { ...j }));
  // пакет из 26 фото
  const batch = 7777;
  for (let i = 1; i <= 26; i++) {
    const j = makeJob(`кадр ${String(i).padStart(2, "0")}.png`, "PNG", "jpg", "JPG", { batch });
    if (i <= 17) {
      j.status = "done";
      j.progress = 1;
      j.outputs = [`/Users/me/кадр ${i}.jpg`];
    } else if (i === 18) simulate(j, 30);
  }
}

const engines = [
  { id: "ffmpeg", title: "FFmpeg", purpose: "Видео, аудио, GIF", delivery: "bundled", downloadMb: 0, path: "/Applications/Morph.app/Contents/MacOS/ffmpeg" },
  { id: "magick", title: "ImageMagick", purpose: "Фото: HEIC, RAW, SVG, ICO, WEBP, AVIF", delivery: "bundled", downloadMb: 0, path: "/Applications/Morph.app/Contents/MacOS/magick" },
  { id: "libreoffice", title: "LibreOffice", purpose: "Word, Excel, PowerPoint ↔ PDF", delivery: "download", downloadMb: 350, path: null },
  { id: "pandoc", title: "Pandoc", purpose: "Markdown, HTML, EPUB, FB2", delivery: "download", downloadMb: 150, path: "/Users/me/Library/Application Support/Morph/engines/pandoc" },
  { id: "qpdf", title: "qpdf", purpose: "Объединение и сжатие PDF", delivery: "bundled", downloadMb: 0, path: "/Applications/Morph.app/Contents/MacOS/qpdf" },
  { id: "pdftoppm", title: "Poppler pdftoppm", purpose: "PDF → картинки и текст", delivery: "bundled", downloadMb: 0, path: "/Applications/Morph.app/Contents/MacOS/pdftoppm" },
  { id: "tar", title: "bsdtar", purpose: "Архивы ZIP, 7Z, TAR", delivery: "system", downloadMb: 0, path: "/usr/bin/tar" },
  { id: "calibre", title: "Calibre", purpose: "MOBI, AZW3 (необязательно)", delivery: "optional", downloadMb: 200, path: null },
];

const handlers = {
  get_settings: () => structuredClone(settings),
  set_settings: ({ settings: s }) => {
    settings = s;
    sessionStorage.setItem(KEY, JSON.stringify(s));
    emit("settings:changed", s);
    return { ok: true };
  },
  system_appearance: () => ({ reduceTransparency: false, reduceMotion: false, highContrast: false, dark: false }),
  menu_data: ({ paths }) => {
    const files = paths.map((p) => {
      const name = p.split("/").pop();
      const ext = name.split(".").pop().toLowerCase();
      return { path: p, name, format: ext, formatTitle: ext.toUpperCase(), kind: "image", kindTitle: "Изображение", size: 1000 };
    });
    return { files, unknown: [], offers: offersFor(files) };
  },
  initial_menu: () => {
    const files = SAMPLES[params.get("sample") || "heic"] || SAMPLES.heic;
    return { files, unknown: [], offers: offersFor(files) };
  },
  pick_files: () => ["/Users/me/Загрузки/IMG_2048.HEIC"],
  convert: ({ paths, target, conflict }) => {
    if (settings.conflict === "ask" && !conflict && target === "jpg") return { conflict: { name: "IMG_2048.jpg" } };
    const offers = offersFor(handlers.menu_data({ paths }).files);
    const o = offers.find((x) => x.id === target) || { title: target.toUpperCase() };
    const j = makeJob(paths[0].split("/").pop(), "HEIC", target, o.title);
    simulate(j, 2.5);
    window.__lastConvert = { paths, target, conflict };
    return { batch: j.batch };
  },
  cancel: ({ id }) => {
    for (const j of jobs.values())
      if (j.id === id || j.batch === id) {
        if (j.status === "running" || j.status === "queued") {
          j.status = "cancelled";
          j.error = "Конвертация отменена.";
          j.eta = null;
          emit("job", { ...j });
        }
      }
  },
  cancel_all: () => {
    for (const j of jobs.values()) handlers.cancel({ id: j.id });
  },
  retry: ({ id }) => {
    const j = jobs.get(id);
    if (j) {
      j.error = null;
      j.progress = 0;
      simulate(j, 3);
    }
  },
  clear_finished: () => {
    for (const [id, j] of jobs) if (["done", "failed", "cancelled"].includes(j.status)) jobs.delete(id);
    emit("jobs:reset", [...jobs.values()]);
  },
  jobs: () => [...jobs.values()].map((j) => ({ ...j })),
  reveal: ({ path }) => (window.__revealed = path),
  hide_menu: () => {
    window.__menuHidden = (window.__menuHidden || 0) + 1;
    emit("menu:hidden", {});
  },
  resize_menu: ({ height }) => (window.__menuHeight = height),
  hide_progress: () => (window.__progressHidden = true),
  open_settings: ({ tab }) => (window.__openSettings = tab || true),
  engines: () => structuredClone(engines),
  install_engine: ({ id }) => {
    const e = engines.find((x) => x.id === id);
    return new Promise((res) =>
      setTimeout(() => {
        if (e) e.path = `/Users/me/Library/Application Support/Morph/engines/${id}`;
        emit("engines:changed", {});
        res({ ok: true, message: "Установлено" });
      }, 1200),
    );
  },
  set_engine_path: ({ id, path }) => {
    const e = engines.find((x) => x.id === id);
    if (e) e.path = path;
    return { ok: true };
  },
  pick_engine_path: () => "/opt/homebrew/bin/soffice",
  history: () => structuredClone(history),
  clear_history: () => {
    history.length = 0;
  },
  check_hotkey: ({ accel }) => {
    // порядок модификаторов не важен
    const norm = (a) => { const p = a.split("+"); const k = p.pop(); return [...p.sort(), k].join("+"); };
    const busy = ["Super+Shift+S", "Control+Alt+Delete", "Super+Space"].map(norm);
    return busy.includes(norm(accel)) ? { ok: false, reason: "сочетание занято системой" } : { ok: true };
  },
  integration_status: () => ({ platform: /Mac/.test(navigator.platform) ? "mac" : "win", finder: true, explorerClassic: true, explorerModern: false, servicesShortcut: false, automation: "granted" }),
  install_integration: ({ kind }) => ({ ok: true, message: kind === "explorerModern" ? "Нужен режим разработчика — см. README" : "Готово" }),
  uninstall_integration: () => ({ ok: true }),
  pick_folder: () => "/Users/me/Конвертированное",
  open_url: ({ url }) => (window.__openedUrl = url),
};

export const mockApi = {
  real: false,
  async invoke(cmd, args = {}) {
    const h = handlers[cmd];
    if (!h) throw new Error(`mock: нет команды ${cmd}`);
    return h(args);
  },
  listen(ev, cb) {
    (listeners[ev] ||= []).push(cb);
    return Promise.resolve(() => {});
  },
  demoJobs,
  emit,
};
