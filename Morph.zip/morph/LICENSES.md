# Лицензии

**Morph** (код приложения: ядро, интерфейс, оболочка) — MIT.

Движки поставляются как **отдельные программы** и запускаются отдельными процессами. Код Morph с ними не линкуется, поэтому лицензия Morph остаётся MIT, а каждый движок сохраняет свою. Тексты лицензий лежат рядом с движками в папке `engines/`, ссылки на исходники — ниже.

| Движок | Лицензия | Поставка | Исходники |
|---|---|---|---|
| FFmpeg (сборка с x264/x265) | GPL-3.0 (сборка), LGPL-2.1 (сам FFmpeg) | встроен | https://ffmpeg.org/download.html |
| ImageMagick 7 | ImageMagick License (Apache-2.0-подобная) | встроен (Windows), опционально (macOS) | https://github.com/ImageMagick/ImageMagick |
| qpdf | Apache-2.0 | встроен | https://github.com/qpdf/qpdf |
| Poppler (pdftoppm, pdftotext) | GPL-2.0/3.0 | встроен | https://poppler.freedesktop.org |
| bsdtar (libarchive) | BSD-2-Clause | часть macOS и Windows 10/11 | https://github.com/libarchive/libarchive |
| LibreOffice | MPL-2.0 | устанавливается по запросу | https://www.libreoffice.org |
| Pandoc | GPL-2.0+ | устанавливается по запросу | https://github.com/jgm/pandoc |
| Calibre | GPL-3.0 | необязательный, если установлен | https://github.com/kovidgoyal/calibre |
| librsvg | LGPL-2.1+ | необязательный | https://gitlab.gnome.org/GNOME/librsvg |

Что важно при распространении сборки с GPL-движками (FFmpeg, Poppler): приложите тексты лицензий (делает установщик) и укажите, где взять исходники (таблица выше). Если GPL нежелательна, соберите FFmpeg под LGPL без x264 — Morph сам переключится на аппаратные кодировщики H.264 (`h264_videotoolbox` на macOS, `h264_mf` в Windows).

AGPL-движки (Ghostscript, MuPDF) в Morph намеренно не используются.
