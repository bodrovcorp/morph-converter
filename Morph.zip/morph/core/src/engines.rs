//! Движки: поиск исполняемых файлов, проверка возможностей, запуск с прогрессом и отменой.

use crate::error::{classify, ConvError, ErrKind};
use std::collections::{HashMap, HashSet};
use std::ffi::OsString;
use std::io::{BufRead, BufReader, Read};
use std::path::{Path, PathBuf};
use std::process::{Command, Stdio};
use std::sync::atomic::{AtomicBool, AtomicU64, Ordering};
use std::sync::{Arc, Condvar, Mutex};
use std::thread;
use std::time::Duration;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, PartialOrd, Ord)]
pub enum EngineId {
    Ffmpeg,
    Ffprobe,
    Magick,
    Sips,
    Soffice,
    Pandoc,
    Qpdf,
    Pdftoppm,
    Pdftotext,
    Tar,
    SevenZip,
    Zip,
    Unzip,
    Calibre,
    Rsvg,
}

pub const ALL_ENGINES: &[EngineId] = &[
    EngineId::Ffmpeg,
    EngineId::Ffprobe,
    EngineId::Magick,
    EngineId::Sips,
    EngineId::Soffice,
    EngineId::Pandoc,
    EngineId::Qpdf,
    EngineId::Pdftoppm,
    EngineId::Pdftotext,
    EngineId::Tar,
    EngineId::SevenZip,
    EngineId::Zip,
    EngineId::Unzip,
    EngineId::Calibre,
    EngineId::Rsvg,
];

impl EngineId {
    pub fn id(self) -> &'static str {
        match self {
            EngineId::Ffmpeg => "ffmpeg",
            EngineId::Ffprobe => "ffprobe",
            EngineId::Magick => "magick",
            EngineId::Sips => "sips",
            EngineId::Soffice => "libreoffice",
            EngineId::Pandoc => "pandoc",
            EngineId::Qpdf => "qpdf",
            EngineId::Pdftoppm => "pdftoppm",
            EngineId::Pdftotext => "pdftotext",
            EngineId::Tar => "tar",
            EngineId::SevenZip => "7zip",
            EngineId::Zip => "zip",
            EngineId::Unzip => "unzip",
            EngineId::Calibre => "calibre",
            EngineId::Rsvg => "rsvg",
        }
    }
    pub fn from_id(s: &str) -> Option<EngineId> {
        ALL_ENGINES.iter().copied().find(|e| e.id() == s)
    }
    pub fn title(self) -> &'static str {
        match self {
            EngineId::Ffmpeg => "FFmpeg",
            EngineId::Ffprobe => "FFprobe",
            EngineId::Magick => "ImageMagick",
            EngineId::Sips => "sips (macOS)",
            EngineId::Soffice => "LibreOffice",
            EngineId::Pandoc => "Pandoc",
            EngineId::Qpdf => "qpdf",
            EngineId::Pdftoppm => "Poppler pdftoppm",
            EngineId::Pdftotext => "Poppler pdftotext",
            EngineId::Tar => "bsdtar",
            EngineId::SevenZip => "7-Zip",
            EngineId::Zip => "zip",
            EngineId::Unzip => "unzip",
            EngineId::Calibre => "Calibre",
            EngineId::Rsvg => "librsvg",
        }
    }
    /// Для чего нужен — показывается на экране «Компоненты»
    pub fn purpose(self) -> &'static str {
        match self {
            EngineId::Ffmpeg | EngineId::Ffprobe => "Видео, аудио, GIF",
            EngineId::Magick => "Фото: HEIC, RAW, SVG, ICO, WEBP, AVIF",
            EngineId::Sips => "Фото средствами macOS",
            EngineId::Soffice => "Word, Excel, PowerPoint ↔ PDF",
            EngineId::Pandoc => "Markdown, HTML, EPUB, FB2",
            EngineId::Qpdf => "Объединение и сжатие PDF",
            EngineId::Pdftoppm | EngineId::Pdftotext => "PDF → картинки и текст",
            EngineId::Tar | EngineId::SevenZip | EngineId::Zip | EngineId::Unzip => "Архивы ZIP, 7Z, TAR",
            EngineId::Calibre => "MOBI, AZW3 (необязательно)",
            EngineId::Rsvg => "SVG без ImageMagick (необязательно)",
        }
    }
    /// Как поставляется
    pub fn delivery(self) -> &'static str {
        match self {
            EngineId::Ffmpeg | EngineId::Ffprobe | EngineId::Magick | EngineId::Qpdf | EngineId::Pdftoppm | EngineId::Pdftotext => "bundled",
            EngineId::Sips | EngineId::Tar => "system",
            EngineId::Soffice | EngineId::Pandoc => "download",
            _ => "optional",
        }
    }
    /// Примерный размер загрузки, МБ
    pub fn download_mb(self) -> u32 {
        match self {
            EngineId::Soffice => 350,
            EngineId::Pandoc => 150,
            EngineId::Calibre => 200,
            _ => 0,
        }
    }
    fn exe_names(self) -> &'static [&'static str] {
        match self {
            EngineId::Ffmpeg => &["ffmpeg"],
            EngineId::Ffprobe => &["ffprobe"],
            EngineId::Magick => &["magick", "convert"],
            EngineId::Sips => &["sips"],
            EngineId::Soffice => &["soffice", "libreoffice"],
            EngineId::Pandoc => &["pandoc"],
            EngineId::Qpdf => &["qpdf"],
            EngineId::Pdftoppm => &["pdftoppm"],
            EngineId::Pdftotext => &["pdftotext"],
            EngineId::Tar => &["bsdtar", "tar"],
            EngineId::SevenZip => &["7zz", "7z", "7za"],
            EngineId::Zip => &["zip"],
            EngineId::Unzip => &["unzip"],
            EngineId::Calibre => &["ebook-convert"],
            EngineId::Rsvg => &["rsvg-convert"],
        }
    }
    fn known_locations(self) -> Vec<PathBuf> {
        #[allow(unused_mut)]
        let mut v = Vec::new();
        #[cfg(target_os = "macos")]
        {
            let p = |s: &str| PathBuf::from(s);
            match self {
                EngineId::Soffice => v.push(p("/Applications/LibreOffice.app/Contents/MacOS/soffice")),
                EngineId::Calibre => v.push(p("/Applications/calibre.app/Contents/MacOS/ebook-convert")),
                EngineId::Sips => v.push(p("/usr/bin/sips")),
                EngineId::Tar => v.push(p("/usr/bin/tar")),
                _ => {}
            }
            for e in self.exe_names() {
                v.push(PathBuf::from(format!("/opt/homebrew/bin/{e}")));
                v.push(PathBuf::from(format!("/usr/local/bin/{e}")));
            }
        }
        #[cfg(windows)]
        {
            let pf = std::env::var_os("ProgramFiles").map(PathBuf::from).unwrap_or_else(|| PathBuf::from(r"C:\Program Files"));
            let pf86 = std::env::var_os("ProgramFiles(x86)").map(PathBuf::from).unwrap_or_else(|| PathBuf::from(r"C:\Program Files (x86)"));
            let local = std::env::var_os("LOCALAPPDATA").map(PathBuf::from).unwrap_or_default();
            let sys = std::env::var_os("SystemRoot").map(PathBuf::from).unwrap_or_else(|| PathBuf::from(r"C:\Windows"));
            match self {
                EngineId::Soffice => {
                    v.push(pf.join(r"LibreOffice\program\soffice.exe"));
                    v.push(pf86.join(r"LibreOffice\program\soffice.exe"));
                }
                EngineId::Pandoc => {
                    v.push(local.join(r"Pandoc\pandoc.exe"));
                    v.push(pf.join(r"Pandoc\pandoc.exe"));
                }
                EngineId::Calibre => v.push(pf.join(r"Calibre2\ebook-convert.exe")),
                EngineId::SevenZip => v.push(pf.join(r"7-Zip\7z.exe")),
                EngineId::Tar => v.push(sys.join(r"System32\tar.exe")),
                _ => {}
            }
        }
        v
    }
}

#[derive(Debug, Clone, Default)]
pub struct EngineConfig {
    /// Папки со встроенными движками (sidecar) и докачанными компонентами
    pub bundled_dirs: Vec<PathBuf>,
    /// Пути, заданные пользователем вручную
    pub overrides: HashMap<EngineId, PathBuf>,
    /// Не искать в PATH (для тестов)
    pub no_path: bool,
}

/// Возможности найденных движков
#[derive(Debug, Clone, Default)]
pub struct Caps {
    pub magick_read: HashSet<String>,
    pub magick_write: HashSet<String>,
    pub magick_v7: bool,
    pub ff_encoders: HashSet<String>,
    pub ff_muxers: HashSet<String>,
    pub tar_bsd: bool,
}

#[derive(Debug, Clone)]
pub struct Engines {
    paths: HashMap<EngineId, PathBuf>,
    pub caps: Caps,
    /// Режим «все движки есть» — для построения полной таблицы конвертаций
    pub assume_all: bool,
}

#[derive(Debug, Clone)]
pub struct EngineStatus {
    pub id: EngineId,
    pub path: Option<PathBuf>,
    pub version: Option<String>,
}

fn exe(name: &str) -> String {
    if cfg!(windows) {
        format!("{name}.exe")
    } else {
        name.to_string()
    }
}

fn is_exec(p: &Path) -> bool {
    p.is_file()
}

impl Engines {
    pub fn discover(cfg: &EngineConfig) -> Engines {
        let mut paths = HashMap::new();
        for &id in ALL_ENGINES {
            if let Some(p) = Self::locate(id, cfg) {
                paths.insert(id, p);
            }
        }
        // sips есть только в macOS
        if !cfg!(target_os = "macos") {
            paths.remove(&EngineId::Sips);
        }
        let mut e = Engines { paths, caps: Caps::default(), assume_all: false };
        e.probe();
        e
    }

    /// Все движки «есть» и умеют всё — для таблицы поддерживаемых пар.
    pub fn all() -> Engines {
        let mut paths = HashMap::new();
        for &id in ALL_ENGINES {
            paths.insert(id, PathBuf::from(id.id()));
        }
        Engines { paths, caps: Caps { tar_bsd: true, magick_v7: true, ..Default::default() }, assume_all: true }
    }

    fn locate(id: EngineId, cfg: &EngineConfig) -> Option<PathBuf> {
        if let Some(p) = cfg.overrides.get(&id) {
            if is_exec(p) {
                return Some(p.clone());
            }
        }
        if let Some(p) = std::env::var_os(format!("MORPH_{}", id.id().to_uppercase())) {
            let p = PathBuf::from(p);
            if is_exec(&p) {
                return Some(p);
            }
        }
        for dir in &cfg.bundled_dirs {
            for n in id.exe_names() {
                for cand in [dir.join(exe(n)), dir.join(id.id()).join(exe(n)), dir.join(id.id()).join("bin").join(exe(n))] {
                    if is_exec(&cand) {
                        return Some(cand);
                    }
                }
            }
        }
        for p in id.known_locations() {
            if is_exec(&p) {
                return Some(p);
            }
        }
        if cfg.no_path {
            return None;
        }
        let path = std::env::var_os("PATH")?;
        for n in id.exe_names() {
            // В Windows «convert.exe» — системная утилита разметки дисков, не ImageMagick!
            if cfg!(windows) && *n == "convert" {
                continue;
            }
            for dir in std::env::split_paths(&path) {
                let cand = dir.join(exe(n));
                if is_exec(&cand) {
                    return Some(cand);
                }
            }
        }
        None
    }

    fn probe(&mut self) {
        if let Some(m) = self.paths.get(&EngineId::Magick).cloned() {
            self.caps.magick_v7 = m.file_stem().map(|s| s.to_string_lossy().starts_with("magick")).unwrap_or(false);
            if let Ok(out) = Command::new(&m).args(["-list", "format"]).stdin(Stdio::null()).output() {
                for line in String::from_utf8_lossy(&out.stdout).lines() {
                    let toks: Vec<&str> = line.split_whitespace().collect();
                    if toks.len() < 2 {
                        continue;
                    }
                    let name = toks[0].trim_end_matches('*').to_lowercase();
                    if let Some(mode) = toks[1..toks.len().min(3)].iter().find(|t| {
                        let b = t.as_bytes();
                        b.len() == 3 && (b[0] == b'r' || b[0] == b'-') && (b[1] == b'w' || b[1] == b'-')
                    }) {
                        if mode.starts_with('r') {
                            self.caps.magick_read.insert(name.clone());
                        }
                        if mode.as_bytes()[1] == b'w' {
                            self.caps.magick_write.insert(name);
                        }
                    }
                }
            }
        }
        if let Some(f) = self.paths.get(&EngineId::Ffmpeg).cloned() {
            for (flag, set) in [("-encoders", &mut self.caps.ff_encoders), ("-muxers", &mut self.caps.ff_muxers)] {
                if let Ok(out) = Command::new(&f).args(["-hide_banner", flag]).stdin(Stdio::null()).output() {
                    for line in String::from_utf8_lossy(&out.stdout).lines() {
                        let toks: Vec<&str> = line.split_whitespace().collect();
                        if toks.len() >= 2 && toks[0].len() <= 6 && !toks[0].contains('=') {
                            set.insert(toks[1].to_string());
                        }
                    }
                }
            }
        }
        if let Some(t) = self.paths.get(&EngineId::Tar).cloned() {
            if let Ok(out) = Command::new(&t).arg("--version").stdin(Stdio::null()).output() {
                self.caps.tar_bsd = String::from_utf8_lossy(&out.stdout).contains("bsdtar");
            }
        }
    }

    pub fn has(&self, id: EngineId) -> bool {
        self.paths.contains_key(&id)
    }
    pub fn path(&self, id: EngineId) -> Option<&Path> {
        self.paths.get(&id).map(|p| p.as_path())
    }
    pub fn magick_reads(&self, fmt: &str) -> bool {
        self.has(EngineId::Magick) && (self.assume_all || self.caps.magick_read.contains(fmt))
    }
    pub fn magick_writes(&self, fmt: &str) -> bool {
        self.has(EngineId::Magick) && (self.assume_all || self.caps.magick_write.contains(fmt))
    }
    pub fn ff_encoder(&self, name: &str) -> bool {
        self.has(EngineId::Ffmpeg) && (self.assume_all || self.caps.ff_encoders.contains(name))
    }
    pub fn ff_muxer(&self, name: &str) -> bool {
        self.has(EngineId::Ffmpeg) && (self.assume_all || self.caps.ff_muxers.contains(name))
    }

    pub fn status(&self) -> Vec<EngineStatus> {
        ALL_ENGINES
            .iter()
            .map(|&id| EngineStatus { id, path: self.paths.get(&id).cloned(), version: None })
            .collect()
    }
}

// ---------------------------------------------------------------------------
// Ограничение параллельности по движкам

pub struct Slots {
    used: Mutex<HashMap<EngineId, usize>>,
    cv: Condvar,
}

impl Slots {
    pub fn new() -> Self {
        Slots { used: Mutex::new(HashMap::new()), cv: Condvar::new() }
    }
    fn limit(id: EngineId) -> usize {
        let cores = thread::available_parallelism().map(|n| n.get()).unwrap_or(2);
        match id {
            // LibreOffice с одним профилем не умеет работать параллельно
            EngineId::Soffice | EngineId::Calibre => 1,
            // FFmpeg сам использует все ядра
            EngineId::Ffmpeg => 2,
            _ => (cores / 2).max(2),
        }
    }
    pub fn acquire(&self, id: EngineId, cancel: &AtomicBool) -> Result<SlotGuard<'_>, ConvError> {
        let mut used = self.used.lock().unwrap();
        loop {
            if cancel.load(Ordering::Relaxed) {
                return Err(ConvError::cancelled());
            }
            let n = *used.get(&id).unwrap_or(&0);
            if n < Self::limit(id) {
                used.insert(id, n + 1);
                return Ok(SlotGuard { slots: self, id });
            }
            used = self.cv.wait_timeout(used, Duration::from_millis(200)).unwrap().0;
        }
    }
}

impl Default for Slots {
    fn default() -> Self {
        Self::new()
    }
}

pub struct SlotGuard<'a> {
    slots: &'a Slots,
    id: EngineId,
}

impl Drop for SlotGuard<'_> {
    fn drop(&mut self) {
        let mut used = self.slots.used.lock().unwrap();
        if let Some(n) = used.get_mut(&self.id) {
            *n = n.saturating_sub(1);
        }
        self.slots.cv.notify_all();
    }
}

// ---------------------------------------------------------------------------
// Запуск команды

#[derive(Debug, Clone)]
pub enum ProgressKind {
    /// Прогресса нет — только «начато/готово»
    None,
    /// FFmpeg `-progress pipe:1`: out_time_us / длительность
    FfmpegTime { duration_us: u64 },
    /// pdftoppm `-progress`: строки «page total file»
    PdfPages,
}

#[derive(Debug, Clone)]
pub struct Cmd {
    pub engine: EngineId,
    pub args: Vec<OsString>,
    pub progress: ProgressKind,
    pub cwd: Option<PathBuf>,
    pub env: Vec<(String, OsString)>,
}

impl Cmd {
    pub fn new(engine: EngineId) -> Self {
        Cmd { engine, args: Vec::new(), progress: ProgressKind::None, cwd: None, env: Vec::new() }
    }
    pub fn arg(mut self, a: impl Into<OsString>) -> Self {
        self.args.push(a.into());
        self
    }
    pub fn args<I, S>(mut self, it: I) -> Self
    where
        I: IntoIterator<Item = S>,
        S: Into<OsString>,
    {
        for a in it {
            self.args.push(a.into());
        }
        self
    }
    pub fn progress(mut self, p: ProgressKind) -> Self {
        self.progress = p;
        self
    }
    pub fn cwd(mut self, d: impl Into<PathBuf>) -> Self {
        self.cwd = Some(d.into());
        self
    }
    pub fn env(mut self, k: &str, v: impl Into<OsString>) -> Self {
        self.env.push((k.to_string(), v.into()));
        self
    }
    pub fn display(&self) -> String {
        let mut s = self.engine.id().to_string();
        for a in &self.args {
            let a = a.to_string_lossy();
            if a.contains(' ') {
                s.push_str(&format!(" \"{a}\""));
            } else {
                s.push(' ');
                s.push_str(&a);
            }
        }
        s
    }
}

/// Запускает команду. `on_progress` получает долю 0..1. Отмена — через флаг `cancel`.
pub fn run(engines: &Engines, cmd: &Cmd, cancel: &AtomicBool, on_progress: &mut dyn FnMut(f64)) -> Result<String, ConvError> {
    let path = engines
        .path(cmd.engine)
        .ok_or_else(|| ConvError::new(ErrKind::EngineMissing(cmd.engine), format!("{} не найден", cmd.engine.title())))?;
    let mut c = Command::new(path);
    c.args(&cmd.args).stdin(Stdio::null()).stdout(Stdio::piped()).stderr(Stdio::piped());
    if let Some(d) = &cmd.cwd {
        c.current_dir(d);
    }
    // Приложения, запущенные из Finder, получают пустую локаль. Тогда LibreOffice и bsdtar
    // не могут работать с кириллицей в именах файлов. Задаём UTF-8 явно.
    #[cfg(unix)]
    {
        let utf8 = |v: Option<std::ffi::OsString>| v.map(|x| x.to_string_lossy().to_uppercase().contains("UTF-8") || x.to_string_lossy().to_uppercase().contains("UTF8")).unwrap_or(false);
        if !utf8(std::env::var_os("LC_ALL")) && !utf8(std::env::var_os("LANG")) {
            let loc = if cfg!(target_os = "macos") { "en_US.UTF-8" } else { "C.UTF-8" };
            c.env("LC_ALL", loc).env("LANG", loc);
        }
    }
    // ImageMagick из Homebrew, упакованный в приложение (scripts/fetch-engines.sh), грузит кодеки модулями
    if cmd.engine == EngineId::Magick {
        if let Some(lib) = path.parent().map(|d| d.join("../lib")) {
            if let Ok(rd) = std::fs::read_dir(&lib) {
                for e in rd.flatten() {
                    let name = e.file_name().to_string_lossy().to_string();
                    if name.starts_with("ImageMagick-") {
                        if let Ok(mods) = std::fs::read_dir(e.path()) {
                            for m in mods.flatten() {
                                if m.file_name().to_string_lossy().starts_with("modules-") {
                                    c.env("MAGICK_CODER_MODULE_PATH", m.path().join("coders"));
                                    c.env("MAGICK_FILTER_MODULE_PATH", m.path().join("filters"));
                                }
                            }
                        }
                    }
                }
            }
            let conf = lib.join("../magick-config");
            if conf.is_dir() {
                c.env("MAGICK_CONFIGURE_PATH", conf);
            }
        }
    }
    for (k, v) in &cmd.env {
        c.env(k, v);
    }
    #[cfg(windows)]
    {
        use std::os::windows::process::CommandExt;
        const CREATE_NO_WINDOW: u32 = 0x0800_0000;
        c.creation_flags(CREATE_NO_WINDOW);
    }
    let mut child = c.spawn().map_err(|e| ConvError::new(ErrKind::EngineMissing(cmd.engine), format!("Не удалось запустить {}: {e}", path.display())))?;

    let done_us = Arc::new(AtomicU64::new(0));
    let pages = Arc::new(AtomicU64::new(0));
    let total_pages = Arc::new(AtomicU64::new(0));
    let stdout = child.stdout.take().unwrap();
    let stderr = child.stderr.take().unwrap();

    let out_kind = cmd.progress.clone();
    let d2 = done_us.clone();
    let p2 = pages.clone();
    let tp2 = total_pages.clone();
    let out_thread = thread::spawn(move || {
        let mut captured = String::new();
        let reader = BufReader::new(stdout);
        for line in reader.split(b'\n').map_while(Result::ok) {
            let line = String::from_utf8_lossy(&line).to_string();
            match out_kind {
                ProgressKind::FfmpegTime { .. } => {
                    if let Some(v) = line.strip_prefix("out_time_us=").or_else(|| line.strip_prefix("out_time_ms=")) {
                        if let Ok(n) = v.trim().parse::<u64>() {
                            d2.store(n, Ordering::Relaxed);
                        }
                    }
                }
                _ => {
                    if captured.len() < 1 << 20 {
                        captured.push_str(&line);
                        captured.push('\n');
                    }
                }
            }
            let _ = (&p2, &tp2);
        }
        captured
    });
    let p3 = pages.clone();
    let tp3 = total_pages.clone();
    let pdf_progress = matches!(cmd.progress, ProgressKind::PdfPages);
    let err_thread = thread::spawn(move || {
        // храним хвост stderr (последние 64 КБ) — для понятной ошибки
        let mut tail: Vec<u8> = Vec::new();
        let mut reader = BufReader::new(stderr);
        let mut buf = [0u8; 8192];
        let mut pending = String::new();
        loop {
            match reader.read(&mut buf) {
                Ok(0) | Err(_) => break,
                Ok(n) => {
                    tail.extend_from_slice(&buf[..n]);
                    if tail.len() > 64 * 1024 {
                        let cut = tail.len() - 64 * 1024;
                        tail.drain(..cut);
                    }
                    if pdf_progress {
                        pending.push_str(&String::from_utf8_lossy(&buf[..n]));
                        while let Some(i) = pending.find('\n') {
                            let line: String = pending.drain(..=i).collect();
                            let t: Vec<&str> = line.split_whitespace().collect();
                            if t.len() >= 2 {
                                if let (Ok(a), Ok(b)) = (t[0].parse::<u64>(), t[1].parse::<u64>()) {
                                    p3.store(a, Ordering::Relaxed);
                                    tp3.store(b, Ordering::Relaxed);
                                }
                            }
                        }
                    }
                }
            }
        }
        String::from_utf8_lossy(&tail).to_string()
    });

    let status = loop {
        if cancel.load(Ordering::Relaxed) {
            let _ = child.kill();
            let _ = child.wait();
            let _ = out_thread.join();
            let _ = err_thread.join();
            return Err(ConvError::cancelled());
        }
        match child.try_wait() {
            Ok(Some(st)) => break st,
            Ok(None) => {}
            Err(e) => return Err(ConvError::new(ErrKind::Internal, e.to_string())),
        }
        match cmd.progress {
            ProgressKind::FfmpegTime { duration_us } if duration_us > 0 => {
                on_progress((done_us.load(Ordering::Relaxed) as f64 / duration_us as f64).clamp(0.0, 1.0));
            }
            ProgressKind::PdfPages => {
                let t = total_pages.load(Ordering::Relaxed);
                if t > 0 {
                    on_progress(pages.load(Ordering::Relaxed) as f64 / t as f64);
                }
            }
            _ => {}
        }
        thread::sleep(Duration::from_millis(60));
    };
    let stdout_text = out_thread.join().unwrap_or_default();
    let stderr_text = err_thread.join().unwrap_or_default();
    if !status.success() {
        return Err(classify(cmd.engine, status.code(), &format!("{stderr_text}\n{stdout_text}")));
    }
    // ImageMagick и FFmpeg иногда «успешно» выдают серую/битую картинку из повреждённого файла,
    // сообщая о проблеме лишь предупреждением. Такие предупреждения считаем ошибкой.
    if fatal_warning(cmd.engine, &stderr_text) {
        return Err(ConvError::new(ErrKind::InputCorrupt, format!("{}: {}", cmd.engine.title(), stderr_text.lines().take(5).collect::<Vec<_>>().join("\n"))));
    }
    on_progress(1.0);
    Ok(format!("{stdout_text}{stderr_text}"))
}

fn fatal_warning(engine: EngineId, stderr: &str) -> bool {
    let s = stderr.to_lowercase();
    match engine {
        EngineId::Magick => [
            "premature end of jpeg file",
            "corrupt jpeg data",
            "insufficient image data",
            "improper image header",
            "unexpected end of file",
            "read error on strip",
            "incorrect count for field",
            "data stream ends early",
        ]
        .iter()
        .any(|p| s.contains(p)),
        _ => false,
    }
}

/// Длительность медиафайла в микросекундах (через ffprobe).
pub fn media_duration_us(engines: &Engines, input: &Path) -> Option<u64> {
    let p = engines.path(EngineId::Ffprobe)?;
    let mut c = Command::new(p);
    c.args(["-v", "error", "-show_entries", "format=duration", "-of", "default=noprint_wrappers=1:nokey=1"])
        .arg(input)
        .stdin(Stdio::null());
    #[cfg(windows)]
    {
        use std::os::windows::process::CommandExt;
        c.creation_flags(0x0800_0000);
    }
    let out = c.output().ok()?;
    let s = String::from_utf8_lossy(&out.stdout);
    let secs: f64 = s.trim().lines().next()?.trim().parse().ok()?;
    Some((secs * 1_000_000.0) as u64)
}

/// Кодеки потоков (видео, аудио) — для быстрого перепаковывания без перекодирования.
pub fn media_codecs(engines: &Engines, input: &Path) -> (Option<String>, Option<String>) {
    let Some(p) = engines.path(EngineId::Ffprobe) else { return (None, None) };
    let run = |sel: &str| -> Option<String> {
        let mut c = Command::new(p);
        c.args(["-v", "error", "-select_streams", sel, "-show_entries", "stream=codec_name", "-of", "default=noprint_wrappers=1:nokey=1"])
            .arg(input)
            .stdin(Stdio::null());
        #[cfg(windows)]
        {
            use std::os::windows::process::CommandExt;
            c.creation_flags(0x0800_0000);
        }
        let out = c.output().ok()?;
        String::from_utf8_lossy(&out.stdout).lines().next().map(|s| s.trim().to_string()).filter(|s| !s.is_empty())
    };
    (run("v:0"), run("a:0"))
}
