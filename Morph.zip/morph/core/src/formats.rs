//! Каталог форматов и определение типа файла по содержимому («магические байты») + расширению.

use std::fs::File;
use std::io::{Read, Seek, SeekFrom};
use std::path::Path;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, PartialOrd, Ord)]
pub enum Kind {
    Image,
    Video,
    Audio,
    Document,
    Spreadsheet,
    Presentation,
    Ebook,
    Archive,
    Folder,
    /// Любой другой файл (можно только упаковать в архив)
    Other,
}

impl Kind {
    pub fn id(self) -> &'static str {
        match self {
            Kind::Image => "image",
            Kind::Video => "video",
            Kind::Audio => "audio",
            Kind::Document => "document",
            Kind::Spreadsheet => "spreadsheet",
            Kind::Presentation => "presentation",
            Kind::Ebook => "ebook",
            Kind::Archive => "archive",
            Kind::Folder => "folder",
            Kind::Other => "other",
        }
    }
    pub fn title(self) -> &'static str {
        match self {
            Kind::Image => "Изображение",
            Kind::Video => "Видео",
            Kind::Audio => "Аудио",
            Kind::Document => "Документ",
            Kind::Spreadsheet => "Таблица",
            Kind::Presentation => "Презентация",
            Kind::Ebook => "Электронная книга",
            Kind::Archive => "Архив",
            Kind::Folder => "Папка",
            Kind::Other => "Файл",
        }
    }
}

#[derive(Debug, PartialEq, Eq)]
pub struct Format {
    pub id: &'static str,
    /// Расширения, первое — основное (для вывода)
    pub exts: &'static [&'static str],
    pub kind: Kind,
    /// Короткое имя для интерфейса
    pub title: &'static str,
    /// Описание для меню («Совместимо везде»)
    pub desc: &'static str,
}

impl Format {
    pub fn ext(&self) -> &'static str {
        self.exts[0]
    }
}

macro_rules! f {
    ($id:expr, [$($e:expr),+], $k:ident, $t:expr, $d:expr) => {
        Format { id: $id, exts: &[$($e),+], kind: Kind::$k, title: $t, desc: $d }
    };
}

pub static FORMATS: &[Format] = &[
    // Изображения
    f!("jpg", ["jpg", "jpeg", "jpe", "jfif"], Image, "JPG", "Совместимо везде"),
    f!("png", ["png"], Image, "PNG", "Без потерь, с прозрачностью"),
    f!("webp", ["webp"], Image, "WEBP", "Лёгкий, для сайтов"),
    f!("avif", ["avif"], Image, "AVIF", "Самый компактный"),
    f!("heic", ["heic", "heif", "hif"], Image, "HEIC", "Формат фото iPhone"),
    f!("gif", ["gif"], Image, "GIF", "256 цветов, анимация"),
    f!("bmp", ["bmp", "dib"], Image, "BMP", "Без сжатия"),
    f!("tiff", ["tiff", "tif"], Image, "TIFF", "Для печати и архива"),
    f!("ico", ["ico"], Image, "ICO", "Иконка 16–256 px"),
    f!("svg", ["svg"], Image, "SVG", "Векторная графика"),
    f!("psd", ["psd"], Image, "PSD", "Photoshop"),
    f!("tga", ["tga"], Image, "TGA", "Targa"),
    f!("cr2", ["cr2"], Image, "CR2", "RAW Canon"),
    f!("cr3", ["cr3"], Image, "CR3", "RAW Canon"),
    f!("nef", ["nef"], Image, "NEF", "RAW Nikon"),
    f!("arw", ["arw"], Image, "ARW", "RAW Sony"),
    f!("dng", ["dng"], Image, "DNG", "RAW Adobe"),
    f!("orf", ["orf"], Image, "ORF", "RAW Olympus"),
    f!("rw2", ["rw2"], Image, "RW2", "RAW Panasonic"),
    f!("raf", ["raf"], Image, "RAF", "RAW Fujifilm"),
    // Видео
    f!("mp4", ["mp4", "m4v"], Video, "MP4", "Совместимо везде (H.264)"),
    f!("mov", ["mov", "qt"], Video, "MOV", "QuickTime"),
    f!("mkv", ["mkv"], Video, "MKV", "Matroska"),
    f!("avi", ["avi"], Video, "AVI", "Старые плееры"),
    f!("webm", ["webm"], Video, "WEBM", "Для сайтов (VP9)"),
    f!("wmv", ["wmv", "asf"], Video, "WMV", "Windows Media"),
    f!("flv", ["flv"], Video, "FLV", "Flash Video"),
    f!("mpeg", ["mpg", "mpeg", "vob"], Video, "MPEG", "MPEG-1/2"),
    f!("3gp", ["3gp", "3g2"], Video, "3GP", "Старые телефоны"),
    f!("ts", ["ts", "mts", "m2ts"], Video, "TS", "Видеокамеры, ТВ"),
    // Аудио
    f!("mp3", ["mp3"], Audio, "MP3", "Совместимо везде"),
    f!("wav", ["wav", "wave"], Audio, "WAV", "Без сжатия"),
    f!("flac", ["flac"], Audio, "FLAC", "Без потерь, сжатый"),
    f!("m4a", ["m4a", "m4b", "alac"], Audio, "M4A", "AAC, Apple"),
    f!("aac", ["aac"], Audio, "AAC", "Поток AAC"),
    f!("ogg", ["ogg", "oga"], Audio, "OGG", "Vorbis"),
    f!("opus", ["opus"], Audio, "OPUS", "Лучшее качество на малом битрейте"),
    f!("wma", ["wma"], Audio, "WMA", "Windows Media Audio"),
    f!("aiff", ["aiff", "aif", "aifc"], Audio, "AIFF", "Без сжатия, Apple"),
    f!("amr", ["amr"], Audio, "AMR", "Диктофоны"),
    // Документы
    f!("pdf", ["pdf"], Document, "PDF", "Выглядит одинаково везде"),
    f!("docx", ["docx"], Document, "DOCX", "Microsoft Word"),
    f!("doc", ["doc"], Document, "DOC", "Word 97–2003"),
    f!("odt", ["odt"], Document, "ODT", "LibreOffice Writer"),
    f!("rtf", ["rtf"], Document, "RTF", "Форматированный текст"),
    f!("txt", ["txt", "text", "log"], Document, "TXT", "Простой текст (UTF-8)"),
    f!("md", ["md", "markdown", "mdown"], Document, "MD", "Markdown"),
    f!("html", ["html", "htm", "xhtml"], Document, "HTML", "Веб-страница"),
    // Таблицы
    f!("xlsx", ["xlsx", "xlsm"], Spreadsheet, "XLSX", "Microsoft Excel"),
    f!("xls", ["xls"], Spreadsheet, "XLS", "Excel 97–2003"),
    f!("ods", ["ods"], Spreadsheet, "ODS", "LibreOffice Calc"),
    f!("csv", ["csv"], Spreadsheet, "CSV", "Текст с разделителями"),
    f!("tsv", ["tsv", "tab"], Spreadsheet, "TSV", "Разделитель — табуляция"),
    f!("json", ["json"], Spreadsheet, "JSON", "Данные для программ"),
    // Презентации
    f!("pptx", ["pptx", "ppsx"], Presentation, "PPTX", "Microsoft PowerPoint"),
    f!("ppt", ["ppt", "pps"], Presentation, "PPT", "PowerPoint 97–2003"),
    f!("odp", ["odp"], Presentation, "ODP", "LibreOffice Impress"),
    // Электронные книги
    f!("epub", ["epub"], Ebook, "EPUB", "Стандарт электронных книг"),
    f!("fb2", ["fb2"], Ebook, "FB2", "FictionBook"),
    f!("mobi", ["mobi", "prc"], Ebook, "MOBI", "Старые Kindle"),
    f!("azw3", ["azw3", "azw"], Ebook, "AZW3", "Kindle"),
    // Архивы
    f!("zip", ["zip"], Archive, "ZIP", "Открывается везде"),
    f!("7z", ["7z"], Archive, "7Z", "Сильнее сжатие"),
    f!("targz", ["tar.gz", "tgz"], Archive, "TAR.GZ", "Linux, macOS"),
    f!("tarbz2", ["tar.bz2", "tbz2", "tbz"], Archive, "TAR.BZ2", "bzip2"),
    f!("tarxz", ["tar.xz", "txz"], Archive, "TAR.XZ", "xz"),
    f!("tar", ["tar"], Archive, "TAR", "Без сжатия"),
    f!("rar", ["rar"], Archive, "RAR", "Только распаковка"),
    f!("folder", ["folder"], Folder, "Папка", "Папка"),
    f!("file", ["*"], Other, "Файл", "Неизвестный формат"),
];

pub fn by_id(id: &str) -> Option<&'static Format> {
    FORMATS.iter().find(|f| f.id == id)
}

/// Разделяет имя файла на основу и расширение с учётом составных (`.tar.gz`).
pub fn split_name(name: &str) -> (String, String) {
    let lower = name.to_lowercase();
    for compound in ["tar.gz", "tar.bz2", "tar.xz", "tar.zst"] {
        let suffix = format!(".{compound}");
        if lower.ends_with(&suffix) && lower.len() > suffix.len() {
            let cut = name.len() - suffix.len();
            return (name[..cut].to_string(), compound.to_string());
        }
    }
    match name.rfind('.') {
        Some(i) if i > 0 => (name[..i].to_string(), name[i + 1..].to_lowercase()),
        _ => (name.to_string(), String::new()),
    }
}

pub fn by_ext(ext: &str) -> Option<&'static Format> {
    let e = ext.to_lowercase();
    FORMATS.iter().find(|f| f.id != "folder" && f.id != "file" && f.exts.iter().any(|x| *x == e))
}

/// Определяет формат файла. Сначала содержимое, затем расширение.
pub fn detect(path: &Path) -> Option<&'static Format> {
    if path.is_dir() {
        return by_id("folder");
    }
    let name = path.file_name()?.to_string_lossy().to_string();
    let (_, ext) = split_name(&name);
    let by_extension = by_ext(&ext);
    let mut head = vec![0u8; 8192];
    let n = File::open(path).and_then(|mut f| f.read(&mut head)).unwrap_or(0);
    head.truncate(n);
    match sniff(&head, path, &ext) {
        Some(id) => {
            let f = by_id(id);
            // Сигнатура говорит о семействе, расширение уточняет (например, TIFF → NEF/DNG)
            if let (Some(sig), Some(e)) = (f, by_extension) {
                if refines(sig.id, e.id) {
                    return Some(e);
                }
            }
            f
        }
        // Неизвестный тип — всё равно «файл»: его можно упаковать в архив
        None => by_extension.or_else(|| by_id("file")),
    }
}

/// Может ли расширение уточнить формат, определённый по сигнатуре.
fn refines(sig: &str, ext: &str) -> bool {
    match sig {
        "tiff" => matches!(ext, "cr2" | "nef" | "arw" | "dng" | "orf" | "rw2" | "tiff"),
        "zip" => matches!(ext, "zip"),
        "doc" | "xls" | "ppt" => matches!(ext, "doc" | "xls" | "ppt"),
        "mp4" => matches!(ext, "mp4" | "m4a" | "mov" | "3gp"),
        "mov" => matches!(ext, "mp4" | "mov"),
        "html" => matches!(ext, "html" | "md" | "txt"),
        "txt" => matches!(ext, "txt" | "md" | "csv" | "tsv" | "json" | "html" | "svg" | "fb2"),
        "gz" => false,
        "mpeg" => matches!(ext, "mpeg" | "ts"),
        _ => false,
    }
}

fn at(b: &[u8], off: usize, sig: &[u8]) -> bool {
    b.len() >= off + sig.len() && &b[off..off + sig.len()] == sig
}

fn contains(b: &[u8], needle: &[u8]) -> bool {
    b.windows(needle.len()).any(|w| w == needle)
}

fn sniff(b: &[u8], path: &Path, ext: &str) -> Option<&'static str> {
    if b.is_empty() {
        return None;
    }
    if at(b, 0, b"%PDF") {
        return Some("pdf");
    }
    if at(b, 0, &[0xFF, 0xD8, 0xFF]) {
        return Some("jpg");
    }
    if at(b, 0, &[0x89, b'P', b'N', b'G']) {
        return Some("png");
    }
    if at(b, 0, b"GIF8") {
        return Some("gif");
    }
    if at(b, 0, b"RIFF") && at(b, 8, b"WEBP") {
        return Some("webp");
    }
    if at(b, 0, b"RIFF") && at(b, 8, b"WAVE") {
        return Some("wav");
    }
    if at(b, 0, b"RIFF") && at(b, 8, b"AVI ") {
        return Some("avi");
    }
    if at(b, 0, b"BM") && b.len() > 14 && ext != "txt" {
        return Some("bmp");
    }
    if at(b, 0, b"8BPS") {
        return Some("psd");
    }
    if at(b, 0, &[0, 0, 1, 0]) && ext == "ico" {
        return Some("ico");
    }
    if at(b, 0, b"FUJIFILMCCD-RAW") {
        return Some("raf");
    }
    if at(b, 0, b"IIRO") || at(b, 0, b"IIU\0") {
        return if ext == "rw2" { Some("rw2") } else { Some("orf") };
    }
    if at(b, 0, b"II*\0") || at(b, 0, b"MM\0*") {
        if at(b, 8, b"CR") {
            return Some("cr2");
        }
        return Some("tiff");
    }
    if at(b, 4, b"ftyp") {
        let brand = &b[8..12.min(b.len())];
        let compat = &b[8..b.len().min(64)];
        if brand == b"crx " {
            return Some("cr3");
        }
        if brand == b"avif" || brand == b"avis" {
            return Some("avif");
        }
        if matches!(brand, b"heic" | b"heix" | b"heim" | b"heis" | b"hevc" | b"hevx" | b"mif1" | b"msf1") {
            if contains(compat, b"avif") {
                return Some("avif");
            }
            return Some("heic");
        }
        if brand == b"M4A " || brand == b"M4B " {
            return Some("m4a");
        }
        if brand == b"qt  " {
            return Some("mov");
        }
        if brand.starts_with(b"3g") {
            return Some("3gp");
        }
        return Some("mp4");
    }
    if at(b, 4, b"moov") || at(b, 4, b"mdat") || at(b, 4, b"wide") || at(b, 4, b"free") {
        return Some("mov");
    }
    if at(b, 0, &[0x1A, 0x45, 0xDF, 0xA3]) {
        return if contains(&b[..b.len().min(64)], b"webm") { Some("webm") } else { Some("mkv") };
    }
    if at(b, 0, &[0x30, 0x26, 0xB2, 0x75]) {
        return if ext == "wma" { Some("wma") } else { Some("wmv") };
    }
    if at(b, 0, b"FLV") {
        return Some("flv");
    }
    if at(b, 0, &[0, 0, 1, 0xBA]) || at(b, 0, &[0, 0, 1, 0xB3]) {
        return Some("mpeg");
    }
    if b.len() > 188 && b[0] == 0x47 && b[188] == 0x47 {
        return Some("ts");
    }
    if at(b, 0, b"ID3") || (b.len() > 2 && b[0] == 0xFF && (b[1] & 0xE0) == 0xE0 && ext != "aac") {
        if at(b, 0, b"ID3") || ext == "mp3" {
            return Some("mp3");
        }
    }
    if b.len() > 2 && b[0] == 0xFF && (b[1] & 0xF6) == 0xF0 {
        return Some("aac");
    }
    if at(b, 0, b"fLaC") {
        return Some("flac");
    }
    if at(b, 0, b"OggS") {
        return if contains(&b[..b.len().min(128)], b"OpusHead") { Some("opus") } else { Some("ogg") };
    }
    if at(b, 0, b"FORM") && (at(b, 8, b"AIFF") || at(b, 8, b"AIFC")) {
        return Some("aiff");
    }
    if at(b, 0, b"#!AMR") {
        return Some("amr");
    }
    if at(b, 0, &[0x37, 0x7A, 0xBC, 0xAF, 0x27, 0x1C]) {
        return Some("7z");
    }
    if at(b, 0, b"Rar!") {
        return Some("rar");
    }
    if at(b, 0, &[0x1F, 0x8B]) {
        return Some(if ext == "tgz" || path.to_string_lossy().to_lowercase().ends_with(".tar.gz") { "targz" } else { "targz" });
    }
    if at(b, 0, b"BZh") {
        return Some("tarbz2");
    }
    if at(b, 0, &[0xFD, b'7', b'z', b'X', b'Z', 0]) {
        return Some("tarxz");
    }
    if at(b, 257, b"ustar") {
        return Some("tar");
    }
    if at(b, 60, b"BOOKMOBI") {
        return if ext == "azw3" || ext == "azw" { Some("azw3") } else { Some("mobi") };
    }
    if at(b, 0, &[0xD0, 0xCF, 0x11, 0xE0]) {
        // OLE-контейнер: Word/Excel/PowerPoint 97–2003 — различаем по расширению
        return match ext {
            "xls" => Some("xls"),
            "ppt" | "pps" => Some("ppt"),
            "msg" => None,
            _ => Some("doc"),
        };
    }
    if at(b, 0, b"PK\x03\x04") {
        return Some(sniff_zip(b, path));
    }
    if at(b, 0, b"{\\rtf") {
        return Some("rtf");
    }
    // Текстовые форматы
    let text = String::from_utf8_lossy(&b[..b.len().min(4096)]).to_lowercase();
    let t = text.trim_start_matches('\u{feff}').trim_start();
    if t.contains("<fictionbook") {
        return Some("fb2");
    }
    if t.starts_with("<svg") || (t.starts_with("<?xml") && t.contains("<svg")) {
        return Some("svg");
    }
    if t.starts_with("<!doctype html") || t.starts_with("<html") {
        return Some("html");
    }
    None
}

/// Определяет тип ZIP-контейнера: DOCX/XLSX/PPTX/EPUB/ODF/обычный ZIP.
fn sniff_zip(head: &[u8], path: &Path) -> &'static str {
    // Первый файл в EPUB/ODF — «mimetype», его содержимое лежит сразу после заголовка
    if at(head, 30, b"mimetype") {
        let rest = &head[38.min(head.len())..head.len().min(160)];
        if contains(rest, b"application/epub+zip") {
            return "epub";
        }
        if contains(rest, b"opendocument.text") {
            return "odt";
        }
        if contains(rest, b"opendocument.spreadsheet") {
            return "ods";
        }
        if contains(rest, b"opendocument.presentation") {
            return "odp";
        }
    }
    // OOXML: имена частей встречаются в локальных заголовках и центральном каталоге
    let mut data = head.to_vec();
    if let Ok(mut f) = File::open(path) {
        if let Ok(len) = f.seek(SeekFrom::End(0)) {
            let tail = 256 * 1024u64;
            let start = len.saturating_sub(tail);
            if f.seek(SeekFrom::Start(start)).is_ok() {
                let mut buf = Vec::new();
                let _ = f.take(tail).read_to_end(&mut buf);
                data.extend_from_slice(&buf);
            }
        }
    }
    if contains(&data, b"word/document") || contains(&data, b"word/_rels") {
        return "docx";
    }
    if contains(&data, b"xl/workbook") || contains(&data, b"xl/_rels") {
        return "xlsx";
    }
    if contains(&data, b"ppt/presentation") || contains(&data, b"ppt/_rels") {
        return "pptx";
    }
    "zip"
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn split_names() {
        assert_eq!(split_name("Отчёт за 2026.docx"), ("Отчёт за 2026".into(), "docx".into()));
        assert_eq!(split_name("backup.TAR.GZ"), ("backup".into(), "tar.gz".into()));
        assert_eq!(split_name(".bashrc"), (".bashrc".into(), "".into()));
        assert_eq!(split_name("README"), ("README".into(), "".into()));
    }

    #[test]
    fn exts_unique() {
        let mut seen = std::collections::HashSet::new();
        for f in FORMATS {
            for e in f.exts {
                assert!(seen.insert(*e), "расширение {e} повторяется");
            }
        }
    }
}
