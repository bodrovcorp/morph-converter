//! Очередь задач: несколько задач одновременно, лимиты по движкам, прогресс, ETA, отмена.

use crate::engines::{run, Engines, Slots};
use crate::error::{ConvError, ErrKind};
use crate::formats::{detect, split_name, Kind};
use crate::naming::{self, Conflict};
use crate::options::Options;
use crate::registry::{Ctx, Input, Output, Plan, Registry, Step};
use crate::text::json::Json;
use std::collections::VecDeque;
use std::fs;
use std::path::{Path, PathBuf};
use std::sync::atomic::{AtomicBool, AtomicU64, Ordering};
use std::sync::{Arc, Condvar, Mutex, OnceLock, RwLock};
use std::thread;
use std::time::{Duration, Instant, SystemTime, UNIX_EPOCH};

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Status {
    Queued,
    Running,
    Done,
    Failed,
    Cancelled,
}

impl Status {
    pub fn id(self) -> &'static str {
        match self {
            Status::Queued => "queued",
            Status::Running => "running",
            Status::Done => "done",
            Status::Failed => "failed",
            Status::Cancelled => "cancelled",
        }
    }
    pub fn finished(self) -> bool {
        matches!(self, Status::Done | Status::Failed | Status::Cancelled)
    }
}

#[derive(Debug, Clone)]
pub enum Dest {
    /// Рядом с исходником
    Beside,
    Folder(PathBuf),
}

#[derive(Debug, Clone)]
pub struct JobRequest {
    pub inputs: Vec<PathBuf>,
    pub target: String,
    pub options: Options,
    pub dest: Dest,
    pub conflict: Conflict,
}

#[derive(Debug, Clone)]
pub struct JobInfo {
    pub id: u64,
    pub batch: u64,
    pub inputs: Vec<PathBuf>,
    pub target: String,
    pub target_title: String,
    pub src_title: String,
    pub status: Status,
    pub progress: f64,
    pub eta_secs: Option<f64>,
    pub outputs: Vec<PathBuf>,
    pub error: Option<String>,
    pub details: String,
    pub src_bytes: u64,
    pub out_bytes: u64,
    pub created_ms: u64,
    pub elapsed_secs: f64,
}

impl JobInfo {
    pub fn to_json(&self) -> Json {
        let paths = |v: &[PathBuf]| Json::Arr(v.iter().map(|p| Json::str(p.to_string_lossy())).collect());
        let name = self.inputs.first().and_then(|p| p.file_name()).map(|s| s.to_string_lossy().to_string()).unwrap_or_default();
        Json::obj(vec![
            ("id", Json::num(self.id as f64)),
            ("batch", Json::num(self.batch as f64)),
            ("name", Json::str(name)),
            ("count", Json::num(self.inputs.len() as f64)),
            ("inputs", paths(&self.inputs)),
            ("target", Json::str(&self.target)),
            ("targetTitle", Json::str(&self.target_title)),
            ("srcTitle", Json::str(&self.src_title)),
            ("status", Json::str(self.status.id())),
            ("progress", Json::num((self.progress * 1000.0).round() / 1000.0)),
            ("eta", self.eta_secs.map(|x| Json::num(x.round())).unwrap_or(Json::Null)),
            ("outputs", paths(&self.outputs)),
            ("error", self.error.as_ref().map(Json::str).unwrap_or(Json::Null)),
            ("details", Json::str(&self.details)),
            ("srcBytes", Json::num(self.src_bytes as f64)),
            ("outBytes", Json::num(self.out_bytes as f64)),
            ("created", Json::num(self.created_ms as f64)),
            ("elapsed", Json::num((self.elapsed_secs * 10.0).round() / 10.0)),
        ])
    }
}

struct Job {
    info: Mutex<JobInfo>,
    req: JobRequest,
    cancel: AtomicBool,
    started: Mutex<Option<Instant>>,
}

pub type Sink = Arc<dyn Fn(&JobInfo) + Send + Sync>;

struct Inner {
    pending: Mutex<VecDeque<Arc<Job>>>,
    cv: Condvar,
    all: Mutex<Vec<Arc<Job>>>,
    engines: RwLock<Arc<Engines>>,
    registry: Registry,
    sink: Sink,
    shutdown: AtomicBool,
}

#[derive(Clone)]
pub struct Queue {
    inner: Arc<Inner>,
}

static NEXT_ID: AtomicU64 = AtomicU64::new(1);

/// Слоты движков общие для всего процесса (LibreOffice — строго по одному)
fn slots() -> &'static Slots {
    static S: OnceLock<Slots> = OnceLock::new();
    S.get_or_init(Slots::new)
}

fn now_ms() -> u64 {
    SystemTime::now().duration_since(UNIX_EPOCH).map(|d| d.as_millis() as u64).unwrap_or(0)
}

impl Queue {
    /// `workers` — сколько задач выполняется одновременно (внутри — ещё лимиты по движкам).
    pub fn new(engines: Arc<Engines>, workers: usize, sink: Sink) -> Queue {
        let inner = Arc::new(Inner {
            pending: Mutex::new(VecDeque::new()),
            cv: Condvar::new(),
            all: Mutex::new(Vec::new()),
            engines: RwLock::new(engines),
            registry: Registry::new(),
            sink,
            shutdown: AtomicBool::new(false),
        });
        for _ in 0..workers.max(1) {
            let inner = inner.clone();
            thread::spawn(move || worker(inner));
        }
        Queue { inner }
    }

    pub fn engines(&self) -> Arc<Engines> {
        self.inner.engines.read().unwrap().clone()
    }

    /// Подменяет набор движков (после установки компонента). Идущие задачи доработают со старым.
    pub fn set_engines(&self, e: Arc<Engines>) {
        *self.inner.engines.write().unwrap() = e;
    }

    /// Ставит в очередь. Для объединяющих целей — одна задача, иначе по задаче на файл.
    pub fn submit(&self, req: JobRequest) -> u64 {
        let batch = NEXT_ID.fetch_add(1, Ordering::Relaxed);
        let combine = is_combine(&req.target);
        let groups: Vec<Vec<PathBuf>> = if combine { vec![req.inputs.clone()] } else { req.inputs.iter().map(|p| vec![p.clone()]).collect() };
        for g in groups {
            let id = NEXT_ID.fetch_add(1, Ordering::Relaxed);
            let src_bytes = g.iter().map(|p| path_size(p)).sum();
            let info = JobInfo {
                id,
                batch,
                inputs: g.clone(),
                target: req.target.clone(),
                target_title: req.target.to_uppercase(),
                src_title: String::new(),
                status: Status::Queued,
                progress: 0.0,
                eta_secs: None,
                outputs: vec![],
                error: None,
                details: String::new(),
                src_bytes,
                out_bytes: 0,
                created_ms: now_ms(),
                elapsed_secs: 0.0,
            };
            let job = Arc::new(Job { info: Mutex::new(info), req: JobRequest { inputs: g, ..req.clone() }, cancel: AtomicBool::new(false), started: Mutex::new(None) });
            (self.inner.sink)(&job.info.lock().unwrap());
            self.inner.all.lock().unwrap().push(job.clone());
            self.inner.pending.lock().unwrap().push_back(job);
        }
        self.inner.cv.notify_all();
        batch
    }

    pub fn cancel(&self, id: u64) {
        for j in self.inner.all.lock().unwrap().iter() {
            let (jid, batch) = {
                let i = j.info.lock().unwrap();
                (i.id, i.batch)
            };
            if jid == id || batch == id {
                j.cancel.store(true, Ordering::Relaxed);
                let mut i = j.info.lock().unwrap();
                if i.status == Status::Queued {
                    i.status = Status::Cancelled;
                    i.error = Some(ConvError::cancelled().user_message());
                    (self.inner.sink)(&i);
                }
            }
        }
    }

    pub fn cancel_all(&self) {
        let ids: Vec<u64> = self.inner.all.lock().unwrap().iter().map(|j| j.info.lock().unwrap().id).collect();
        for id in ids {
            self.cancel(id);
        }
    }

    pub fn snapshot(&self) -> Vec<JobInfo> {
        self.inner.all.lock().unwrap().iter().map(|j| j.info.lock().unwrap().clone()).collect()
    }

    pub fn clear_finished(&self) {
        self.inner.all.lock().unwrap().retain(|j| !j.info.lock().unwrap().status.finished());
    }

    /// Ждёт завершения всех задач (для CLI и тестов)
    pub fn wait_idle(&self, timeout: Duration) -> bool {
        let start = Instant::now();
        loop {
            if self.snapshot().iter().all(|j| j.status.finished()) {
                return true;
            }
            if start.elapsed() > timeout {
                return false;
            }
            thread::sleep(Duration::from_millis(50));
        }
    }

    /// Куда попадёт результат при политике «Суффикс» — для режима «Спросить».
    pub fn predicted_output(&self, input: &Path, target: &str, dest: &Dest) -> Option<PathBuf> {
        let f = detect(input)?;
        let offers = self.inner.registry.offers_for(f, &self.engines());
        let o = offers.iter().find(|o| o.id == target)?;
        let dir = match dest {
            Dest::Beside => input.parent()?.to_path_buf(),
            Dest::Folder(p) => p.clone(),
        };
        let stem = Input { path: input.to_path_buf(), format: f }.stem();
        Some(naming::candidate(&dir, &naming::sanitize(&stem), o.ext, 0))
    }

    pub fn shutdown(&self) {
        self.inner.shutdown.store(true, Ordering::Relaxed);
        self.cancel_all();
        self.inner.cv.notify_all();
    }
}

fn path_size(p: &Path) -> u64 {
    match fs::metadata(p) {
        Ok(m) if m.is_file() => m.len(),
        Ok(m) if m.is_dir() => fs::read_dir(p).map(|rd| rd.flatten().map(|e| path_size(&e.path())).sum()).unwrap_or(0),
        _ => 0,
    }
}

fn worker(inner: Arc<Inner>) {
    loop {
        let job = {
            let mut q = inner.pending.lock().unwrap();
            loop {
                if inner.shutdown.load(Ordering::Relaxed) {
                    return;
                }
                if let Some(j) = q.pop_front() {
                    break j;
                }
                q = inner.cv.wait_timeout(q, Duration::from_millis(500)).unwrap().0;
            }
        };
        if job.cancel.load(Ordering::Relaxed) {
            continue;
        }
        {
            let mut i = job.info.lock().unwrap();
            i.status = Status::Running;
            *job.started.lock().unwrap() = Some(Instant::now());
            (inner.sink)(&i);
        }
        let result = execute(&inner, &job);
        let mut i = job.info.lock().unwrap();
        i.elapsed_secs = job.started.lock().unwrap().map(|s| s.elapsed().as_secs_f64()).unwrap_or(0.0);
        i.eta_secs = None;
        match result {
            Ok(outs) => {
                i.status = Status::Done;
                i.progress = 1.0;
                i.out_bytes = outs.iter().map(|p| path_size(p)).sum();
                i.outputs = outs;
            }
            Err(e) if e.is_cancelled() || job.cancel.load(Ordering::Relaxed) => {
                i.status = Status::Cancelled;
                i.error = Some(ConvError::cancelled().user_message());
            }
            Err(e) => {
                i.status = Status::Failed;
                i.error = Some(e.user_message());
                if !e.details.is_empty() {
                    i.details.push_str("\n--- ошибка ---\n");
                    i.details.push_str(&e.details);
                }
            }
        }
        (inner.sink)(&i);
    }
}

/// Рабочая папка задачи; удаляется в любом случае (успех, ошибка, отмена).
struct WorkDir(PathBuf);
impl Drop for WorkDir {
    fn drop(&mut self) {
        let _ = fs::remove_dir_all(&self.0);
    }
}

fn execute(inner: &Inner, job: &Job) -> Result<Vec<PathBuf>, ConvError> {
    let req = &job.req;
    let engines = inner.engines.read().unwrap().clone();
    // 1. Входные файлы
    let mut inputs = Vec::new();
    for p in &req.inputs {
        if !p.exists() {
            return Err(ConvError::new(ErrKind::InputMissing, p.display().to_string()));
        }
        if p.is_file() {
            if let Err(e) = fs::File::open(p) {
                return Err(ConvError::from_io_read(&e, &p.display().to_string()));
            }
            if fs::metadata(p).map(|m| m.len() == 0).unwrap_or(false) {
                return Err(ConvError::new(ErrKind::BadData("Файл пустой (0 байт).".into()), p.display().to_string()));
            }
        }
        let f = detect(p).ok_or_else(|| ConvError::new(ErrKind::Unsupported, format!("неизвестный формат: {}", p.display())))?;
        inputs.push(Input { path: p.clone(), format: f });
    }
    let formats: Vec<_> = inputs.iter().map(|i| i.format).collect();
    let offers = inner.registry.offers_for_many(&formats, &engines);
    let offer = offers
        .into_iter()
        .find(|o| o.id == req.target)
        .ok_or_else(|| ConvError::new(ErrKind::Unsupported, format!("{} → {}", inputs[0].format.title, req.target)))?;
    {
        let mut i = job.info.lock().unwrap();
        i.target_title = offer.title.clone();
        i.src_title = inputs[0].format.title.to_string();
    }
    if let Some(m) = offer.missing.first() {
        return Err(ConvError::new(ErrKind::EngineMissing(*m), format!("нужен {}", m.title())));
    }

    // Права на запись проверяем до начала — чтобы не ждать час видео и упасть в конце
    let dest_dir = match &req.dest {
        Dest::Beside => inputs[0].path.parent().map(Path::to_path_buf).unwrap_or_else(|| PathBuf::from(".")),
        Dest::Folder(p) => p.clone(),
    };
    if !dest_dir.is_dir() {
        return Err(ConvError::new(ErrKind::BadData("Папка сохранения не найдена.".into()), dest_dir.display().to_string()));
    }
    naming::probe_writable(&dest_dir)?;

    // 2. Рабочая папка и план
    let work = work_root().join(job.info.lock().unwrap().id.to_string());
    let _ = fs::remove_dir_all(&work);
    fs::create_dir_all(&work).map_err(|e| ConvError::from_io_write(&e, "Временная папка"))?;
    let _guard = WorkDir(work.clone());
    let ctx = Ctx { inputs: &inputs, offer: &offer, opts: &req.options, engines: &engines, work: &work };
    let plan = inner.registry.plan(&ctx)?;
    let Plan { steps, output, stem } = plan;

    // 3. Выполнение шагов
    let total: f64 = steps.iter().map(|s| s.weight()).sum::<f64>().max(0.0001);
    let mut done_w = 0.0;
    let mut last_emit = Instant::now() - Duration::from_secs(1);
    for step in steps {
        if job.cancel.load(Ordering::Relaxed) {
            return Err(ConvError::cancelled());
        }
        let w = step.weight();
        {
            let mut i = job.info.lock().unwrap();
            i.details.push_str(&format!("$ {}\n", step.describe()));
        }
        match step {
            Step::Run { cmd, .. } => {
                let _slot = slots().acquire(cmd.engine, &job.cancel)?;
                let mut on_progress = |f: f64| {
                    let p = ((done_w + w * f) / total).clamp(0.0, 0.999);
                    if last_emit.elapsed() >= Duration::from_millis(150) {
                        last_emit = Instant::now();
                        update_progress(inner, job, p);
                    }
                };
                let log = run(&engines, &cmd, &job.cancel, &mut on_progress)?;
                let tail: String = log.lines().rev().take(20).collect::<Vec<_>>().into_iter().rev().collect::<Vec<_>>().join("\n");
                if !tail.trim().is_empty() {
                    job.info.lock().unwrap().details.push_str(&format!("{tail}\n"));
                }
            }
            Step::Func { f, .. } => f()?,
        }
        done_w += w;
        update_progress(inner, job, (done_w / total).min(0.999));
    }
    if job.cancel.load(Ordering::Relaxed) {
        return Err(ConvError::cancelled());
    }

    // 4. Перенос результата
    let first = &inputs[0];
    let stem = stem.unwrap_or_else(|| first.stem());
    // Никогда не перезаписываем исходник, даже при политике «Перезаписать»
    let protect = |path: &Path| inputs.iter().any(|i| same_file(&i.path, path));
    finalize(output, &dest_dir, &stem, offer.ext, req.conflict, &protect)
}

/// Своя временная папка у каждого процесса (и пользователя) — без конфликтов прав в общем /tmp.
pub fn work_root() -> PathBuf {
    std::env::temp_dir().join(format!("morph-work-{}", std::process::id()))
}

fn same_file(a: &Path, b: &Path) -> bool {
    match (fs::canonicalize(a), fs::canonicalize(b)) {
        (Ok(x), Ok(y)) => x == y,
        _ => false,
    }
}

fn update_progress(inner: &Inner, job: &Job, p: f64) {
    let mut i = job.info.lock().unwrap();
    i.progress = p;
    if let Some(start) = *job.started.lock().unwrap() {
        let el = start.elapsed().as_secs_f64();
        i.elapsed_secs = el;
        if p > 0.02 && el > 1.0 {
            let eta = el * (1.0 - p) / p;
            // сглаживание, чтобы цифра не прыгала
            i.eta_secs = Some(match i.eta_secs {
                Some(prev) => prev * 0.7 + eta * 0.3,
                None => eta,
            });
        }
    }
    (inner.sink)(&i);
}

fn reserve_safe(dir: &Path, stem: &str, ext: &str, policy: Conflict, is_dir: bool, protect: &dyn Fn(&Path) -> bool) -> Result<naming::Reserved, ConvError> {
    let target = naming::candidate(dir, &naming::sanitize(stem), ext, 0);
    let policy = if policy == Conflict::Overwrite && protect(&target) { Conflict::Suffix } else { policy };
    naming::reserve(dir, stem, ext, policy, is_dir)
}

fn non_empty(p: &Path) -> Result<(), ConvError> {
    match fs::metadata(p) {
        Ok(m) if m.is_dir() || m.len() > 0 => Ok(()),
        Ok(_) => Err(ConvError::new(ErrKind::Empty, format!("{} пуст", p.display()))),
        Err(_) => Err(ConvError::new(ErrKind::InputCorrupt, "конвертер не создал результат")),
    }
}

fn list_sorted(dir: &Path) -> Result<Vec<PathBuf>, ConvError> {
    let mut v: Vec<PathBuf> = fs::read_dir(dir).map_err(|e| ConvError::from_io_read(&e, "Результат"))?.flatten().map(|e| e.path()).collect();
    // естественная сортировка: страница 2 раньше страницы 10
    v.sort_by_key(|p| {
        let s = p.file_name().map(|s| s.to_string_lossy().to_string()).unwrap_or_default();
        let digits: String = s.chars().rev().skip_while(|c| !c.is_ascii_digit()).take_while(|c| c.is_ascii_digit()).collect::<String>().chars().rev().collect();
        (digits.len(), digits, s)
    });
    Ok(v)
}

fn finalize(output: Output, dest: &Path, stem: &str, ext: &str, policy: Conflict, protect: &dyn Fn(&Path) -> bool) -> Result<Vec<PathBuf>, ConvError> {
    match output {
        Output::File(p) => {
            non_empty(&p)?;
            let r = reserve_safe(dest, stem, ext, policy, false, protect)?;
            Ok(vec![naming::place(&p, r)?])
        }
        Output::Many { dir, ext: want } => {
            let files: Vec<PathBuf> = list_sorted(&dir)?.into_iter().filter(|p| p.is_file()).collect();
            let main: Vec<&PathBuf> = files.iter().filter(|p| split_name(&p.file_name().unwrap().to_string_lossy()).1 == want).collect();
            if main.is_empty() {
                return Err(ConvError::new(ErrKind::InputCorrupt, "конвертер не создал результат — исходный файл, вероятно, повреждён"));
            }
            if files.len() == 1 {
                non_empty(&files[0])?;
                let r = reserve_safe(dest, stem, ext, policy, false, protect)?;
                return Ok(vec![naming::place(&files[0], r)?]);
            }
            // Несколько файлов → папка «stem», внутри «stem-01.png» и т. д.
            let r = reserve_safe(dest, stem, "", policy, true, protect)?;
            let staging = dir.with_file_name("final");
            fs::create_dir_all(&staging).map_err(|e| ConvError::from_io_write(&e, "Результат"))?;
            for f in &files {
                let name = f.file_name().unwrap().to_string_lossy().to_string();
                let new_name = match name.strip_prefix("in") {
                    Some(rest) if rest.starts_with('-') || rest.starts_with('.') => format!("{}{}", naming::sanitize(stem), rest),
                    _ => name,
                };
                fs::rename(f, staging.join(new_name)).map_err(|e| ConvError::from_io_write(&e, "Результат"))?;
            }
            Ok(vec![naming::place(&staging, r)?])
        }
        Output::Dir(d) => {
            let entries = list_sorted(&d)?;
            if entries.is_empty() {
                return Err(ConvError::new(ErrKind::Empty, "архив пуст"));
            }
            if entries.len() == 1 {
                // Один элемент внутри архива — кладём его напрямую (как «Архиватор» macOS)
                let e = &entries[0];
                let name = e.file_name().unwrap().to_string_lossy().to_string();
                let is_dir = e.is_dir();
                let (s, x) = if is_dir { (name.clone(), String::new()) } else { split_name(&name) };
                let r = reserve_safe(dest, &s, &x, policy, is_dir, protect)?;
                return Ok(vec![naming::place(e, r)?]);
            }
            let r = reserve_safe(dest, stem, "", policy, true, protect)?;
            Ok(vec![naming::place(&d, r)?])
        }
    }
}

/// Цель объединяет все файлы в один результат (одна задача на всё выделение)
pub fn is_combine(target: &str) -> bool {
    target.ends_with("_all") || matches!(target, "merge_pdf" | "pdf_images")
}

/// Нужен ли пакетной операции итоговый файл-папка
pub fn is_folder_kind(k: Kind) -> bool {
    k == Kind::Folder
}
