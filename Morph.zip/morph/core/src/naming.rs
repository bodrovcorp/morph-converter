//! Имена выходных файлов: резервирование без гонок, суффикс « (1)», атомарный перенос результата.

use crate::error::ConvError;
use std::fs::{self, OpenOptions};
use std::io;
use std::path::{Path, PathBuf};

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Conflict {
    /// «имя (1).ext» — по умолчанию
    Suffix,
    /// перезаписать существующий файл
    Overwrite,
}

/// Зарезервированное место назначения. Если результат не перенесён — место освобождается в Drop.
#[derive(Debug)]
pub struct Reserved {
    pub path: PathBuf,
    pub is_dir: bool,
    placeholder: bool,
    committed: bool,
}

impl Reserved {
    pub fn commit(mut self) -> PathBuf {
        self.committed = true;
        self.path.clone()
    }
}

impl Drop for Reserved {
    fn drop(&mut self) {
        if !self.committed && self.placeholder {
            if self.is_dir {
                let _ = fs::remove_dir_all(&self.path);
            } else {
                let _ = fs::remove_file(&self.path);
            }
        }
    }
}

/// Имя-кандидат: «stem.ext», «stem (1).ext», «stem (2).ext», …
pub fn candidate(dir: &Path, stem: &str, ext: &str, n: u32) -> PathBuf {
    let base = if n == 0 { stem.to_string() } else { format!("{stem} ({n})") };
    if ext.is_empty() {
        dir.join(base)
    } else {
        dir.join(format!("{base}.{ext}"))
    }
}

/// Убирает символы, недопустимые в именах файлов Windows/macOS.
pub fn sanitize(stem: &str) -> String {
    let s: String = stem
        .chars()
        .map(|c| if matches!(c, '/' | '\\' | ':' | '*' | '?' | '"' | '<' | '>' | '|') || (c as u32) < 0x20 { '_' } else { c })
        .collect();
    let s = s.trim().trim_end_matches('.').to_string();
    if s.is_empty() {
        "file".into()
    } else {
        s
    }
}

/// Резервирует путь для файла (или папки, если `ext` пуст и `dir_out`).
pub fn reserve(dir: &Path, stem: &str, ext: &str, policy: Conflict, dir_out: bool) -> Result<Reserved, ConvError> {
    let stem = sanitize(stem);
    if policy == Conflict::Overwrite {
        let p = candidate(dir, &stem, ext, 0);
        // проверим, что в папку вообще можно писать
        probe_writable(dir)?;
        if dir_out && p.is_dir() {
            // перезапись папки: старую удалим при переносе
        }
        return Ok(Reserved { path: p, is_dir: dir_out, placeholder: false, committed: false });
    }
    for n in 0..10_000 {
        let p = candidate(dir, &stem, ext, n);
        let res = if dir_out {
            fs::create_dir(&p)
        } else {
            OpenOptions::new().write(true).create_new(true).open(&p).map(|_| ())
        };
        match res {
            Ok(()) => return Ok(Reserved { path: p, is_dir: dir_out, placeholder: true, committed: false }),
            Err(e) if e.kind() == io::ErrorKind::AlreadyExists => continue,
            // На Windows занятое папкой имя при create_new даёт PermissionDenied
            Err(e) if e.kind() == io::ErrorKind::PermissionDenied && p.exists() => continue,
            Err(e) => return Err(ConvError::from_io_write(&e, &format!("Создание {}", p.display()))),
        }
    }
    Err(ConvError::new(crate::error::ErrKind::Internal, "не удалось подобрать свободное имя"))
}

pub fn probe_writable(dir: &Path) -> Result<(), ConvError> {
    let probe = dir.join(format!(".morph-write-test-{}", std::process::id()));
    match OpenOptions::new().write(true).create(true).truncate(true).open(&probe) {
        Ok(_) => {
            let _ = fs::remove_file(&probe);
            Ok(())
        }
        Err(e) => Err(ConvError::from_io_write(&e, &format!("Запись в {}", dir.display()))),
    }
}

/// Переносит готовый результат на зарезервированное место.
/// Сначала пробуем rename (мгновенно, атомарно), при другом томе — копирование.
pub fn place(tmp: &Path, reserved: Reserved) -> Result<PathBuf, ConvError> {
    let dst = reserved.path.clone();
    if reserved.is_dir {
        if dst.exists() {
            fs::remove_dir_all(&dst).map_err(|e| ConvError::from_io_write(&e, "Подготовка папки"))?;
        }
        if fs::rename(tmp, &dst).is_err() {
            copy_dir(tmp, &dst).map_err(|e| ConvError::from_io_write(&e, "Копирование результата"))?;
        }
        return Ok(reserved.commit());
    }
    match fs::rename(tmp, &dst) {
        Ok(()) => Ok(reserved.commit()),
        Err(_) => {
            // другой диск: копируем во временное имя рядом и переименовываем
            let part = dst.with_file_name(format!(
                ".{}.morph-part",
                dst.file_name().map(|s| s.to_string_lossy().to_string()).unwrap_or_default()
            ));
            let r = fs::copy(tmp, &part).and_then(|_| fs::rename(&part, &dst));
            if let Err(e) = r {
                let _ = fs::remove_file(&part);
                return Err(ConvError::from_io_write(&e, "Сохранение результата"));
            }
            let _ = fs::remove_file(tmp);
            Ok(reserved.commit())
        }
    }
}

pub fn copy_dir(src: &Path, dst: &Path) -> io::Result<()> {
    fs::create_dir_all(dst)?;
    for entry in fs::read_dir(src)? {
        let entry = entry?;
        let to = dst.join(entry.file_name());
        if entry.file_type()?.is_dir() {
            copy_dir(&entry.path(), &to)?;
        } else {
            fs::copy(entry.path(), &to)?;
        }
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    fn tmpdir(name: &str) -> PathBuf {
        let d = std::env::temp_dir().join(format!("morph-naming-{name}-{}", std::process::id()));
        let _ = fs::remove_dir_all(&d);
        fs::create_dir_all(&d).unwrap();
        d
    }

    #[test]
    fn suffixes() {
        let d = tmpdir("suffix");
        fs::write(d.join("фото отпуск.jpg"), b"x").unwrap();
        let r1 = reserve(&d, "фото отпуск", "jpg", Conflict::Suffix, false).unwrap();
        assert_eq!(r1.path.file_name().unwrap(), "фото отпуск (1).jpg");
        let r2 = reserve(&d, "фото отпуск", "jpg", Conflict::Suffix, false).unwrap();
        assert_eq!(r2.path.file_name().unwrap(), "фото отпуск (2).jpg");
        drop(r1); // не закоммичен — место освобождается
        assert!(!d.join("фото отпуск (1).jpg").exists());
        let _ = r2.commit();
        assert!(d.join("фото отпуск (2).jpg").exists());
    }

    #[test]
    fn sanitizes() {
        assert_eq!(sanitize("a/b:c?"), "a_b_c_");
        assert_eq!(sanitize("  ."), "file");
    }

    #[test]
    fn places_file() {
        let d = tmpdir("place");
        let tmp = d.join("tmp.bin");
        fs::write(&tmp, b"hello").unwrap();
        let r = reserve(&d, "итог", "bin", Conflict::Suffix, false).unwrap();
        let p = place(&tmp, r).unwrap();
        assert_eq!(fs::read(p).unwrap(), b"hello");
    }
}
