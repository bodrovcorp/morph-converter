//! Аудио: FFmpeg.

use super::mkdir;
use crate::engines::{media_duration_us, Cmd, EngineId, Engines, ProgressKind};
use crate::error::ConvError;
use crate::formats::{by_id, Format, Kind};
use crate::options::{OptKind, Options};
use crate::registry::{Converter, Ctx, Offer, Output, Plan, Step};

pub struct AudioConverter;
const NAME: &str = "audio";

pub fn codec_args(target: &str, o: &Options) -> Vec<String> {
    let br = format!("{}k", o.audio_bitrate);
    let v: Vec<&str> = match target {
        "mp3" => vec!["-c:a", "libmp3lame", "-b:a", &br],
        "m4a" => vec!["-c:a", "aac", "-b:a", &br, "-movflags", "+faststart"],
        "aac" => vec!["-c:a", "aac", "-b:a", &br, "-f", "adts"],
        "wav" => vec!["-c:a", "pcm_s16le"],
        "aiff" => vec!["-c:a", "pcm_s16be"],
        "flac" => vec!["-c:a", "flac"],
        "ogg" => vec!["-c:a", "libvorbis", "-q:a", "5"],
        "opus" => vec!["-c:a", "libopus", "-b:a", if o.audio_bitrate > 160 { "160k" } else { &br }],
        "wma" => vec!["-c:a", "wmav2", "-b:a", &br],
        _ => vec![],
    };
    v.into_iter().map(String::from).collect()
}

impl Converter for AudioConverter {
    fn name(&self) -> &'static str {
        NAME
    }
    fn offers(&self, src: &'static Format, e: &Engines) -> Vec<Offer> {
        if src.kind != Kind::Audio {
            return Vec::new();
        }
        let mut v = Vec::new();
        for (id, rank, pop) in [("mp3", 1, true), ("m4a", 2, true), ("wav", 3, true), ("flac", 4, true), ("ogg", 10, false), ("opus", 11, false), ("aac", 12, false), ("aiff", 13, false), ("wma", 14, false)] {
            if id == src.id {
                continue;
            }
            let mut o = Offer::to(NAME, by_id(id).unwrap()).rank(rank).needs(e, &[&[EngineId::Ffmpeg]]);
            if pop {
                o = o.pop(rank);
            }
            if matches!(id, "mp3" | "m4a" | "aac" | "opus" | "wma") {
                o = o.opts(&[OptKind::AudioBitrate]);
            }
            v.push(o);
        }
        v
    }
    fn plan(&self, ctx: &Ctx) -> Result<Plan, ConvError> {
        let inp = &ctx.input().path;
        let out_dir = ctx.out("out");
        mkdir(&out_dir)?;
        let out = out_dir.join(format!("out.{}", ctx.offer.ext));
        let dur = media_duration_us(ctx.engines, inp).unwrap_or(0);
        let c = Cmd::new(EngineId::Ffmpeg)
            .args(["-hide_banner", "-loglevel", "error", "-nostats", "-progress", "pipe:1", "-y", "-i"])
            .arg(inp)
            .args(["-vn", "-map_metadata", "0"])
            .args(codec_args(&ctx.offer.id, ctx.opts))
            .arg(&out)
            .progress(ProgressKind::FfmpegTime { duration_us: dur });
        Ok(Plan::new(vec![Step::run(c)], Output::File(out)))
    }
}
