//! Таблицы: CSV/TSV ↔ XLSX/XLS/ODS, JSON ↔ CSV/XLSX, таблицы → PDF.
//! Кодировка CSV (UTF-8, Windows-1251, KOI8-R, UTF-16) и разделитель определяются автоматически.

use super::{expect_file, lo, mkdir};
use crate::engines::{EngineId, Engines};
use crate::error::{ConvError, ErrKind};
use crate::formats::{by_id, Format, Kind};
use crate::options::OptKind;
use crate::registry::{Converter, Ctx, Offer, Output, Plan, Step};
use crate::text::{csv, encoding, json};
use std::fs;
use std::path::{Path, PathBuf};

pub struct SheetConverter;
const NAME: &str = "sheet";

fn lo_filter(dst: &str) -> &'static str {
    match dst {
        "xlsx" => "xlsx:Calc MS Excel 2007 XML",
        "xls" => "xls:MS Excel 97",
        "ods" => "ods",
        "pdf" => "pdf:calc_pdf_Export",
        "html" => "html:HTML (StarCalc)",
        _ => "xlsx",
    }
}

/// Читает CSV/TSV любой кодировки → (таблица, разделитель)
pub fn read_csv(path: &Path, tsv: bool) -> Result<(csv::Table, char), ConvError> {
    let bytes = fs::read(path).map_err(|e| ConvError::from_io_read(&e, "Чтение CSV"))?;
    let (text, _) = encoding::decode(&bytes);
    if text.trim().is_empty() {
        return Err(ConvError::new(ErrKind::Empty, "CSV пуст"));
    }
    let d = if tsv { '\t' } else { csv::sniff_delimiter(&text) };
    Ok((csv::parse(&text, d), d))
}

pub fn write_csv(path: &Path, t: &csv::Table, delim: char, bom: bool) -> Result<(), ConvError> {
    let mut s = String::new();
    if bom {
        s.push('\u{feff}');
    }
    s.push_str(&csv::write(t, delim));
    fs::write(path, s).map_err(|e| ConvError::from_io_write(&e, "Запись CSV"))
}

/// Похоже ли, что числа записаны с десятичной запятой (русская локаль)
fn decimal_comma(t: &csv::Table) -> bool {
    t.iter().skip(1).take(50).flatten().any(|c| {
        let c = c.trim();
        c.contains(',') && !c.contains('.') && c.replace(',', "").chars().all(|x| x.is_ascii_digit() || x == '-') && c.chars().filter(|x| *x == ',').count() == 1
    })
}

impl Converter for SheetConverter {
    fn name(&self) -> &'static str {
        NAME
    }

    fn offers(&self, src: &'static Format, e: &Engines) -> Vec<Offer> {
        let lo_need: &[&[EngineId]] = &[&[EngineId::Soffice]];
        let csv_opts = [OptKind::CsvBom];
        let mk = |id: &str, rank: u16, pop: bool| {
            let mut o = Offer::to(NAME, by_id(id).unwrap()).rank(rank);
            if pop {
                o = o.pop(rank);
            }
            o
        };
        let mut v = Vec::new();
        match src.id {
            "csv" | "tsv" => {
                v.push(mk("xlsx", 1, true).needs(e, lo_need));
                v.push(mk("json", 2, true));
                v.push(mk("pdf", 3, true).needs(e, lo_need));
                v.push(mk("ods", 10, false).needs(e, lo_need));
                v.push(mk("xls", 11, false).needs(e, lo_need));
                if src.id == "csv" {
                    v.push(mk("tsv", 12, false));
                } else {
                    v.push(mk("csv", 12, true).opts(&csv_opts));
                }
                v.push(mk("html", 13, false).needs(e, lo_need));
            }
            "xlsx" | "xls" | "ods" => {
                v.push(mk("csv", 1, true).opts(&csv_opts).needs(e, lo_need));
                v.push(mk("pdf", 2, true).needs(e, lo_need));
                v.push(mk("json", 3, true).needs(e, lo_need));
                for (id, r) in [("xlsx", 4), ("ods", 10), ("xls", 11)] {
                    if id != src.id {
                        v.push(mk(id, r, id == "xlsx").needs(e, lo_need));
                    }
                }
                v.push(mk("html", 12, false).needs(e, lo_need));
            }
            "json" => {
                v.push(mk("csv", 1, true).opts(&csv_opts));
                v.push(mk("xlsx", 2, true).needs(e, lo_need));
                v.push(mk("ods", 10, false).needs(e, lo_need));
            }
            _ => {}
        }
        for o in v.iter_mut() {
            if o.id == "pdf" {
                o.desc = "Таблица для печати".into();
            }
            if o.kind != Kind::Spreadsheet && o.id != "pdf" {
                o.kind = Kind::Spreadsheet;
            }
        }
        v
    }

    fn plan(&self, ctx: &Ctx) -> Result<Plan, ConvError> {
        let src = ctx.input().format.id;
        let dst = ctx.offer.id.clone();
        let input = ctx.input().path.clone();
        let out_dir = ctx.out("out");
        mkdir(&out_dir)?;
        let o = ctx.opts.clone();
        let tsv = src == "tsv";

        match (src, dst.as_str()) {
            // CSV → CSV/TSV (смена разделителя/кодировки) и CSV → JSON — встроенными средствами
            ("csv" | "tsv", "json") => {
                let out = out_dir.join("out.json");
                let out2 = out.clone();
                Ok(Plan::new(
                    vec![Step::func("CSV → JSON", move || {
                        let (t, d) = read_csv(&input, tsv)?;
                        let dc = d == ';' && decimal_comma(&t);
                        fs::write(&out2, json::to_string_pretty(&json::from_table_ex(&t, dc))).map_err(|e| ConvError::from_io_write(&e, "Запись JSON"))
                    })],
                    Output::File(out),
                ))
            }
            ("csv" | "tsv", "csv" | "tsv") => {
                let out = out_dir.join(format!("out.{dst}"));
                let out2 = out.clone();
                let d = if dst == "tsv" { '\t' } else { o.csv_delimiter };
                Ok(Plan::new(
                    vec![Step::func("CSV → CSV", move || {
                        let (t, _) = read_csv(&input, tsv)?;
                        write_csv(&out2, &t, d, o.csv_bom && d != '\t')
                    })],
                    Output::File(out),
                ))
            }
            ("json", "csv") => {
                let out = out_dir.join("out.csv");
                let out2 = out.clone();
                Ok(Plan::new(vec![Step::func("JSON → CSV", move || json_to_csv(&input, &out2, o.csv_delimiter, o.csv_bom))], Output::File(out)))
            }
            ("json", _) => {
                // JSON → CSV (UTF-8, запятая) → LibreOffice
                let mid = ctx.out("src");
                mkdir(&mid)?;
                let csvp = mid.join("in.csv");
                let c2 = csvp.clone();
                let steps = vec![
                    Step::func("JSON → CSV", move || json_to_csv(&input, &c2, ',', false)),
                    Step::run(lo(&csvp, lo_filter(&dst), Some("CSV:44,34,76,1,,1033"), &out_dir)),
                ];
                Ok(Plan::new(steps, Output::Many { dir: out_dir, ext: ctx.offer.ext }))
            }
            ("csv" | "tsv", _) => {
                // Нормализуем CSV: UTF-8, тот же разделитель; язык — по десятичному разделителю
                let mid = ctx.out("src");
                mkdir(&mid)?;
                let norm = mid.join("in.csv");
                let (t, d) = read_csv(&input, tsv)?;
                let lang = if d == ';' && decimal_comma(&t) { 1049 } else { 1033 };
                write_csv(&norm, &t, d, false)?;
                let infilter = format!("CSV:{},34,76,1,,{}", d as u32, lang);
                let steps = vec![Step::run(lo(&norm, lo_filter(&dst), Some(&infilter), &out_dir))];
                Ok(Plan::new(steps, Output::Many { dir: out_dir, ext: ctx.offer.ext }))
            }
            (_, "csv") => {
                // Все листы книги: каждый — отдельный CSV (LibreOffice 7.2+)
                let d = o.csv_delimiter as u32;
                let filter = format!("csv:Text - txt - csv (StarCalc):{d},34,76,1,,0,false,true,false,false,false,-1");
                let dir2 = out_dir.clone();
                let bom = o.csv_bom;
                let steps = vec![
                    Step::run(lo(&input, &filter, None, &out_dir)),
                    Step::func("BOM для Excel", move || if bom { add_bom_all(&dir2) } else { Ok(()) }),
                ];
                Ok(Plan::new(steps, Output::Many { dir: out_dir, ext: "csv" }))
            }
            (_, "json") => {
                let mid = ctx.out("mid");
                mkdir(&mid)?;
                let out = out_dir.join("out.json");
                let (m2, out2) = (mid.clone(), out.clone());
                let steps = vec![
                    Step::run(lo(&input, "csv:Text - txt - csv (StarCalc):44,34,76,1", None, &mid)),
                    Step::func("CSV → JSON", move || {
                        let f = first_file(&m2, "csv")?;
                        let (t, _) = read_csv(&f, false)?;
                        fs::write(&out2, json::to_string_pretty(&json::from_table(&t))).map_err(|e| ConvError::from_io_write(&e, "Запись JSON"))
                    }),
                    Step::func("проверка", expect_file(out.clone(), "JSON")),
                ];
                Ok(Plan::new(steps, Output::File(out)))
            }
            _ => Ok(Plan::new(vec![Step::run(lo(&input, lo_filter(&dst), None, &out_dir))], Output::Many { dir: out_dir, ext: ctx.offer.ext })),
        }
    }
}

fn json_to_csv(input: &Path, out: &Path, delim: char, bom: bool) -> Result<(), ConvError> {
    let bytes = fs::read(input).map_err(|e| ConvError::from_io_read(&e, "Чтение JSON"))?;
    let (text, _) = encoding::decode(&bytes);
    let v = json::parse(&text).map_err(|e| ConvError::new(ErrKind::InputCorrupt, format!("JSON не разобран (позиция {}): {}", e.pos, e.msg)))?;
    let t = json::to_table(&v).map_err(|m| ConvError::new(ErrKind::BadData(m.to_string()), m))?;
    write_csv(out, &t, delim, bom)
}

fn add_bom_all(dir: &Path) -> Result<(), ConvError> {
    for e in fs::read_dir(dir).map_err(|e| ConvError::from_io_read(&e, "Папка"))?.flatten() {
        let p = e.path();
        if p.extension().map(|x| x == "csv").unwrap_or(false) {
            let b = fs::read(&p).map_err(|e| ConvError::from_io_read(&e, "CSV"))?;
            if !b.starts_with(&[0xEF, 0xBB, 0xBF]) {
                let mut nb = vec![0xEF, 0xBB, 0xBF];
                nb.extend_from_slice(&b);
                fs::write(&p, nb).map_err(|e| ConvError::from_io_write(&e, "CSV"))?;
            }
        }
    }
    Ok(())
}

fn first_file(dir: &Path, ext: &str) -> Result<PathBuf, ConvError> {
    let mut v: Vec<PathBuf> = fs::read_dir(dir)
        .map_err(|e| ConvError::from_io_read(&e, "Папка"))?
        .flatten()
        .map(|e| e.path())
        .filter(|p| p.extension().map(|x| x == ext).unwrap_or(false))
        .collect();
    v.sort();
    v.into_iter().next().ok_or_else(|| ConvError::new(ErrKind::InputCorrupt, "LibreOffice не смог прочитать таблицу"))
}
