//! Видео: FFmpeg. Быстрая перепаковка без перекодирования, когда кодеки совместимы.

use super::mkdir;
use crate::engines::{media_codecs, media_duration_us, Cmd, EngineId, Engines, ProgressKind};
use crate::error::ConvError;
use crate::formats::{by_id, Format, Kind};
use crate::options::{OptKind, Options, VideoQuality};
use crate::registry::{Converter, Ctx, Offer, Output, Plan, Step};

pub struct VideoConverter;
const NAME: &str = "video";

fn is_video_src(f: &Format) -> bool {
    f.kind == Kind::Video || f.id == "gif"
}

impl Converter for VideoConverter {
    fn name(&self) -> &'static str {
        NAME
    }

    fn offers(&self, src: &'static Format, e: &Engines) -> Vec<Offer> {
        if !is_video_src(src) {
            return Vec::new();
        }
        let need: &[&[EngineId]] = &[&[EngineId::Ffmpeg]];
        let vopts = [OptKind::VideoQuality, OptKind::VideoHeight, OptKind::NoAudio];
        let mut v = Vec::new();
        let mut add = |o: Offer| v.push(o.needs(e, need));
        let anim = src.id == "gif";
        for (id, rank, pop) in [("mp4", 1, true), ("webm", 3, false), ("mov", 5, false), ("mkv", 6, false), ("avi", 7, false)] {
            if id == src.id {
                continue;
            }
            let mut o = Offer::to(NAME, by_id(id).unwrap()).rank(rank).opts(&vopts);
            if pop || (anim && id == "webm") {
                o = o.pop(rank);
            }
            add(o);
        }
        if !anim {
            add(Offer::new(NAME, "mp4_small", "mp4", "Сжать видео", "MP4 меньшего размера", Kind::Video).pop(2).opts(&[OptKind::VideoQuality, OptKind::VideoHeight]));
            add(Offer::new(NAME, "gif", "gif", "GIF", "Анимация из видео", Kind::Image).pop(4).opts(&[OptKind::Gif]));
            // извлечение звука
            for (id, rank, pop) in [("mp3", 5, true), ("m4a", 20, false), ("wav", 21, false), ("flac", 22, false), ("ogg", 23, false), ("opus", 24, false)] {
                let f = by_id(id).unwrap();
                let mut o = Offer::new(NAME, id, f.ext(), &format!("{} (звук)", f.title), "Извлечь аудиодорожку", Kind::Audio).rank(rank).opts(&[OptKind::AudioBitrate]);
                if pop {
                    o = o.pop(rank);
                }
                add(o);
            }
        }
        v
    }

    fn plan(&self, ctx: &Ctx) -> Result<Plan, ConvError> {
        let inp = &ctx.input().path;
        let o = ctx.opts;
        let out_dir = ctx.out("out");
        mkdir(&out_dir)?;
        let target = ctx.offer.id.as_str();
        let out = out_dir.join(format!("out.{}", ctx.offer.ext));
        let dur = media_duration_us(ctx.engines, inp).unwrap_or(0);
        let mut c = Cmd::new(EngineId::Ffmpeg)
            .args(["-hide_banner", "-loglevel", "error", "-nostats", "-progress", "pipe:1", "-y", "-i"])
            .arg(inp)
            .progress(ProgressKind::FfmpegTime { duration_us: dur });

        // Аудио из видео
        if crate::formats::by_id(target).map(|f| f.kind == Kind::Audio).unwrap_or(false) {
            c = c.args(["-vn", "-sn", "-map_metadata", "0"]);
            c = c.args(super::audio::codec_args(target, o));
            return Ok(Plan::new(vec![Step::run(c.arg(&out))], Output::File(out)));
        }

        if target == "gif" {
            let vf = format!(
                "fps={},scale='min({},iw)':-1:flags=lanczos,split[s0][s1];[s0]palettegen=stats_mode=diff[p];[s1][p]paletteuse=dither=bayer:bayer_scale=5",
                o.gif_fps, o.gif_width
            );
            c = c.arg("-vf").arg(vf).args(["-loop", "0"]);
            return Ok(Plan::new(vec![Step::run(c.arg(&out))], Output::File(out)));
        }

        let small = target == "mp4_small";
        let mut opts = o.clone();
        if small && opts.video_quality == VideoQuality::Balanced {
            opts.video_quality = VideoQuality::Small;
        }
        let height = if small { Some(opts.video_height.unwrap_or(1080)) } else { opts.video_height };

        // Быстрый путь: перепаковка без перекодирования (MKV → MP4 и т. п.)
        let container = ctx.offer.ext;
        if !small && height.is_none() && opts.video_quality == VideoQuality::Balanced && matches!(container, "mp4" | "mov" | "mkv") {
            let (vc, ac) = media_codecs(ctx.engines, inp);
            let v_ok = matches!(vc.as_deref(), Some("h264") | Some("hevc"))
                || (container == "mkv" && matches!(vc.as_deref(), Some("vp9") | Some("av1") | Some("vp8") | Some("mpeg4")));
            // У MPEG-PS/TS/AVI бывают пакеты без меток времени — такие только перекодируем
            let v_ok = v_ok && !matches!(ctx.input().format.id, "mpeg" | "avi" | "flv" | "wmv");
            let a_ok = match ac.as_deref() {
                None => true,
                Some("aac") | Some("mp3") | Some("alac") => true,
                Some(_) => container == "mkv",
            };
            if v_ok && a_ok && ctx.input().format.id != "gif" {
                c = c.args(["-map", "0:v:0", "-map", "0:a?", "-c", "copy"]);
                if opts.no_audio {
                    c = c.arg("-an");
                }
                if vc.as_deref() == Some("hevc") && container != "mkv" {
                    c = c.args(["-tag:v", "hvc1"]);
                }
                if container != "mkv" {
                    c = c.args(["-movflags", "+faststart"]);
                }
                return Ok(Plan::new(vec![Step::run(c.arg(&out))], Output::File(out)));
            }
        }

        let scale = match height {
            Some(h) => format!("scale=-2:'min({h},ih)'"),
            None => "scale=trunc(iw/2)*2:trunc(ih/2)*2".to_string(),
        };
        c = c.args(["-map", "0:v:0"]);
        if !opts.no_audio && ctx.input().format.id != "gif" {
            c = c.args(["-map", "0:a?"]);
        }
        c = c.arg("-vf").arg(scale);
        c = c.args(video_codec_args(container, &opts, ctx.engines));
        if opts.no_audio || ctx.input().format.id == "gif" {
            c = c.arg("-an");
        } else {
            c = c.args(match container {
                "webm" => vec!["-c:a", "libopus", "-b:a", "128k"],
                "avi" => vec!["-c:a", "libmp3lame", "-b:a", "192k"],
                _ => {
                    if small {
                        vec!["-c:a", "aac", "-b:a", "96k"]
                    } else {
                        vec!["-c:a", "aac", "-b:a", "160k"]
                    }
                }
            });
        }
        if matches!(container, "mp4" | "mov") {
            c = c.args(["-movflags", "+faststart"]);
        }
        Ok(Plan::new(vec![Step::run(c.arg(&out))], Output::File(out)))
    }
}

/// Аргументы видеокодека с учётом того, какие кодировщики есть в сборке FFmpeg.
fn video_codec_args(container: &str, o: &Options, e: &Engines) -> Vec<String> {
    let s = |v: &[&str]| v.iter().map(|x| x.to_string()).collect::<Vec<_>>();
    match container {
        "webm" => {
            let mut v = s(&["-c:v", "libvpx-vp9", "-b:v", "0", "-crf"]);
            v.push(o.crf_vp9().to_string());
            v.extend(s(&["-row-mt", "1", "-deadline", "good", "-cpu-used", "4", "-pix_fmt", "yuv420p"]));
            v
        }
        "avi" => s(&["-c:v", "mpeg4", "-q:v", if o.video_quality == VideoQuality::High { "2" } else { "4" }, "-tag:v", "XVID"]),
        _ => {
            if e.ff_encoder("libx264") {
                let mut v = s(&["-c:v", "libx264", "-preset", "medium", "-crf"]);
                v.push(o.crf_h264().to_string());
                v.extend(s(&["-pix_fmt", "yuv420p"]));
                v
            } else if e.ff_encoder("h264_videotoolbox") {
                // аппаратный кодировщик macOS (LGPL-сборка FFmpeg)
                let q = match o.video_quality {
                    VideoQuality::High => "75",
                    VideoQuality::Balanced => "60",
                    VideoQuality::Small => "45",
                };
                s(&["-c:v", "h264_videotoolbox", "-q:v", q, "-pix_fmt", "yuv420p"])
            } else if e.ff_encoder("h264_mf") {
                // Media Foundation в Windows
                s(&["-c:v", "h264_mf", "-rate_control", "quality", "-quality", "70", "-pix_fmt", "yuv420p"])
            } else {
                s(&["-c:v", "mpeg4", "-q:v", "3"])
            }
        }
    }
}
