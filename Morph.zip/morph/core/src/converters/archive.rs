//! Архивы: распаковка и упаковка ZIP / 7Z / TAR.GZ / TAR / TAR.BZ2 / TAR.XZ (+ распаковка RAR).
//! Основной движок — bsdtar (встроен в macOS и Windows 10/11), запасные — 7-Zip, zip/unzip, GNU tar.

use super::mkdir;
use crate::engines::{Cmd, EngineId, Engines};
use crate::error::{ConvError, ErrKind};
use crate::formats::{by_id, Format, Kind};
use crate::registry::{Converter, Ctx, Input, Offer, Output, Plan, Step};
use std::path::{Path, PathBuf};

pub struct ArchiveConverter;
const NAME: &str = "archive";

#[derive(Clone, Copy, PartialEq, Debug)]
enum Tool {
    SevenZip,
    BsdTar,
    GnuTar,
    Zip,
    Unzip,
}

fn can_unpack(src: &str, e: &Engines) -> Option<Tool> {
    if e.has(EngineId::SevenZip) {
        return Some(Tool::SevenZip);
    }
    if e.has(EngineId::Tar) && e.caps.tar_bsd {
        return Some(Tool::BsdTar);
    }
    match src {
        "zip" if e.has(EngineId::Unzip) => Some(Tool::Unzip),
        "targz" | "tar" | "tarbz2" | "tarxz" if e.has(EngineId::Tar) => Some(Tool::GnuTar),
        _ => None,
    }
}

fn can_pack(dst: &str, e: &Engines) -> Option<Tool> {
    if e.has(EngineId::Tar) && e.caps.tar_bsd {
        return Some(Tool::BsdTar);
    }
    if e.has(EngineId::SevenZip) {
        return Some(Tool::SevenZip);
    }
    match dst {
        "zip" if e.has(EngineId::Zip) => Some(Tool::Zip),
        "targz" | "tar" | "tarbz2" | "tarxz" if e.has(EngineId::Tar) => Some(Tool::GnuTar),
        _ => None,
    }
}

fn missing(t: Option<Tool>) -> Vec<EngineId> {
    if t.is_some() {
        vec![]
    } else {
        vec![EngineId::Tar]
    }
}

const PACK: &[(&str, &str, &str)] = &[("zip", "ZIP-архив", "Открывается везде"), ("7z", "7Z-архив", "Сильнее сжатие"), ("targz", "TAR.GZ-архив", "Linux, macOS")];

impl Converter for ArchiveConverter {
    fn name(&self) -> &'static str {
        NAME
    }

    fn offers(&self, src: &'static Format, e: &Engines) -> Vec<Offer> {
        let mut v = Vec::new();
        if src.kind == Kind::Archive {
            v.push(Offer::new(NAME, "unpack", "", "Распаковать", "В папку рядом с архивом", Kind::Archive).pop(1).missing(missing(can_unpack(src.id, e))));
            if src.id != "rar" || e.has(EngineId::SevenZip) || e.caps.tar_bsd || e.assume_all {
                for (i, &(id, title, desc)) in PACK.iter().enumerate() {
                    if id != src.id {
                        let f = by_id(id).unwrap();
                        let unpack_ok = can_unpack(src.id, e).is_some();
                        let mut o = Offer::new(NAME, id, f.ext(), f.title, desc, Kind::Archive).rank(10 + i as u16);
                        let _ = title;
                        if !unpack_ok || can_pack(id, e).is_none() {
                            o.missing = vec![EngineId::Tar];
                        }
                        v.push(o);
                    }
                }
            }
            return v;
        }
        // Любой файл или папку можно упаковать
        for (i, &(id, title, desc)) in PACK.iter().enumerate() {
            let f = by_id(id).unwrap();
            let mut o = Offer::new(NAME, id, f.ext(), title, desc, Kind::Archive).rank(900 + i as u16).missing(missing(can_pack(id, e)));
            if src.kind == Kind::Folder {
                o = o.pop(1 + i as u16);
            }
            v.push(o);
        }
        v
    }

    fn combine_offers(&self, _srcs: &[&'static Format], e: &Engines) -> Vec<Offer> {
        PACK.iter()
            .enumerate()
            .map(|(i, &(id, title, desc))| {
                let f = by_id(id).unwrap();
                let mut o = Offer::new(NAME, &format!("{id}_all"), f.ext(), &format!("{title} из всех"), desc, Kind::Archive).rank(5 + i as u16).missing(missing(can_pack(id, e)));
                if i == 0 {
                    o = o.pop(5);
                }
                o.combine = true;
                o
            })
            .collect()
    }

    fn plan(&self, ctx: &Ctx) -> Result<Plan, ConvError> {
        let e = ctx.engines;
        let id = ctx.offer.id.trim_end_matches("_all").to_string();
        let src = ctx.input().format;
        let out_dir = ctx.out("out");
        mkdir(&out_dir)?;
        let mut steps = Vec::new();

        // Распаковка
        if id == "unpack" {
            let tool = can_unpack(src.id, e).ok_or_else(|| ConvError::new(ErrKind::EngineMissing(EngineId::Tar), "нет распаковщика"))?;
            steps.push(Step::run(unpack_cmd(tool, &ctx.input().path, &out_dir)));
            return Ok(Plan::new(steps, Output::Dir(out_dir)));
        }

        let out = out_dir.join(format!("out.{}", ctx.offer.ext));
        let tool = can_pack(&id, e).ok_or_else(|| ConvError::new(ErrKind::EngineMissing(EngineId::Tar), "нет архиватора"))?;

        // Архив → архив: распаковываем во временную папку и упаковываем её содержимое
        if src.kind == Kind::Archive && !ctx.offer.combine {
            let utool = can_unpack(src.id, e).ok_or_else(|| ConvError::new(ErrKind::EngineMissing(EngineId::Tar), "нет распаковщика"))?;
            let x = ctx.out("x");
            mkdir(&x)?;
            steps.push(Step::run_w(unpack_cmd(utool, &ctx.input().path, &x), 0.5));
            let x2 = x.clone();
            // Содержимое папки становится известно только после распаковки — передаём «.»
            steps.push(Step::run(pack_cmd(tool, &id, &out, &x2, &[PathBuf::from(".")], true)));
            return Ok(Plan::new(steps, Output::File(out)));
        }

        // Файлы/папки → архив. Пути — относительно общей папки, чтобы в архиве не было полных путей.
        let (base, names) = common_base(ctx.inputs);
        steps.push(Step::run(pack_cmd(tool, &id, &out, &base, &names, false)));
        let mut p = Plan::new(steps, Output::File(out));
        if ctx.inputs.len() > 1 {
            p.stem = Some(format!("{} + ещё {}", ctx.input().stem(), ctx.inputs.len() - 1));
        }
        Ok(p)
    }
}

fn common_base(inputs: &[Input]) -> (PathBuf, Vec<PathBuf>) {
    let base = inputs[0].path.parent().map(Path::to_path_buf).unwrap_or_default();
    let names = inputs
        .iter()
        .map(|i| {
            if i.path.parent() == Some(base.as_path()) {
                PathBuf::from(i.path.file_name().unwrap())
            } else {
                i.path.clone()
            }
        })
        .collect();
    (base, names)
}

fn unpack_cmd(tool: Tool, archive: &Path, dest: &Path) -> Cmd {
    match tool {
        Tool::SevenZip => Cmd::new(EngineId::SevenZip).args(["x", "-y", "-bso0", "-bsp0"]).arg(format!("-o{}", dest.display())).arg(archive),
        Tool::BsdTar | Tool::GnuTar => Cmd::new(EngineId::Tar).arg("-xf").arg(archive).arg("-C").arg(dest),
        Tool::Unzip => Cmd::new(EngineId::Unzip).args(["-q", "-o"]).arg(archive).arg("-d").arg(dest),
        Tool::Zip => unreachable!(),
    }
}

fn pack_cmd(tool: Tool, fmt: &str, out: &Path, base: &Path, names: &[PathBuf], contents: bool) -> Cmd {
    match tool {
        Tool::BsdTar => {
            let mut c = Cmd::new(EngineId::Tar);
            c = match fmt {
                "zip" => c.args(["--format", "zip", "--options", "zip:compression=deflate,zip:hdrcharset=UTF-8", "-cf"]),
                "7z" => c.args(["--format", "7zip", "-cf"]),
                "targz" => c.args(["-czf"]),
                "tarbz2" => c.args(["-cjf"]),
                "tarxz" => c.args(["-cJf"]),
                _ => c.args(["-cf"]),
            };
            c.arg(out).arg("-C").arg(base).args(names.iter().map(|n| n.as_os_str().to_owned()))
        }
        Tool::GnuTar => {
            let flag = match fmt {
                "targz" => "-czf",
                "tarbz2" => "-cjf",
                "tarxz" => "-cJf",
                _ => "-cf",
            };
            Cmd::new(EngineId::Tar).arg(flag).arg(out).arg("-C").arg(base).args(names.iter().map(|n| n.as_os_str().to_owned()))
        }
        Tool::SevenZip => {
            let t = match fmt {
                "zip" => "-tzip",
                "7z" => "-t7z",
                _ => "-ttar",
            };
            let mut c = Cmd::new(EngineId::SevenZip).args(["a", t, "-y", "-bso0", "-bsp0"]);
            if fmt == "zip" {
                c = c.arg("-mcu=on");
            }
            let c = c.arg(out).cwd(base);
            if contents {
                c.arg("*")
            } else {
                c.args(names.iter().map(|n| n.as_os_str().to_owned()))
            }
        }
        Tool::Zip => Cmd::new(EngineId::Zip).args(["-r", "-q", "-X"]).arg(out).args(names.iter().map(|n| n.as_os_str().to_owned())).cwd(base),
        Tool::Unzip => unreachable!(),
    }
}
