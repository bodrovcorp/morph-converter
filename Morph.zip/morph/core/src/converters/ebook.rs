//! Электронные книги: Calibre (если установлен) или Pandoc (+ LibreOffice для PDF).

use super::document::pandoc_cmd;
use super::{lo, mkdir, pandoc, src_dir};
use crate::engines::{Cmd, EngineId, Engines};
use crate::error::{ConvError, ErrKind};
use crate::formats::{by_id, Format, Kind};
use crate::registry::{Converter, Ctx, Offer, Output, Plan, Step};

pub struct EbookConverter;
const NAME: &str = "ebook";

fn calibre_only(src: &str, dst: &str) -> bool {
    matches!(src, "mobi" | "azw3") || matches!(dst, "mobi" | "azw3")
}

impl Converter for EbookConverter {
    fn name(&self) -> &'static str {
        NAME
    }
    fn offers(&self, src: &'static Format, e: &Engines) -> Vec<Offer> {
        // Источник — книга; плюс DOCX/MD → FB2 через Pandoc
        if src.kind != Kind::Ebook {
            return Vec::new();
        }
        let order = [("epub", 1, true), ("pdf", 2, true), ("fb2", 3, true), ("docx", 4, true), ("txt", 10, false), ("html", 11, false), ("mobi", 12, false), ("azw3", 13, false)];
        let mut v = Vec::new();
        for (id, rank, pop) in order {
            if id == src.id {
                continue;
            }
            let mut o = Offer::to(NAME, by_id(id).unwrap()).rank(rank);
            if pop {
                o = o.pop(rank);
            }
            let calibre = e.has(EngineId::Calibre);
            o.missing = if calibre {
                vec![]
            } else if calibre_only(src.id, id) {
                vec![EngineId::Calibre]
            } else if id == "pdf" {
                [EngineId::Pandoc, EngineId::Soffice].into_iter().filter(|x| !e.has(*x)).collect()
            } else {
                [EngineId::Pandoc].into_iter().filter(|x| !e.has(*x)).collect()
            };
            v.push(o);
        }
        v
    }
    fn plan(&self, ctx: &Ctx) -> Result<Plan, ConvError> {
        let src = ctx.input().format.id;
        let dst = ctx.offer.id.as_str();
        let inp = &ctx.input().path;
        let out_dir = ctx.out("out");
        mkdir(&out_dir)?;
        let out = out_dir.join(format!("out.{}", ctx.offer.ext));
        if ctx.engines.has(EngineId::Calibre) {
            let c = Cmd::new(EngineId::Calibre).arg(inp).arg(&out);
            return Ok(Plan::new(vec![Step::run(c)], Output::File(out)));
        }
        if calibre_only(src, dst) {
            return Err(ConvError::new(ErrKind::EngineMissing(EngineId::Calibre), "MOBI/AZW3 требуют Calibre"));
        }
        let reader = if src == "fb2" { "fb2" } else { "epub" };
        if dst == "pdf" {
            let mid = ctx.out("mid.docx");
            return Ok(Plan::new(
                vec![
                    Step::run_w(pandoc(inp, reader, "docx", &mid, Some(&src_dir(ctx))).arg("--standalone"), 0.4),
                    Step::run(lo(&mid, "pdf", None, &out_dir)),
                ],
                Output::Many { dir: out_dir, ext: "pdf" },
            ));
        }
        Ok(Plan::new(vec![Step::run(pandoc_cmd(ctx, inp, reader, dst, &out)?)], Output::File(out)))
    }
}
