//! Конвертеры. Каждый файл — отдельный модуль со своим набором пар «из → в».
pub mod archive;
pub mod audio;
pub mod document;
pub mod ebook;
pub mod image;
pub mod pdf;
pub mod sheet;
pub mod slides;
pub mod video;

use crate::engines::{Cmd, EngineId};
use crate::error::{ConvError, ErrKind};
use crate::registry::Ctx;
use std::fs;
use std::path::{Path, PathBuf};
use std::sync::OnceLock;

/// Копирует (или жёстко связывает) входной файл в рабочую папку под ASCII-именем `in.<ext>`.
/// Так движки не спотыкаются о кириллицу, пробелы и квадратные скобки в путях.
pub fn stage(input: &Path, work: &Path, ext: &str) -> Result<PathBuf, ConvError> {
    let dir = work.join("src");
    fs::create_dir_all(&dir).map_err(|e| ConvError::from_io_write(&e, "Рабочая папка"))?;
    let dst = dir.join(format!("in.{ext}"));
    if fs::hard_link(input, &dst).is_err() {
        fs::copy(input, &dst).map_err(|e| ConvError::from_io_read(&e, "Чтение исходного файла"))?;
    }
    Ok(dst)
}

pub fn mkdir(p: &Path) -> Result<(), ConvError> {
    fs::create_dir_all(p).map_err(|e| ConvError::from_io_write(&e, "Рабочая папка"))
}

/// file:// URL для -env:UserInstallation LibreOffice
pub fn file_url(p: &Path) -> String {
    let s = p.to_string_lossy().replace('\\', "/");
    let mut out = String::from("file://");
    if !s.starts_with('/') {
        out.push('/');
    }
    for b in s.bytes() {
        match b {
            b'A'..=b'Z' | b'a'..=b'z' | b'0'..=b'9' | b'/' | b'-' | b'_' | b'.' | b'~' | b':' => out.push(b as char),
            _ => out.push_str(&format!("%{b:02X}")),
        }
    }
    out
}

/// Отдельный профиль LibreOffice: не мешаем открытому у пользователя LibreOffice и наоборот.
pub fn lo_profile() -> &'static Path {
    static P: OnceLock<PathBuf> = OnceLock::new();
    P.get_or_init(|| std::env::temp_dir().join(format!("morph-lo-profile-{}", std::process::id())))
}

/// Команда LibreOffice: `soffice --headless --convert-to <filter> --outdir <out> <input>`
pub fn lo(input: &Path, filter: &str, infilter: Option<&str>, outdir: &Path) -> Cmd {
    let mut c = Cmd::new(EngineId::Soffice)
        .arg(format!("-env:UserInstallation={}", file_url(lo_profile())))
        .args(["--headless", "--invisible", "--norestore", "--nolockcheck", "--nodefault", "--nologo"]);
    if let Some(f) = infilter {
        c = c.arg(format!("--infilter={f}"));
    }
    c.arg("--convert-to").arg(filter).arg("--outdir").arg(outdir).arg(input)
}

/// Pandoc: `pandoc in -f reader -t writer -o out`
pub fn pandoc(input: &Path, reader: &str, writer: &str, out: &Path, resource_dir: Option<&Path>) -> Cmd {
    let mut c = Cmd::new(EngineId::Pandoc).arg(input).arg("-f").arg(reader).arg("-t").arg(writer).arg("-o").arg(out);
    if let Some(d) = resource_dir {
        c = c.arg(format!("--resource-path={}", d.display()));
    }
    c
}

/// Проверка, что движок создал файл (LibreOffice иногда «успешно» ничего не делает).
pub fn expect_file(p: PathBuf, why: &'static str) -> impl FnOnce() -> Result<(), ConvError> + Send {
    move || match fs::metadata(&p) {
        Ok(m) if m.len() > 0 => Ok(()),
        Ok(_) => Err(ConvError::new(ErrKind::Empty, format!("{why}: пустой результат"))),
        Err(_) => Err(ConvError::new(ErrKind::InputCorrupt, format!("{why}: результат не создан — файл, вероятно, повреждён"))),
    }
}

/// Читатели Pandoc по нашему id формата
pub fn pandoc_reader(id: &str) -> Option<&'static str> {
    Some(match id {
        "md" | "txt" => "markdown",
        "html" => "html",
        "docx" => "docx",
        "odt" => "odt",
        "rtf" => "rtf",
        "epub" => "epub",
        "fb2" => "fb2",
        _ => return None,
    })
}

pub fn pandoc_writer(id: &str) -> Option<&'static str> {
    Some(match id {
        "md" => "gfm",
        "html" => "html5",
        "docx" => "docx",
        "odt" => "odt",
        "rtf" => "rtf",
        "txt" => "plain",
        "epub" => "epub3",
        "fb2" => "fb2",
        _ => return None,
    })
}

/// CSS для HTML, собранного Pandoc: аккуратная типографика без внешних ресурсов.
pub const HTML_CSS: &str = "body{font-family:-apple-system,'Segoe UI',Inter,Roboto,sans-serif;max-width:46rem;margin:3rem auto;padding:0 1.25rem;line-height:1.6;color:#1b1b1f}\
h1,h2,h3{line-height:1.25}code,pre{font-family:ui-monospace,'SF Mono',Consolas,monospace;background:#f4f4f6;border-radius:6px}\
pre{padding:.8rem 1rem;overflow:auto}code{padding:.1rem .3rem}table{border-collapse:collapse}td,th{border:1px solid #ddd;padding:.35rem .6rem}\
img{max-width:100%}blockquote{margin:0;padding-left:1rem;border-left:3px solid #ddd;color:#555}";

/// Общий помощник: путь к исходнику и его папке
pub fn src_dir(ctx: &Ctx) -> PathBuf {
    ctx.input().path.parent().map(|p| p.to_path_buf()).unwrap_or_default()
}
