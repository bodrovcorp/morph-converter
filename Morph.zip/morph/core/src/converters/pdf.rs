//! PDF: страницы в картинки и текст (Poppler), объединение/сжатие/разделение (qpdf), PDF → Word (LibreOffice).

use super::{lo, mkdir};
use crate::engines::{Cmd, EngineId, Engines, ProgressKind};
use crate::error::ConvError;
use crate::formats::{Format, Kind};
use crate::options::OptKind;
use crate::registry::{Converter, Ctx, Offer, Output, Plan, Step};

pub struct PdfConverter;
const NAME: &str = "pdf";

impl Converter for PdfConverter {
    fn name(&self) -> &'static str {
        NAME
    }

    fn offers(&self, src: &'static Format, e: &Engines) -> Vec<Offer> {
        if src.id != "pdf" {
            return Vec::new();
        }
        let k = Kind::Document;
        vec![
            Offer::new(NAME, "png_pages", "png", "PNG", "Каждая страница — картинка", Kind::Image).pop(1).opts(&[OptKind::Dpi]).needs(e, &[&[EngineId::Pdftoppm]]),
            Offer::new(NAME, "jpg_pages", "jpg", "JPG", "Каждая страница — фото", Kind::Image).pop(2).opts(&[OptKind::Dpi, OptKind::Quality]).needs(e, &[&[EngineId::Pdftoppm]]),
            Offer::new(NAME, "docx", "docx", "DOCX", "Word, черновое качество вёрстки", k).pop(3).needs(e, &[&[EngineId::Soffice]]),
            Offer::new(NAME, "txt", "txt", "TXT", "Только текст", k).pop(4).needs(e, &[&[EngineId::Pdftotext]]),
            Offer::new(NAME, "pdf_compress", "pdf", "Сжать PDF", "Без потерь качества", k).rank(10).needs(e, &[&[EngineId::Qpdf]]),
            Offer::new(NAME, "pdf_split", "pdf", "Разделить", "Каждая страница — отдельный PDF", k).rank(11).needs(e, &[&[EngineId::Qpdf]]),
            Offer::new(NAME, "odt", "odt", "ODT", "LibreOffice, черновое качество", k).rank(12).needs(e, &[&[EngineId::Soffice]]),
        ]
    }

    fn combine_offers(&self, srcs: &[&'static Format], e: &Engines) -> Vec<Offer> {
        if srcs.iter().all(|f| f.id == "pdf") {
            let mut o = Offer::new(NAME, "merge_pdf", "pdf", "Объединить", "Все PDF — в один файл по порядку", Kind::Document).pop(0).needs(e, &[&[EngineId::Qpdf]]);
            o.combine = true;
            return vec![o];
        }
        Vec::new()
    }

    fn plan(&self, ctx: &Ctx) -> Result<Plan, ConvError> {
        let inp = &ctx.input().path;
        let out_dir = ctx.out("out");
        mkdir(&out_dir)?;
        let o = ctx.opts;
        match ctx.offer.id.as_str() {
            "png_pages" | "jpg_pages" => {
                let jpg = ctx.offer.id == "jpg_pages";
                let mut c = Cmd::new(EngineId::Pdftoppm).arg("-r").arg(o.pdf_dpi.to_string()).arg("-progress");
                c = if jpg { c.arg("-jpeg").arg("-jpegopt").arg(format!("quality={}", o.image_quality)) } else { c.arg("-png") };
                let c = c.arg(inp).arg(out_dir.join("in")).progress(ProgressKind::PdfPages);
                Ok(Plan::new(vec![Step::run(c)], Output::Many { dir: out_dir, ext: if jpg { "jpg" } else { "png" } }))
            }
            "txt" => {
                let out = out_dir.join("out.txt");
                let c = Cmd::new(EngineId::Pdftotext).args(["-enc", "UTF-8", "-layout"]).arg(inp).arg(&out);
                Ok(Plan::new(vec![Step::run(c)], Output::File(out)))
            }
            "docx" | "odt" => {
                let filter = if ctx.offer.id == "docx" { "docx:MS Word 2007 XML" } else { "odt" };
                Ok(Plan::new(vec![Step::run(lo(inp, filter, Some("writer_pdf_import"), &out_dir))], Output::Many { dir: out_dir, ext: ctx.offer.ext }))
            }
            "pdf_compress" => {
                let out = out_dir.join("out.pdf");
                let c = Cmd::new(EngineId::Qpdf)
                    .args(["--compress-streams=y", "--recompress-flate", "--compression-level=9", "--object-streams=generate", "--warning-exit-0"])
                    .arg(inp)
                    .arg(&out);
                let mut p = Plan::new(vec![Step::run(c)], Output::File(out));
                p.stem = Some(format!("{} (сжатый)", ctx.input().stem()));
                Ok(p)
            }
            "pdf_split" => {
                let c = Cmd::new(EngineId::Qpdf).args(["--split-pages", "--warning-exit-0"]).arg(inp).arg(out_dir.join("in.pdf"));
                Ok(Plan::new(vec![Step::run(c)], Output::Many { dir: out_dir, ext: "pdf" }))
            }
            "merge_pdf" => {
                let out = out_dir.join("out.pdf");
                let mut c = Cmd::new(EngineId::Qpdf).args(["--warning-exit-0", "--empty", "--pages"]);
                for i in ctx.inputs {
                    c = c.arg(&i.path);
                }
                c = c.arg("--").arg(&out);
                let mut p = Plan::new(vec![Step::run(c)], Output::File(out));
                p.stem = Some(format!("{} + ещё {}", ctx.input().stem(), ctx.inputs.len() - 1));
                Ok(p)
            }
            other => Err(ConvError::new(crate::error::ErrKind::Unsupported, other.to_string())),
        }
    }
}
