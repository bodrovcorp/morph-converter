//! Текстовые документы: LibreOffice (DOCX/DOC/ODT/RTF/TXT/HTML) и Pandoc (Markdown, HTML, EPUB).

use super::{expect_file, lo, mkdir, pandoc, pandoc_reader, pandoc_writer, src_dir, stage, HTML_CSS};
use crate::engines::{EngineId, Engines};
use crate::error::{ConvError, ErrKind};
use crate::formats::{by_id, Format};
use crate::registry::{Converter, Ctx, Offer, Output, Plan, Step};
use crate::text::encoding;
use std::fs;
use std::path::{Path, PathBuf};

pub struct DocumentConverter;
const NAME: &str = "document";

const SOURCES: &[&str] = &["docx", "doc", "odt", "rtf", "txt", "md", "html"];

#[derive(Debug, Clone, Copy, PartialEq)]
enum Route {
    Lo,
    Pandoc,
    /// Pandoc → DOCX → LibreOffice
    PandocThenLo,
    /// LibreOffice → DOCX → Pandoc
    LoThenPandoc,
}

fn route(src: &str, dst: &str) -> Option<Route> {
    use Route::*;
    let pandoc_src = matches!(src, "md" | "html" | "docx" | "odt" | "rtf");
    Some(match dst {
        "pdf" | "doc" => {
            if src == "md" {
                PandocThenLo
            } else {
                Lo
            }
        }
        "docx" | "odt" | "rtf" => {
            // У LibreOffice нет экспорта HTML-документа в RTF — используем Pandoc
            if src == "md" || (src == "html" && dst == "rtf") {
                Pandoc
            } else {
                Lo
            }
        }
        "txt" => {
            if src == "md" {
                Pandoc
            } else {
                Lo
            }
        }
        "html" => {
            if pandoc_src {
                Pandoc
            } else {
                Lo
            }
        }
        "md" | "epub" => {
            if pandoc_src || src == "txt" {
                Pandoc
            } else {
                LoThenPandoc
            }
        }
        _ => return None,
    })
}

fn engines_for(r: Route) -> Vec<EngineId> {
    match r {
        Route::Lo => vec![EngineId::Soffice],
        Route::Pandoc => vec![EngineId::Pandoc],
        Route::PandocThenLo | Route::LoThenPandoc => vec![EngineId::Pandoc, EngineId::Soffice],
    }
}

pub fn lo_filter(dst: &str) -> &'static str {
    match dst {
        "pdf" => "pdf",
        "docx" => "docx:MS Word 2007 XML",
        "doc" => "doc:MS Word 97",
        "odt" => "odt",
        "rtf" => "rtf",
        "txt" => "txt:Text (encoded):UTF8",
        "html" => "html:XHTML Writer File:UTF8",
        _ => "pdf",
    }
}

/// Перекодирует текстовый файл в UTF-8 (Windows-1251, KOI8-R, UTF-16 → UTF-8).
pub fn transcode_step(src: PathBuf, dst: PathBuf) -> Step {
    Step::func("перекодирование текста в UTF-8", move || {
        let bytes = fs::read(&src).map_err(|e| ConvError::from_io_read(&e, "Чтение текста"))?;
        let (text, _enc) = encoding::decode(&bytes);
        fs::write(&dst, text.replace("\r\n", "\n")).map_err(|e| ConvError::from_io_write(&e, "Запись текста"))
    })
}

impl Converter for DocumentConverter {
    fn name(&self) -> &'static str {
        NAME
    }

    fn offers(&self, src: &'static Format, e: &Engines) -> Vec<Offer> {
        if !SOURCES.contains(&src.id) {
            return Vec::new();
        }
        let order: &[(&str, u16, bool)] = if src.id == "md" {
            &[("html", 1, true), ("docx", 2, true), ("pdf", 3, true), ("odt", 10, false), ("rtf", 11, false), ("epub", 12, false), ("txt", 13, false), ("doc", 14, false)]
        } else if src.id == "html" {
            &[("pdf", 1, true), ("docx", 2, true), ("md", 3, true), ("txt", 4, false), ("odt", 10, false), ("rtf", 11, false), ("epub", 12, false), ("doc", 13, false)]
        } else {
            &[("pdf", 1, true), ("docx", 2, true), ("odt", 3, false), ("txt", 4, true), ("rtf", 10, false), ("doc", 11, false), ("html", 12, false), ("md", 13, false), ("epub", 14, false)]
        };
        let mut v = Vec::new();
        for &(id, rank, pop) in order {
            if id == src.id {
                continue;
            }
            let Some(r) = route(src.id, id) else { continue };
            let mut o = Offer::to(NAME, by_id(id).unwrap()).rank(rank);
            if pop {
                o = o.pop(rank);
            }
            if id == "epub" {
                o.desc = "Электронная книга".into();
            }
            let need = engines_for(r);
            o.missing = need.into_iter().filter(|x| !e.has(*x)).collect();
            v.push(o);
        }
        v
    }

    fn plan(&self, ctx: &Ctx) -> Result<Plan, ConvError> {
        let src = ctx.input().format.id;
        let dst = ctx.offer.id.as_str();
        let r = route(src, dst).ok_or_else(|| ConvError::new(ErrKind::Unsupported, format!("{src} → {dst}")))?;
        let out_dir = ctx.out("out");
        mkdir(&out_dir)?;
        let mut steps = Vec::new();

        // Текст: сначала приводим к UTF-8
        let input: PathBuf = if src == "txt" {
            let dir = ctx.out("src");
            mkdir(&dir)?;
            let t = dir.join(if r == Route::Pandoc { "in.md" } else { "in.txt" });
            steps.push(transcode_step(ctx.input().path.clone(), t.clone()));
            t
        } else {
            ctx.input().path.clone()
        };
        let infilter = if src == "txt" { Some("Text (encoded):UTF8") } else { None };
        let reader = pandoc_reader(src).unwrap_or("markdown");

        match r {
            Route::Lo => {
                steps.push(Step::run(lo(&input, lo_filter(dst), infilter, &out_dir)));
                Ok(Plan::new(steps, Output::Many { dir: out_dir, ext: ctx.offer.ext }))
            }
            Route::Pandoc => {
                let out = out_dir.join(format!("out.{}", ctx.offer.ext));
                let cmd = pandoc_cmd(ctx, &input, reader, dst, &out)?;
                steps.push(Step::run(cmd));
                steps.push(Step::func("проверка результата", expect_file(out.clone(), "Pandoc")));
                Ok(Plan::new(steps, Output::File(out)))
            }
            Route::PandocThenLo => {
                let mid = ctx.out("mid.docx");
                steps.push(Step::run_w(pandoc(&input, reader, "docx", &mid, Some(&src_dir(ctx))).arg("--standalone"), 0.3));
                steps.push(Step::run(lo(&mid, lo_filter(dst), None, &out_dir)));
                Ok(Plan::new(steps, Output::Many { dir: out_dir, ext: ctx.offer.ext }))
            }
            Route::LoThenPandoc => {
                let staged = stage(&input, ctx.work, ctx.input().format.ext())?;
                let mid_dir = ctx.out("mid");
                mkdir(&mid_dir)?;
                steps.push(Step::run_w(lo(&staged, lo_filter("docx"), infilter, &mid_dir), 0.6));
                let mid = mid_dir.join("in.docx");
                let out = out_dir.join(format!("out.{}", ctx.offer.ext));
                steps.push(Step::run(pandoc_cmd(ctx, &mid, "docx", dst, &out)?));
                Ok(Plan::new(steps, Output::File(out)))
            }
        }
    }
}

/// Команда Pandoc с оформлением под целевой формат
pub fn pandoc_cmd(ctx: &Ctx, input: &Path, reader: &str, dst: &str, out: &Path) -> Result<crate::engines::Cmd, ConvError> {
    let writer = pandoc_writer(dst).ok_or_else(|| ConvError::new(ErrKind::Unsupported, dst.to_string()))?;
    let title = ctx.input().stem();
    let mut c = pandoc(input, reader, writer, out, Some(&src_dir(ctx))).arg("--standalone");
    match dst {
        "html" => {
            let css = ctx.out("style.css");
            fs::write(&css, HTML_CSS).map_err(|e| ConvError::from_io_write(&e, "CSS"))?;
            c = c.arg("--embed-resources").arg("-c").arg(css).arg("--metadata").arg(format!("pagetitle={title}"));
        }
        "epub" | "fb2" => {
            c = c.arg("--metadata").arg(format!("title={title}"));
        }
        "md" => {
            c = c.arg("--wrap=none");
        }
        _ => {}
    }
    Ok(c)
}
