//! Презентации: PPTX/PPT/ODP → PDF, картинки слайдов, другие форматы презентаций.

use super::{lo, mkdir};
use crate::engines::{Cmd, EngineId, Engines, ProgressKind};
use crate::error::ConvError;
use crate::formats::{by_id, Format, Kind};
use crate::options::OptKind;
use crate::registry::{Converter, Ctx, Offer, Output, Plan, Step};

pub struct SlidesConverter;
const NAME: &str = "slides";

fn filter(dst: &str) -> &'static str {
    match dst {
        "pdf" => "pdf:impress_pdf_Export",
        "pptx" => "pptx:Impress MS PowerPoint 2007 XML",
        "ppt" => "ppt:MS PowerPoint 97",
        "odp" => "odp",
        _ => "pdf",
    }
}

impl Converter for SlidesConverter {
    fn name(&self) -> &'static str {
        NAME
    }
    fn offers(&self, src: &'static Format, e: &Engines) -> Vec<Offer> {
        if src.kind != Kind::Presentation {
            return Vec::new();
        }
        let lo_need: &[&[EngineId]] = &[&[EngineId::Soffice]];
        let img_need: &[&[EngineId]] = &[&[EngineId::Soffice], &[EngineId::Pdftoppm]];
        let mut v = vec![
            Offer::to(NAME, by_id("pdf").unwrap()).pop(1).needs(e, lo_need),
            Offer::new(NAME, "png_slides", "png", "PNG", "Каждый слайд — картинка", Kind::Image).pop(2).opts(&[OptKind::Dpi]).needs(e, img_need),
            Offer::new(NAME, "jpg_slides", "jpg", "JPG", "Каждый слайд — фото", Kind::Image).pop(3).opts(&[OptKind::Dpi, OptKind::Quality]).needs(e, img_need),
        ];
        v[0].desc = "Для показа и печати".into();
        for (id, r) in [("pptx", 4), ("odp", 10), ("ppt", 11)] {
            if id != src.id {
                let mut o = Offer::to(NAME, by_id(id).unwrap()).rank(r).needs(e, lo_need);
                if id == "pptx" {
                    o = o.pop(r);
                }
                v.push(o);
            }
        }
        v
    }
    fn plan(&self, ctx: &Ctx) -> Result<Plan, ConvError> {
        let inp = &ctx.input().path;
        let out_dir = ctx.out("out");
        mkdir(&out_dir)?;
        match ctx.offer.id.as_str() {
            "png_slides" | "jpg_slides" => {
                let mid = ctx.out("mid");
                mkdir(&mid)?;
                let staged = super::stage(inp, ctx.work, ctx.input().format.ext())?;
                let pdf = mid.join("in.pdf");
                let jpg = ctx.offer.id == "jpg_slides";
                let mut c = Cmd::new(EngineId::Pdftoppm).arg("-r").arg(ctx.opts.pdf_dpi.to_string()).arg("-progress");
                c = if jpg { c.arg("-jpeg").arg("-jpegopt").arg(format!("quality={}", ctx.opts.image_quality)) } else { c.arg("-png") };
                c = c.arg(&pdf).arg(out_dir.join("in")).progress(ProgressKind::PdfPages);
                Ok(Plan::new(
                    vec![Step::run_w(lo(&staged, filter("pdf"), None, &mid), 0.6), Step::run_w(c, 0.4)],
                    Output::Many { dir: out_dir, ext: if jpg { "jpg" } else { "png" } },
                ))
            }
            id => Ok(Plan::new(vec![Step::run(lo(inp, filter(id), None, &out_dir))], Output::Many { dir: out_dir, ext: ctx.offer.ext })),
        }
    }
}
