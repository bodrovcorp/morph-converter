//! Изображения: ImageMagick (основной), sips (macOS, без установки), FFmpeg (запись WEBP/AVIF).

use super::{mkdir, stage};
use crate::engines::{Cmd, EngineId, Engines};
use crate::error::{ConvError, ErrKind};
use crate::formats::{by_id, Format, Kind};
use crate::options::{OptKind, Resize};
use crate::registry::{Converter, Ctx, Offer, Output, Plan, Step};

pub struct ImageConverter;

const NAME: &str = "image";
const TARGETS: &[(&str, u16, bool)] = &[
    // (id, ранг, популярный)
    ("jpg", 1, true),
    ("png", 2, true),
    ("webp", 3, true),
    ("avif", 4, true),
    ("pdf", 5, true),
    ("heic", 10, false),
    ("tiff", 11, false),
    ("gif", 12, false),
    ("bmp", 13, false),
    ("ico", 14, false),
];
const RAW: &[&str] = &["cr2", "cr3", "nef", "arw", "dng", "orf", "rw2", "raf"];

fn magick_name(id: &str) -> &str {
    match id {
        "jpg" => "jpeg",
        "tiff" => "tiff",
        other => other,
    }
}

/// Форматы, которые FFmpeg читает как картинку
fn ff_reads(id: &str) -> bool {
    matches!(id, "jpg" | "png" | "bmp" | "tiff" | "webp" | "gif")
}

fn sips_reads(id: &str) -> bool {
    matches!(id, "jpg" | "png" | "tiff" | "heic" | "gif" | "bmp" | "psd" | "webp" | "avif" | "tga") || RAW.contains(&id)
}
fn sips_writes(id: &str) -> bool {
    matches!(id, "jpg" | "png" | "tiff" | "heic" | "gif" | "bmp")
}

#[derive(Debug, Clone, Copy, PartialEq)]
enum Route {
    Magick,
    Sips,
    Ffmpeg,
    /// сначала в PNG (magick/sips), потом FFmpeg
    ToPngThenFfmpeg(bool), // true — промежуточный шаг через magick, false — через sips
}

/// SVG без поддержки в ImageMagick растеризуем через librsvg, дальше — как PNG.
fn svg_via_rsvg(src: &str, e: &Engines) -> bool {
    src == "svg" && !e.magick_reads("svg") && e.has(EngineId::Rsvg)
}

fn route(src: &str, dst: &str, e: &Engines) -> Option<Route> {
    let src = if svg_via_rsvg(src, e) { "png" } else { src };
    if e.magick_reads(magick_name(src)) && e.magick_writes(magick_name(dst)) {
        return Some(Route::Magick);
    }
    if e.has(EngineId::Sips) && sips_reads(src) && sips_writes(dst) {
        return Some(Route::Sips);
    }
    if dst == "webp" || dst == "avif" {
        let enc_ok = if dst == "webp" { e.ff_encoder("libwebp") } else { (e.ff_encoder("libaom-av1") || e.ff_encoder("libsvtav1")) && e.ff_muxer("avif") };
        if enc_ok {
            if ff_reads(src) {
                return Some(Route::Ffmpeg);
            }
            if e.magick_reads(magick_name(src)) && e.magick_writes("png") {
                return Some(Route::ToPngThenFfmpeg(true));
            }
            if e.has(EngineId::Sips) && sips_reads(src) {
                return Some(Route::ToPngThenFfmpeg(false));
            }
        }
    }
    None
}

impl Converter for ImageConverter {
    fn name(&self) -> &'static str {
        NAME
    }

    fn offers(&self, src: &'static Format, e: &Engines) -> Vec<Offer> {
        if src.kind != Kind::Image {
            return Vec::new();
        }
        let mut v = Vec::new();
        for &(id, rank, popular) in TARGETS {
            if id == src.id || (id == "heic" && src.id == "heic") {
                continue;
            }
            let f = by_id(id).unwrap();
            let mut o = Offer::to(NAME, f).rank(rank);
            if popular {
                o = o.pop(rank);
            }
            // для RAW популярны JPG/TIFF/PNG
            if RAW.contains(&src.id) && id == "tiff" {
                o = o.pop(3);
            }
            if id == "pdf" {
                o.desc = "Документ из изображения".into();
            }
            o.options = match id {
                "png" | "bmp" | "tiff" | "gif" => vec![OptKind::Resize, OptKind::StripMetadata],
                "ico" | "pdf" => vec![],
                _ => vec![OptKind::Quality, OptKind::Resize, OptKind::StripMetadata],
            };
            if id == "pdf" {
                if svg_via_rsvg(src.id, e) {
                    // librsvg пишет PDF сам, в векторе
                } else if !e.magick_reads(magick_name(src.id)) || !e.magick_writes("pdf") {
                    o.missing = vec![EngineId::Magick];
                }
            } else if route(src.id, id, e).is_none() {
                o.missing = vec![EngineId::Magick];
            }
            v.push(o);
        }
        v
    }

    fn combine_offers(&self, srcs: &[&'static Format], e: &Engines) -> Vec<Offer> {
        if srcs.iter().all(|f| f.kind == Kind::Image) {
            let mut o = Offer::new(NAME, "pdf_images", "pdf", "Один PDF", "Все изображения — страницами одного PDF", Kind::Document).pop(0);
            o.combine = true;
            if !e.magick_writes("pdf") {
                o.missing = vec![EngineId::Magick];
            }
            return vec![o];
        }
        Vec::new()
    }

    fn plan(&self, ctx: &Ctx) -> Result<Plan, ConvError> {
        let o = ctx.opts;
        let out_dir = ctx.out("out");
        mkdir(&out_dir)?;

        if ctx.offer.id == "pdf_images" {
            let out = out_dir.join("out.pdf");
            let mut cmd = Cmd::new(EngineId::Magick);
            for (i, inp) in ctx.inputs.iter().enumerate() {
                let staged = stage(&inp.path, &ctx.work.join(format!("s{i}")), inp.format.ext())?;
                cmd = cmd.arg(format!("{}[0]", staged.display()));
            }
            cmd = cmd.args(["-auto-orient", "-background", "white", "-alpha", "remove", "-alpha", "off", "-quality", "92"]).arg(&out);
            let mut p = Plan::new(vec![Step::run(cmd)], Output::File(out));
            p.stem = Some(format!("{} + ещё {}", ctx.input().stem(), ctx.inputs.len() - 1));
            return Ok(p);
        }

        let mut src = ctx.input().format.id;
        let dst = ctx.offer.id.as_str();
        let mut staged = stage(&ctx.input().path, ctx.work, ctx.input().format.ext())?;
        let out = out_dir.join(format!("out.{}", ctx.offer.ext));
        let mut pre = Vec::new();
        if svg_via_rsvg(src, ctx.engines) {
            if dst == "pdf" {
                let c = Cmd::new(EngineId::Rsvg).args(["-f", "pdf", "-o"]).arg(&out).arg(&staged);
                return Ok(Plan::new(vec![Step::run(c)], Output::File(out)));
            }
            let mid = ctx.out("svg.png");
            let mut c = Cmd::new(EngineId::Rsvg).args(["-f", "png", "-z", "2", "-o"]).arg(&mid);
            if let Resize::MaxSide(n) = o.resize {
                c = c.arg("-w").arg(n.to_string()).arg("-h").arg(n.to_string()).arg("--keep-aspect-ratio");
            }
            pre.push(Step::run_w(c.arg(&staged), 0.3));
            if dst == "png" {
                // готово сразу
                let c2 = Cmd::new(EngineId::Rsvg).args(["-f", "png", "-z", "2", "-o"]).arg(&out).arg(&staged);
                return Ok(Plan::new(vec![Step::run(c2)], Output::File(out)));
            }
            staged = mid;
            src = "png";
        }
        let r = if dst == "pdf" { Some(Route::Magick) } else { route(src, dst, ctx.engines) };
        let mut steps = pre;
        steps.extend(match r {
            Some(Route::Magick) => vec![Step::run(magick(ctx, src, dst, &staged, &out))],
            Some(Route::Sips) => vec![Step::run(sips(o.image_quality, o.resize, dst, &staged, &out))],
            Some(Route::Ffmpeg) => vec![Step::run(ffmpeg_still(ctx, dst, &staged, &out))],
            Some(Route::ToPngThenFfmpeg(via_magick)) => {
                let mid = ctx.out("mid.png");
                let first = if via_magick { magick(ctx, src, "png", &staged, &mid) } else { sips(100, Resize::None, "png", &staged, &mid) };
                vec![Step::run_w(first, 0.4), Step::run(ffmpeg_still(ctx, dst, &mid, &out))]
            }
            None => return Err(ConvError::new(ErrKind::EngineMissing(EngineId::Magick), format!("нет движка для {src} → {dst}"))),
        });
        Ok(Plan::new(steps, Output::File(out)))
    }
}

fn resize_arg(r: Resize) -> Option<String> {
    match r {
        Resize::None => None,
        Resize::MaxSide(n) => Some(format!("{n}x{n}>")),
        Resize::Percent(p) => Some(format!("{p}%")),
    }
}

fn magick(ctx: &Ctx, src: &str, dst: &str, input: &std::path::Path, out: &std::path::Path) -> Cmd {
    let o = ctx.opts;
    let mut c = Cmd::new(EngineId::Magick);
    if src == "svg" {
        c = c.args(["-density", "300", "-background", "none"]);
    }
    // Анимацию сохраняем только для GIF → WEBP/GIF; в остальных случаях берём первый кадр/страницу/слой
    let keep_frames = src == "gif" && matches!(dst, "webp" | "gif");
    let in_arg = if keep_frames { input.display().to_string() } else { format!("{}[0]", input.display()) };
    c = c.arg(in_arg);
    if keep_frames {
        c = c.arg("-coalesce");
    }
    c = c.arg("-auto-orient");
    if o.strip_metadata {
        c = c.arg("-strip");
    }
    if let Some(r) = resize_arg(o.resize) {
        c = c.arg("-resize").arg(r);
    }
    match dst {
        "jpg" | "bmp" | "pdf" => {
            c = c.args(["-background", "white", "-alpha", "remove", "-alpha", "off"]);
        }
        "ico" => {
            c = c.args(["-background", "none", "-resize", "256x256", "-gravity", "center", "-extent", "256x256", "-define", "icon:auto-resize=256,128,64,48,32,16"]);
        }
        _ => {}
    }
    if matches!(dst, "jpg" | "webp" | "avif" | "heic") {
        c = c.arg("-quality").arg(o.image_quality.to_string());
    }
    if dst == "pdf" {
        c = c.args(["-quality", "92"]);
    }
    c.arg(out)
}

fn sips(q: u8, resize: Resize, dst: &str, input: &std::path::Path, out: &std::path::Path) -> Cmd {
    let fmt = match dst {
        "jpg" => "jpeg",
        "tiff" => "tiff",
        other => other,
    };
    let mut c = Cmd::new(EngineId::Sips).args(["-s", "format", fmt]);
    if matches!(dst, "jpg" | "heic") {
        c = c.args(["-s", "formatOptions"]).arg(q.to_string());
    }
    if let Resize::MaxSide(n) = resize {
        c = c.arg("-Z").arg(n.to_string());
    }
    c.arg(input).arg("--out").arg(out)
}

fn ffmpeg_still(ctx: &Ctx, dst: &str, input: &std::path::Path, out: &std::path::Path) -> Cmd {
    let o = ctx.opts;
    let mut c = Cmd::new(EngineId::Ffmpeg).args(["-hide_banner", "-loglevel", "error", "-y", "-i"]).arg(input).args(["-frames:v", "1"]);
    let mut vf = Vec::new();
    match o.resize {
        Resize::MaxSide(n) => vf.push(format!("scale='min({n},iw)':'min({n},ih)':force_original_aspect_ratio=decrease")),
        Resize::Percent(p) => vf.push(format!("scale=iw*{p}/100:-1")),
        Resize::None => {}
    }
    if dst == "avif" {
        vf.push("scale=trunc(iw/2)*2:trunc(ih/2)*2".into());
    }
    if !vf.is_empty() {
        c = c.arg("-vf").arg(vf.join(","));
    }
    if o.strip_metadata {
        c = c.args(["-map_metadata", "-1"]);
    }
    if dst == "webp" {
        c = c.args(["-c:v", "libwebp", "-quality"]).arg(o.image_quality.to_string());
    } else {
        let crf = ((100 - o.image_quality as i32) as f64 * 0.6 + 12.0).round() as i32;
        let enc = if ctx.engines.ff_encoder("libaom-av1") { "libaom-av1" } else { "libsvtav1" };
        c = c.args(["-c:v", enc, "-still-picture", "1", "-pix_fmt", "yuv420p", "-crf"]).arg(crf.to_string());
        if enc == "libaom-av1" {
            c = c.args(["-cpu-used", "6"]);
        }
    }
    c.arg(out)
}
