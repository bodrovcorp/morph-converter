//! Параметры конвертации (качество, размер, метаданные…). Приходят из интерфейса в виде JSON.

use crate::text::json::Json;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum VideoQuality {
    High,
    Balanced,
    Small,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Resize {
    None,
    /// Наибольшая сторона, px
    MaxSide(u32),
    Percent(u32),
}

#[derive(Debug, Clone)]
pub struct Options {
    pub image_quality: u8,
    pub resize: Resize,
    pub strip_metadata: bool,
    pub video_quality: VideoQuality,
    /// Высота кадра (1080, 720…), None — как у исходника
    pub video_height: Option<u32>,
    pub no_audio: bool,
    pub gif_fps: u32,
    pub gif_width: u32,
    pub audio_bitrate: u32,
    pub pdf_dpi: u32,
    /// CSV для Excel: UTF-8 с BOM
    pub csv_bom: bool,
    pub csv_delimiter: char,
}

impl Default for Options {
    fn default() -> Self {
        Options {
            image_quality: 85,
            resize: Resize::None,
            strip_metadata: false,
            video_quality: VideoQuality::Balanced,
            video_height: None,
            no_audio: false,
            gif_fps: 12,
            gif_width: 480,
            audio_bitrate: 192,
            pdf_dpi: 150,
            csv_bom: true,
            csv_delimiter: ',',
        }
    }
}

impl Options {
    /// Разбирает JSON-объект параметров; неизвестные и неверные поля игнорируются.
    pub fn from_json(v: &Json) -> Options {
        let mut o = Options::default();
        let num = |k: &str| v.get(k).and_then(|x| x.as_f64());
        if let Some(q) = num("quality") {
            o.image_quality = q.clamp(1.0, 100.0) as u8;
        }
        if let Some(s) = num("maxSide") {
            if s >= 8.0 {
                o.resize = Resize::MaxSide(s as u32);
            }
        }
        if let Some(p) = num("scale") {
            if (1.0..=400.0).contains(&p) && p != 100.0 {
                o.resize = Resize::Percent(p as u32);
            }
        }
        if let Some(b) = v.get("stripMetadata").and_then(|x| x.as_bool()) {
            o.strip_metadata = b;
        }
        if let Some(q) = v.get("videoQuality").and_then(|x| x.as_str()) {
            o.video_quality = match q {
                "high" => VideoQuality::High,
                "small" => VideoQuality::Small,
                _ => VideoQuality::Balanced,
            };
        }
        if let Some(h) = num("height") {
            if h >= 120.0 {
                o.video_height = Some(h as u32);
            }
        }
        if let Some(b) = v.get("noAudio").and_then(|x| x.as_bool()) {
            o.no_audio = b;
        }
        if let Some(f) = num("gifFps") {
            o.gif_fps = f.clamp(1.0, 50.0) as u32;
        }
        if let Some(w) = num("gifWidth") {
            o.gif_width = w.clamp(64.0, 1920.0) as u32;
        }
        if let Some(b) = num("audioBitrate") {
            o.audio_bitrate = b.clamp(32.0, 512.0) as u32;
        }
        if let Some(d) = num("dpi") {
            o.pdf_dpi = d.clamp(36.0, 600.0) as u32;
        }
        if let Some(b) = v.get("csvBom").and_then(|x| x.as_bool()) {
            o.csv_bom = b;
        }
        if let Some(d) = v.get("csvDelimiter").and_then(|x| x.as_str()).and_then(|s| s.chars().next()) {
            if matches!(d, ',' | ';' | '\t' | '|') {
                o.csv_delimiter = d;
            }
        }
        o
    }

    /// CRF для H.264 / VP9 по пресету качества
    pub fn crf_h264(&self) -> u32 {
        match self.video_quality {
            VideoQuality::High => 18,
            VideoQuality::Balanced => 23,
            VideoQuality::Small => 28,
        }
    }
    pub fn crf_vp9(&self) -> u32 {
        match self.video_quality {
            VideoQuality::High => 24,
            VideoQuality::Balanced => 32,
            VideoQuality::Small => 40,
        }
    }
}

/// Какие параметры показывать в меню для цели
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum OptKind {
    Quality,
    Resize,
    StripMetadata,
    VideoQuality,
    VideoHeight,
    NoAudio,
    Gif,
    AudioBitrate,
    Dpi,
    CsvBom,
}

impl OptKind {
    pub fn id(self) -> &'static str {
        match self {
            OptKind::Quality => "quality",
            OptKind::Resize => "resize",
            OptKind::StripMetadata => "stripMetadata",
            OptKind::VideoQuality => "videoQuality",
            OptKind::VideoHeight => "height",
            OptKind::NoAudio => "noAudio",
            OptKind::Gif => "gif",
            OptKind::AudioBitrate => "audioBitrate",
            OptKind::Dpi => "dpi",
            OptKind::CsvBom => "csvBom",
        }
    }
}

pub fn opts_json(list: &[OptKind]) -> Json {
    Json::Arr(list.iter().map(|o| Json::str(o.id())).collect())
}
