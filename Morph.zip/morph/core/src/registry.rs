//! Реестр конвертеров. Каждый конвертер — отдельный модуль, реализующий трейт `Converter`.
//! Чтобы добавить формат: напишите модуль в `converters/`, реализуйте трейт и добавьте строку в `Registry::new()`.

use crate::engines::{Cmd, EngineId, Engines};
use crate::error::ConvError;
use crate::formats::{Format, Kind};
use crate::options::{OptKind, Options};
use crate::text::json::Json;
use std::collections::BTreeMap;
use std::path::{Path, PathBuf};

/// Вариант конвертации, который показывается в меню.
#[derive(Debug, Clone)]
pub struct Offer {
    /// Уникальный id цели: «jpg», «png_pages», «unpack», «merge_pdf»…
    pub id: String,
    /// Какой конвертер выполняет
    pub converter: &'static str,
    /// Расширение результата («» для папки)
    pub ext: &'static str,
    /// Заголовок в меню («JPG», «Распаковать»)
    pub title: String,
    /// Подсказка («Совместимо везде»)
    pub desc: String,
    /// Показывать в «Популярных»
    pub popular: bool,
    /// Порядок внутри группы (меньше — выше)
    pub rank: u16,
    /// Группа в «Ещё»
    pub kind: Kind,
    /// Каких движков не хватает (пусто — всё есть)
    pub missing: Vec<EngineId>,
    pub options: Vec<OptKind>,
    /// Один результат из нескольких файлов (объединение)
    pub combine: bool,
}

impl Offer {
    pub fn new(converter: &'static str, id: &str, ext: &'static str, title: &str, desc: &str, kind: Kind) -> Offer {
        Offer {
            id: id.to_string(),
            converter,
            ext,
            title: title.to_string(),
            desc: desc.to_string(),
            popular: false,
            rank: 100,
            kind,
            missing: Vec::new(),
            options: Vec::new(),
            combine: false,
        }
    }
    pub fn to(converter: &'static str, f: &'static Format) -> Offer {
        Offer::new(converter, f.id, f.ext(), f.title, f.desc, f.kind)
    }
    pub fn pop(mut self, rank: u16) -> Offer {
        self.popular = true;
        self.rank = rank;
        self
    }
    pub fn rank(mut self, rank: u16) -> Offer {
        self.rank = rank;
        self
    }
    pub fn opts(mut self, o: &[OptKind]) -> Offer {
        self.options = o.to_vec();
        self
    }
    pub fn needs(mut self, engines: &Engines, need: &[&[EngineId]]) -> Offer {
        // need — список групп «хотя бы один из»
        for group in need {
            if !group.iter().any(|e| engines.has(*e)) {
                self.missing.push(group[0]);
            }
        }
        self
    }
    pub fn missing(mut self, m: Vec<EngineId>) -> Offer {
        self.missing = m;
        self
    }
    pub fn to_json(&self) -> Json {
        Json::obj(vec![
            ("id", Json::str(&self.id)),
            ("converter", Json::str(self.converter)),
            ("ext", Json::str(self.ext)),
            ("title", Json::str(&self.title)),
            ("desc", Json::str(&self.desc)),
            ("popular", Json::Bool(self.popular)),
            ("rank", Json::num(self.rank as f64)),
            ("kind", Json::str(self.kind.id())),
            ("kindTitle", Json::str(self.kind.title())),
            ("missing", Json::Arr(self.missing.iter().map(|e| Json::str(e.id())).collect())),
            ("missingTitles", Json::Arr(self.missing.iter().map(|e| Json::str(e.title())).collect())),
            ("options", crate::options::opts_json(&self.options)),
            ("combine", Json::Bool(self.combine)),
        ])
    }
}

/// Входной файл с определённым форматом
#[derive(Debug, Clone)]
pub struct Input {
    pub path: PathBuf,
    pub format: &'static Format,
}

impl Input {
    pub fn stem(&self) -> String {
        let name = self.path.file_name().map(|s| s.to_string_lossy().to_string()).unwrap_or_default();
        if self.format.kind == Kind::Folder {
            return name;
        }
        crate::formats::split_name(&name).0
    }
}

/// Шаг плана
pub enum Step {
    /// Внешняя программа; weight — доля общего времени
    Run { cmd: Cmd, weight: f64 },
    /// Встроенная операция (перекодирование CSV, JSON и т. п.)
    Func { name: &'static str, weight: f64, f: Box<dyn FnOnce() -> Result<(), ConvError> + Send> },
}

impl Step {
    pub fn run(cmd: Cmd) -> Step {
        Step::Run { cmd, weight: 1.0 }
    }
    pub fn run_w(cmd: Cmd, weight: f64) -> Step {
        Step::Run { cmd, weight }
    }
    pub fn func(name: &'static str, f: impl FnOnce() -> Result<(), ConvError> + Send + 'static) -> Step {
        Step::Func { name, weight: 0.2, f: Box::new(f) }
    }
    pub fn weight(&self) -> f64 {
        match self {
            Step::Run { weight, .. } | Step::Func { weight, .. } => *weight,
        }
    }
    pub fn describe(&self) -> String {
        match self {
            Step::Run { cmd, .. } => cmd.display(),
            Step::Func { name, .. } => format!("[встроенный шаг] {name}"),
        }
    }
}

/// Что получится в рабочей папке после выполнения плана
#[derive(Debug, Clone)]
pub enum Output {
    /// Один файл
    File(PathBuf),
    /// Несколько файлов в папке (страницы PDF, слайды). Если файл один — сохранится как файл.
    Many { dir: PathBuf, ext: &'static str },
    /// Папка целиком (распаковка архива)
    Dir(PathBuf),
}

pub struct Plan {
    pub steps: Vec<Step>,
    pub output: Output,
    /// Имя результата без расширения (по умолчанию — имя первого входного файла)
    pub stem: Option<String>,
}

impl Plan {
    pub fn new(steps: Vec<Step>, output: Output) -> Plan {
        Plan { steps, output, stem: None }
    }
}

/// Контекст планирования
pub struct Ctx<'a> {
    pub inputs: &'a [Input],
    pub offer: &'a Offer,
    pub opts: &'a Options,
    pub engines: &'a Engines,
    /// Временная рабочая папка задачи
    pub work: &'a Path,
}

impl Ctx<'_> {
    pub fn input(&self) -> &Input {
        &self.inputs[0]
    }
    pub fn out(&self, name: &str) -> PathBuf {
        self.work.join(name)
    }
}

pub trait Converter: Send + Sync {
    fn name(&self) -> &'static str;
    /// Варианты для одного файла данного формата
    fn offers(&self, src: &'static Format, engines: &Engines) -> Vec<Offer>;
    /// Варианты для набора файлов, дающие ОДИН результат (объединение PDF, архив из нескольких файлов)
    fn combine_offers(&self, _srcs: &[&'static Format], _engines: &Engines) -> Vec<Offer> {
        Vec::new()
    }
    fn plan(&self, ctx: &Ctx) -> Result<Plan, ConvError>;
}

pub struct Registry {
    pub converters: Vec<Box<dyn Converter>>,
}

impl Default for Registry {
    fn default() -> Self {
        Self::new()
    }
}

impl Registry {
    pub fn new() -> Registry {
        use crate::converters::*;
        Registry {
            converters: vec![
                Box::new(image::ImageConverter),
                Box::new(video::VideoConverter),
                Box::new(audio::AudioConverter),
                Box::new(document::DocumentConverter),
                Box::new(pdf::PdfConverter),
                Box::new(sheet::SheetConverter),
                Box::new(slides::SlidesConverter),
                Box::new(ebook::EbookConverter),
                Box::new(archive::ArchiveConverter),
            ],
        }
    }

    pub fn get(&self, name: &str) -> Option<&dyn Converter> {
        self.converters.iter().find(|c| c.name() == name).map(|c| c.as_ref())
    }

    /// Все варианты для одного формата (без дублей по id; приоритет — у первого конвертера)
    pub fn offers_for(&self, f: &'static Format, engines: &Engines) -> Vec<Offer> {
        let mut seen = BTreeMap::new();
        for c in &self.converters {
            for o in c.offers(f, engines) {
                seen.entry(o.id.clone()).or_insert(o);
            }
        }
        let mut v: Vec<Offer> = seen.into_values().collect();
        v.sort_by(|a, b| (!a.popular, a.rank, a.title.clone()).cmp(&(!b.popular, b.rank, b.title.clone())));
        v
    }

    /// Варианты для выделения: общие для всех файлов + объединяющие.
    pub fn offers_for_many(&self, formats: &[&'static Format], engines: &Engines) -> Vec<Offer> {
        if formats.is_empty() {
            return Vec::new();
        }
        let mut common = self.offers_for(formats[0], engines);
        for f in &formats[1..] {
            let other = self.offers_for(f, engines);
            common.retain(|o| other.iter().any(|x| x.id == o.id));
            // недостающие движки объединяем
            for o in common.iter_mut() {
                if let Some(x) = other.iter().find(|x| x.id == o.id) {
                    for m in &x.missing {
                        if !o.missing.contains(m) {
                            o.missing.push(*m);
                        }
                    }
                }
            }
        }
        if formats.len() > 1 {
            let mut extra = Vec::new();
            for c in &self.converters {
                extra.extend(c.combine_offers(formats, engines));
            }
            // объединяющие варианты — в начало
            extra.sort_by_key(|o| o.rank);
            extra.extend(common);
            common = extra;
        }
        common
    }

    pub fn plan(&self, ctx: &Ctx) -> Result<Plan, ConvError> {
        let c = self
            .get(ctx.offer.converter)
            .ok_or_else(|| ConvError::new(crate::error::ErrKind::Internal, format!("нет конвертера {}", ctx.offer.converter)))?;
        c.plan(ctx)
    }

    /// Полная таблица «из чего → во что» (без учёта установленных движков).
    pub fn matrix(&self) -> Vec<(&'static Format, Vec<Offer>)> {
        let all = Engines::all();
        crate::formats::FORMATS.iter().map(|f| (f, self.offers_for(f, &all))).collect()
    }
}
