//! Ошибки с понятными пользователю сообщениями.

use crate::engines::EngineId;
use std::fmt;
use std::io;

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum ErrKind {
    InputMissing,
    InputCorrupt,
    PasswordProtected,
    Unsupported,
    NoWritePermission,
    DiskFull,
    EngineMissing(EngineId),
    EngineFailed,
    Cancelled,
    Empty,
    BadData(String),
    Internal,
}

#[derive(Debug, Clone)]
pub struct ConvError {
    pub kind: ErrKind,
    /// Технические подробности для кнопки «Подробнее»
    pub details: String,
}

impl ConvError {
    pub fn new(kind: ErrKind, details: impl Into<String>) -> Self {
        ConvError { kind, details: details.into() }
    }
    pub fn cancelled() -> Self {
        Self::new(ErrKind::Cancelled, "")
    }
    pub fn is_cancelled(&self) -> bool {
        self.kind == ErrKind::Cancelled
    }

    /// Сообщение для пользователя — без трейсбеков и технического жаргона.
    pub fn user_message(&self) -> String {
        match &self.kind {
            ErrKind::InputMissing => "Не удалось найти файл: возможно, его переместили или удалили.".into(),
            ErrKind::InputCorrupt => "Не удалось открыть файл: он повреждён или сохранён в неподдерживаемом варианте формата.".into(),
            ErrKind::PasswordProtected => "Файл защищён паролем. Снимите пароль и попробуйте снова.".into(),
            ErrKind::Unsupported => "Такое преобразование для этого файла не поддерживается.".into(),
            ErrKind::NoWritePermission => "Нет прав на запись в папку. Выберите другую папку сохранения в настройках.".into(),
            ErrKind::DiskFull => "На диске не хватает места для результата.".into(),
            ErrKind::EngineMissing(e) => format!("Не установлен компонент «{}». Его можно добавить в Настройках → Компоненты.", e.title()),
            ErrKind::EngineFailed => "Конвертер завершился с ошибкой. Подробности — по кнопке «Подробнее».".into(),
            ErrKind::Cancelled => "Конвертация отменена.".into(),
            ErrKind::Empty => "Результат получился пустым — исходный файл, вероятно, не содержит данных.".into(),
            ErrKind::BadData(msg) => msg.clone(),
            ErrKind::Internal => "Внутренняя ошибка приложения. Подробности — по кнопке «Подробнее».".into(),
        }
    }

    /// Ошибка ввода-вывода при записи результата.
    pub fn from_io_write(e: &io::Error, what: &str) -> Self {
        let kind = match e.kind() {
            io::ErrorKind::PermissionDenied | io::ErrorKind::ReadOnlyFilesystem => ErrKind::NoWritePermission,
            io::ErrorKind::StorageFull | io::ErrorKind::QuotaExceeded => ErrKind::DiskFull,
            _ => match e.raw_os_error() {
                Some(28) | Some(112) => ErrKind::DiskFull,              // ENOSPC / ERROR_DISK_FULL
                Some(13) | Some(30) | Some(5) => ErrKind::NoWritePermission, // EACCES / EROFS / ERROR_ACCESS_DENIED
                _ => ErrKind::Internal,
            },
        };
        Self::new(kind, format!("{what}: {e}"))
    }

    pub fn from_io_read(e: &io::Error, what: &str) -> Self {
        let kind = match e.kind() {
            io::ErrorKind::NotFound => ErrKind::InputMissing,
            io::ErrorKind::PermissionDenied => ErrKind::BadData("Нет прав на чтение файла.".into()),
            _ => ErrKind::Internal,
        };
        Self::new(kind, format!("{what}: {e}"))
    }
}

impl fmt::Display for ConvError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "{}", self.user_message())
    }
}

impl std::error::Error for ConvError {}

/// Сопоставляет вывод движка с понятной ошибкой.
pub fn classify(engine: EngineId, code: Option<i32>, stderr: &str) -> ConvError {
    let s = stderr.to_lowercase();
    let has = |pats: &[&str]| pats.iter().any(|p| s.contains(p));
    let kind = if has(&["no space left", "disk full", "not enough space", "недостаточно места"]) {
        ErrKind::DiskFull
    } else if has(&["permission denied", "access is denied", "read-only file system", "отказано в доступе"]) {
        ErrKind::NoWritePermission
    } else if has(&["password", "encrypted", "decrypt"]) && !has(&["no password"]) {
        ErrKind::PasswordProtected
    } else if has(&[
        "invalid data found when processing input",
        "moov atom not found",
        "could not find codec parameters",
        "end of file",
        "corrupt",
        "improper image header",
        "insufficient image data",
        "no decode delegate",
        "not a jpeg file",
        "premature end",
        "unexpected end",
        "syntax error",
        "couldn't read xref",
        "may not be a pdf",
        "not a pdf",
        "source file could not be loaded",
        "general input/output error",
        "unrecognized archive format",
        "is not a zip archive",
        "can not open the file as archive",
        "not in gzip format",
        "error reading",
        "truncated",
        "bad magic",
        "failed to read",
        "cannot decode",
        "unexpected token",
        "unable to open image",
        "zlib",
        "unknown file format",
        "could not open",
        "end-of-central-directory",
        "cannot find zipfile directory",
        "zipfile is empty",
        "damaged",
        "headers error",
        "data error",
        "not a valid",
    ]) {
        ErrKind::InputCorrupt
    } else {
        ErrKind::EngineFailed
    };
    let tail: String = {
        let lines: Vec<&str> = stderr.lines().filter(|l| !l.trim().is_empty()).collect();
        lines[lines.len().saturating_sub(15)..].join("\n")
    };
    ConvError::new(kind, format!("{} завершился с кодом {:?}\n{}", engine.title(), code, tail))
}
