//! Morph core — ядро локального конвертера файлов.
//!
//! * `formats` — каталог форматов и определение типа по содержимому;
//! * `registry` + `converters` — конвертеры-модули и меню целей;
//! * `engines` — поиск движков (FFmpeg, ImageMagick, LibreOffice…), запуск, прогресс, отмена;
//! * `queue` — очередь задач;
//! * `naming` — имена результатов без перезаписи;
//! * `text` — кодировки, CSV, JSON.

pub mod converters;
pub mod engines;
pub mod error;
pub mod formats;
pub mod naming;
pub mod options;
pub mod queue;
pub mod registry;
pub mod text;

use engines::Engines;
use formats::detect;
use registry::Registry;
use std::path::PathBuf;
use text::json::Json;

/// Описание выделения для меню: формат каждого файла + доступные цели.
pub fn menu_json(paths: &[PathBuf], engines: &Engines) -> Json {
    let reg = Registry::new();
    let mut files = Vec::new();
    let mut formats = Vec::new();
    let mut unknown = Vec::new();
    for p in paths {
        match detect(p) {
            Some(f) => {
                formats.push(f);
                let size = std::fs::metadata(p).map(|m| m.len()).unwrap_or(0);
                files.push(Json::obj(vec![
                    ("path", Json::str(p.to_string_lossy())),
                    ("name", Json::str(p.file_name().map(|s| s.to_string_lossy().to_string()).unwrap_or_default())),
                    ("format", Json::str(f.id)),
                    ("formatTitle", Json::str(f.title)),
                    ("kind", Json::str(f.kind.id())),
                    ("kindTitle", Json::str(f.kind.title())),
                    ("size", Json::num(size as f64)),
                ]));
            }
            None => unknown.push(Json::str(p.to_string_lossy())),
        }
    }
    let offers = reg.offers_for_many(&formats, engines);
    Json::obj(vec![
        ("files", Json::Arr(files)),
        ("unknown", Json::Arr(unknown)),
        ("offers", Json::Arr(offers.iter().map(|o| o.to_json()).collect())),
    ])
}

/// Состояние движков для экрана «Компоненты»
pub fn engines_json(engines: &Engines) -> Json {
    Json::Arr(
        engines
            .status()
            .into_iter()
            .map(|s| {
                Json::obj(vec![
                    ("id", Json::str(s.id.id())),
                    ("title", Json::str(s.id.title())),
                    ("purpose", Json::str(s.id.purpose())),
                    ("delivery", Json::str(s.id.delivery())),
                    ("downloadMb", Json::num(s.id.download_mb() as f64)),
                    ("path", s.path.map(|p| Json::str(p.to_string_lossy())).unwrap_or(Json::Null)),
                ])
            })
            .collect(),
    )
}
