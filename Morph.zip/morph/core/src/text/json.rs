//! Небольшой JSON-парсер/писатель без зависимостей + преобразования JSON ↔ таблица.

use std::collections::BTreeMap;
use std::fmt::Write as _;

#[derive(Debug, Clone, PartialEq)]
pub enum Json {
    Null,
    Bool(bool),
    Num(f64, String), // число и исходная запись (чтобы не терять точность/формат)
    Str(String),
    Arr(Vec<Json>),
    Obj(Vec<(String, Json)>), // порядок ключей сохраняется
}

impl Json {
    pub fn get(&self, key: &str) -> Option<&Json> {
        match self {
            Json::Obj(v) => v.iter().find(|(k, _)| k == key).map(|(_, v)| v),
            _ => None,
        }
    }
    pub fn as_str(&self) -> Option<&str> {
        match self {
            Json::Str(s) => Some(s),
            _ => None,
        }
    }
    pub fn as_f64(&self) -> Option<f64> {
        match self {
            Json::Num(n, _) => Some(*n),
            Json::Str(s) => s.parse().ok(),
            _ => None,
        }
    }
    pub fn as_bool(&self) -> Option<bool> {
        match self {
            Json::Bool(b) => Some(*b),
            _ => None,
        }
    }
    pub fn str(s: impl Into<String>) -> Json {
        Json::Str(s.into())
    }
    pub fn num(n: f64) -> Json {
        let repr = if n.fract() == 0.0 && n.abs() < 1e15 { format!("{}", n as i64) } else { format!("{}", n) };
        Json::Num(n, repr)
    }
    pub fn obj(pairs: Vec<(&str, Json)>) -> Json {
        Json::Obj(pairs.into_iter().map(|(k, v)| (k.to_string(), v)).collect())
    }
}

#[derive(Debug)]
pub struct ParseError {
    pub pos: usize,
    pub msg: &'static str,
}

pub fn parse(s: &str) -> Result<Json, ParseError> {
    let s = s.strip_prefix('\u{feff}').unwrap_or(s);
    let mut p = Parser { b: s.as_bytes(), i: 0, src: s };
    p.ws();
    let v = p.value(0)?;
    p.ws();
    if p.i != p.b.len() {
        return Err(p.err("лишние символы после JSON"));
    }
    Ok(v)
}

struct Parser<'a> {
    b: &'a [u8],
    i: usize,
    src: &'a str,
}

impl<'a> Parser<'a> {
    fn err(&self, msg: &'static str) -> ParseError {
        ParseError { pos: self.i, msg }
    }
    fn ws(&mut self) {
        while self.i < self.b.len() && matches!(self.b[self.i], b' ' | b'\t' | b'\n' | b'\r') {
            self.i += 1;
        }
    }
    fn value(&mut self, depth: usize) -> Result<Json, ParseError> {
        if depth > 256 {
            return Err(self.err("слишком глубокая вложенность"));
        }
        match self.b.get(self.i) {
            None => Err(self.err("неожиданный конец")),
            Some(b'{') => {
                self.i += 1;
                let mut v = Vec::new();
                self.ws();
                if self.b.get(self.i) == Some(&b'}') {
                    self.i += 1;
                    return Ok(Json::Obj(v));
                }
                loop {
                    self.ws();
                    let k = self.string()?;
                    self.ws();
                    if self.b.get(self.i) != Some(&b':') {
                        return Err(self.err("ожидалось «:»"));
                    }
                    self.i += 1;
                    self.ws();
                    let val = self.value(depth + 1)?;
                    v.push((k, val));
                    self.ws();
                    match self.b.get(self.i) {
                        Some(b',') => self.i += 1,
                        Some(b'}') => {
                            self.i += 1;
                            return Ok(Json::Obj(v));
                        }
                        _ => return Err(self.err("ожидалось «,» или «}»")),
                    }
                }
            }
            Some(b'[') => {
                self.i += 1;
                let mut v = Vec::new();
                self.ws();
                if self.b.get(self.i) == Some(&b']') {
                    self.i += 1;
                    return Ok(Json::Arr(v));
                }
                loop {
                    self.ws();
                    v.push(self.value(depth + 1)?);
                    self.ws();
                    match self.b.get(self.i) {
                        Some(b',') => self.i += 1,
                        Some(b']') => {
                            self.i += 1;
                            return Ok(Json::Arr(v));
                        }
                        _ => return Err(self.err("ожидалось «,» или «]»")),
                    }
                }
            }
            Some(b'"') => Ok(Json::Str(self.string()?)),
            Some(b't') => self.lit("true", Json::Bool(true)),
            Some(b'f') => self.lit("false", Json::Bool(false)),
            Some(b'n') => self.lit("null", Json::Null),
            Some(_) => self.number(),
        }
    }
    fn lit(&mut self, word: &str, v: Json) -> Result<Json, ParseError> {
        if self.b[self.i..].starts_with(word.as_bytes()) {
            self.i += word.len();
            Ok(v)
        } else {
            Err(self.err("неизвестное значение"))
        }
    }
    fn number(&mut self) -> Result<Json, ParseError> {
        let start = self.i;
        while self.i < self.b.len() && matches!(self.b[self.i], b'-' | b'+' | b'.' | b'e' | b'E' | b'0'..=b'9') {
            self.i += 1;
        }
        let t = &self.src[start..self.i];
        t.parse::<f64>().map(|n| Json::Num(n, t.to_string())).map_err(|_| self.err("неверное число"))
    }
    fn string(&mut self) -> Result<String, ParseError> {
        if self.b.get(self.i) != Some(&b'"') {
            return Err(self.err("ожидалась строка"));
        }
        self.i += 1;
        let mut out = String::new();
        loop {
            let start = self.i;
            while self.i < self.b.len() && self.b[self.i] != b'"' && self.b[self.i] != b'\\' {
                self.i += 1;
            }
            out.push_str(&self.src[start..self.i]);
            match self.b.get(self.i) {
                None => return Err(self.err("незакрытая строка")),
                Some(b'"') => {
                    self.i += 1;
                    return Ok(out);
                }
                Some(_) => {
                    self.i += 1;
                    let e = *self.b.get(self.i).ok_or(self.err("незакрытая строка"))?;
                    self.i += 1;
                    match e {
                        b'"' => out.push('"'),
                        b'\\' => out.push('\\'),
                        b'/' => out.push('/'),
                        b'b' => out.push('\u{8}'),
                        b'f' => out.push('\u{c}'),
                        b'n' => out.push('\n'),
                        b'r' => out.push('\r'),
                        b't' => out.push('\t'),
                        b'u' => {
                            let cp = self.hex4()?;
                            if (0xD800..0xDC00).contains(&cp) && self.b[self.i..].starts_with(b"\\u") {
                                self.i += 2;
                                let lo = self.hex4()?;
                                let c = 0x10000 + ((cp - 0xD800) << 10) + (lo.wrapping_sub(0xDC00) & 0x3FF);
                                out.push(char::from_u32(c).unwrap_or('\u{FFFD}'));
                            } else {
                                out.push(char::from_u32(cp).unwrap_or('\u{FFFD}'));
                            }
                        }
                        _ => return Err(self.err("неверная escape-последовательность")),
                    }
                }
            }
        }
    }
    fn hex4(&mut self) -> Result<u32, ParseError> {
        let h = self.src.get(self.i..self.i + 4).ok_or(self.err("неверный \\u"))?;
        self.i += 4;
        u32::from_str_radix(h, 16).map_err(|_| self.err("неверный \\u"))
    }
}

pub fn escape(s: &str, out: &mut String) {
    out.push('"');
    for c in s.chars() {
        match c {
            '"' => out.push_str("\\\""),
            '\\' => out.push_str("\\\\"),
            '\n' => out.push_str("\\n"),
            '\r' => out.push_str("\\r"),
            '\t' => out.push_str("\\t"),
            c if (c as u32) < 0x20 => {
                let _ = write!(out, "\\u{:04x}", c as u32);
            }
            c => out.push(c),
        }
    }
    out.push('"');
}

pub fn to_string(v: &Json) -> String {
    let mut s = String::new();
    write_val(v, &mut s, None, 0);
    s
}

pub fn to_string_pretty(v: &Json) -> String {
    let mut s = String::new();
    write_val(v, &mut s, Some(2), 0);
    s.push('\n');
    s
}

fn write_val(v: &Json, out: &mut String, indent: Option<usize>, level: usize) {
    let nl = |out: &mut String, lvl: usize| {
        if let Some(n) = indent {
            out.push('\n');
            out.push_str(&" ".repeat(n * lvl));
        }
    };
    match v {
        Json::Null => out.push_str("null"),
        Json::Bool(b) => out.push_str(if *b { "true" } else { "false" }),
        Json::Num(_, r) => out.push_str(r),
        Json::Str(s) => escape(s, out),
        Json::Arr(a) => {
            out.push('[');
            for (i, x) in a.iter().enumerate() {
                if i > 0 {
                    out.push(',');
                }
                nl(out, level + 1);
                write_val(x, out, indent, level + 1);
            }
            if !a.is_empty() {
                nl(out, level);
            }
            out.push(']');
        }
        Json::Obj(o) => {
            out.push('{');
            for (i, (k, x)) in o.iter().enumerate() {
                if i > 0 {
                    out.push(',');
                }
                nl(out, level + 1);
                escape(k, out);
                out.push(':');
                if indent.is_some() {
                    out.push(' ');
                }
                write_val(x, out, indent, level + 1);
            }
            if !o.is_empty() {
                nl(out, level);
            }
            out.push('}');
        }
    }
}

// ---------- JSON ↔ таблица ----------

fn flatten(prefix: &str, v: &Json, out: &mut Vec<(String, String)>) {
    match v {
        Json::Obj(o) if !o.is_empty() => {
            for (k, x) in o {
                let key = if prefix.is_empty() { k.clone() } else { format!("{prefix}.{k}") };
                flatten(&key, x, out);
            }
        }
        Json::Null => out.push((prefix.to_string(), String::new())),
        Json::Bool(b) => out.push((prefix.to_string(), b.to_string())),
        Json::Num(_, r) => out.push((prefix.to_string(), r.clone())),
        Json::Str(s) => out.push((prefix.to_string(), s.clone())),
        // массивы и пустые объекты сохраняем как JSON внутри ячейки
        other => out.push((prefix.to_string(), to_string(other))),
    }
}

/// JSON → таблица. Понимает: массив объектов, массив массивов, объект с одним массивом внутри, одиночный объект.
pub fn to_table(v: &Json) -> Result<Vec<Vec<String>>, &'static str> {
    let arr: Vec<Json> = match v {
        Json::Arr(a) => a.clone(),
        Json::Obj(o) => {
            let arrays: Vec<&Json> = o.iter().map(|(_, x)| x).filter(|x| matches!(x, Json::Arr(_))).collect();
            if arrays.len() == 1 {
                if let Json::Arr(a) = arrays[0] {
                    a.clone()
                } else {
                    unreachable!()
                }
            } else {
                vec![v.clone()]
            }
        }
        _ => return Err("В JSON нет таблицы: ожидался массив объектов"),
    };
    if arr.is_empty() {
        return Err("JSON-массив пуст");
    }
    if arr.iter().all(|x| matches!(x, Json::Arr(_))) {
        return Ok(arr
            .iter()
            .map(|r| match r {
                Json::Arr(cells) => cells
                    .iter()
                    .map(|c| {
                        let mut f = Vec::new();
                        flatten("", c, &mut f);
                        f.into_iter().next().map(|(_, s)| s).unwrap_or_default()
                    })
                    .collect(),
                _ => unreachable!(),
            })
            .collect());
    }
    let mut cols: Vec<String> = Vec::new();
    let mut index: BTreeMap<String, usize> = BTreeMap::new();
    let mut rows: Vec<Vec<(String, String)>> = Vec::new();
    for item in &arr {
        let mut f = Vec::new();
        match item {
            Json::Obj(_) => flatten("", item, &mut f),
            other => flatten("value", other, &mut f),
        }
        for (k, _) in &f {
            if !index.contains_key(k) {
                index.insert(k.clone(), cols.len());
                cols.push(k.clone());
            }
        }
        rows.push(f);
    }
    let mut table = vec![cols.clone()];
    for r in rows {
        let mut line = vec![String::new(); cols.len()];
        for (k, val) in r {
            line[index[&k]] = val;
        }
        table.push(line);
    }
    Ok(table)
}

/// «Безопасное» число: без ведущих нулей, без пробелов, конечное. «007» и «+7 900…» остаются строками.
fn as_number(s: &str) -> Option<Json> {
    let t = s.trim();
    if t.is_empty() || t != s || t.len() > 15 {
        return None;
    }
    let digits = t.trim_start_matches('-');
    if digits.len() > 1 && digits.starts_with('0') && !digits.starts_with("0.") {
        return None;
    }
    if t.starts_with('+') || t.ends_with('.') || t.starts_with('.') {
        return None;
    }
    if !t.chars().all(|c| c.is_ascii_digit() || c == '-' || c == '.') {
        return None;
    }
    t.parse::<f64>().ok().filter(|n| n.is_finite()).map(|n| Json::Num(n, t.to_string()))
}

/// Таблица (первая строка — заголовки) → массив объектов.
pub fn from_table(t: &[Vec<String>]) -> Json {
    from_table_ex(t, false)
}

/// `decimal_comma` — числа записаны с десятичной запятой («1500,5»), как в русском Excel.
pub fn from_table_ex(t: &[Vec<String>], decimal_comma: bool) -> Json {
    if t.is_empty() {
        return Json::Arr(vec![]);
    }
    let headers: Vec<String> = t[0]
        .iter()
        .enumerate()
        .map(|(i, h)| if h.trim().is_empty() { format!("column{}", i + 1) } else { h.trim().to_string() })
        .collect();
    let mut out = Vec::new();
    for row in &t[1..] {
        let mut obj = Vec::new();
        for (i, h) in headers.iter().enumerate() {
            let cell = row.get(i).cloned().unwrap_or_default();
            let num = if decimal_comma && cell.matches(',').count() == 1 && !cell.contains('.') {
                as_number(&cell.replace(',', ".")).map(|j| match j {
                    Json::Num(n, r) => Json::Num(n, r),
                    other => other,
                })
            } else {
                as_number(&cell)
            };
            let v = num.unwrap_or(Json::Str(cell));
            obj.push((h.clone(), v));
        }
        out.push(Json::Obj(obj));
    }
    Json::Arr(out)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parse_and_write() {
        let v = parse(r#"{"имя":"Ольга","n":[1,2.5,-3e2],"ok":true,"z":null,"s":"a\"bж"}"#).unwrap();
        assert_eq!(v.get("имя").unwrap().as_str(), Some("Ольга"));
        assert_eq!(v.get("s").unwrap().as_str(), Some("a\"bж"));
        let back = parse(&to_string_pretty(&v)).unwrap();
        assert_eq!(back, v);
    }

    #[test]
    fn rejects_garbage() {
        assert!(parse("{\"a\":}").is_err());
        assert!(parse("[1,2").is_err());
        assert!(parse("1 2").is_err());
    }

    #[test]
    fn table_roundtrip() {
        let v = parse(r#"[{"id":1,"name":"Иван","geo":{"city":"Москва"}},{"id":2,"tags":["a","b"]}]"#).unwrap();
        let t = to_table(&v).unwrap();
        assert_eq!(t[0], vec!["id", "name", "geo.city", "tags"]);
        assert_eq!(t[2][3], "[\"a\",\"b\"]");
        let j = from_table(&t);
        assert_eq!(j, parse(&to_string(&j)).unwrap());
        if let Json::Arr(a) = j {
            assert_eq!(a[0].get("id").unwrap().as_f64(), Some(1.0));
        }
    }

    #[test]
    fn numbers_conservative() {
        assert!(as_number("007").is_none());
        assert!(as_number("+79001234567").is_none());
        assert!(as_number("1,5").is_none());
        assert!(as_number("42").is_some());
        assert!(as_number("-0.5").is_some());
    }
}
