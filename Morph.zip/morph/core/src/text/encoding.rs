//! Определение и декодирование кодировки текстовых файлов.
//! Поддержка: UTF-8 (с BOM и без), UTF-16 LE/BE (с BOM), Windows-1251, KOI8-R, Windows-1252.

use super::tables::{CP1251, CP1252, KOI8_R};

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Encoding {
    Utf8,
    Utf8Bom,
    Utf16Le,
    Utf16Be,
    Cp1251,
    Koi8R,
    Cp1252,
}

impl Encoding {
    pub fn name(self) -> &'static str {
        match self {
            Encoding::Utf8 => "UTF-8",
            Encoding::Utf8Bom => "UTF-8 (BOM)",
            Encoding::Utf16Le => "UTF-16 LE",
            Encoding::Utf16Be => "UTF-16 BE",
            Encoding::Cp1251 => "Windows-1251",
            Encoding::Koi8R => "KOI8-R",
            Encoding::Cp1252 => "Windows-1252",
        }
    }
}

/// Определяет кодировку по содержимому.
pub fn detect(bytes: &[u8]) -> Encoding {
    if bytes.starts_with(&[0xEF, 0xBB, 0xBF]) {
        return Encoding::Utf8Bom;
    }
    if bytes.starts_with(&[0xFF, 0xFE]) {
        return Encoding::Utf16Le;
    }
    if bytes.starts_with(&[0xFE, 0xFF]) {
        return Encoding::Utf16Be;
    }
    // UTF-16 без BOM: много нулевых байтов на чётных/нечётных позициях
    if bytes.len() >= 4 {
        let sample = &bytes[..bytes.len().min(4096)];
        let zeros_odd = sample.iter().skip(1).step_by(2).filter(|b| **b == 0).count();
        let zeros_even = sample.iter().step_by(2).filter(|b| **b == 0).count();
        let half = sample.len() / 2;
        if half > 0 && zeros_odd * 10 > half * 4 && zeros_even * 10 < half {
            return Encoding::Utf16Le;
        }
        if half > 0 && zeros_even * 10 > half * 4 && zeros_odd * 10 < half {
            return Encoding::Utf16Be;
        }
    }
    if is_utf8(bytes) {
        return Encoding::Utf8;
    }
    // Однобайтовая кодировка: кириллица или латиница?
    let high: Vec<u8> = bytes.iter().copied().filter(|b| *b >= 0x80).collect();
    if high.is_empty() {
        return Encoding::Utf8;
    }
    // Доля байтов, попадающих в кириллический диапазон 0xC0–0xFF
    let cyr = high.iter().filter(|b| **b >= 0xC0).count();
    if cyr * 10 >= high.len() * 6 {
        // В русском тексте строчные буквы встречаются намного чаще прописных.
        // CP1251: строчные 0xE0–0xFF. KOI8-R: строчные 0xC0–0xDF.
        let upper_half = high.iter().filter(|b| **b >= 0xE0).count();
        let lower_half = high.iter().filter(|b| (0xC0..0xE0).contains(*b)).count();
        if lower_half > upper_half * 2 {
            // похоже на KOI8-R, но проверим по частотным буквам
            if score_ru(&decode_table(bytes, &KOI8_R)) > score_ru(&decode_table(bytes, &CP1251)) {
                return Encoding::Koi8R;
            }
        }
        return Encoding::Cp1251;
    }
    Encoding::Cp1252
}

fn score_ru(s: &str) -> usize {
    // частые русские буквы
    s.chars().filter(|c| "оеаинтсрвл".contains(*c)).count()
}

pub fn is_utf8(bytes: &[u8]) -> bool {
    match std::str::from_utf8(bytes) {
        Ok(_) => true,
        // Файл мог быть обрезан посреди символа — допускаем неполную последовательность в конце
        Err(e) => e.error_len().is_none() && bytes.len() - e.valid_up_to() < 4,
    }
}

fn decode_table(bytes: &[u8], table: &[char; 128]) -> String {
    let mut s = String::with_capacity(bytes.len() * 2);
    for &b in bytes {
        if b < 0x80 {
            s.push(b as char);
        } else {
            s.push(table[(b - 0x80) as usize]);
        }
    }
    s
}

fn decode_utf16(bytes: &[u8], le: bool) -> String {
    let units: Vec<u16> = bytes
        .chunks_exact(2)
        .map(|c| if le { u16::from_le_bytes([c[0], c[1]]) } else { u16::from_be_bytes([c[0], c[1]]) })
        .collect();
    String::from_utf16_lossy(&units)
}

/// Декодирует байты в строку, возвращая и использованную кодировку.
pub fn decode(bytes: &[u8]) -> (String, Encoding) {
    let enc = detect(bytes);
    (decode_as(bytes, enc), enc)
}

pub fn decode_as(bytes: &[u8], enc: Encoding) -> String {
    match enc {
        Encoding::Utf8 => String::from_utf8_lossy(bytes).into_owned(),
        Encoding::Utf8Bom => String::from_utf8_lossy(&bytes[3..]).into_owned(),
        Encoding::Utf16Le => {
            let b = if bytes.starts_with(&[0xFF, 0xFE]) { &bytes[2..] } else { bytes };
            decode_utf16(b, true)
        }
        Encoding::Utf16Be => {
            let b = if bytes.starts_with(&[0xFE, 0xFF]) { &bytes[2..] } else { bytes };
            decode_utf16(b, false)
        }
        Encoding::Cp1251 => decode_table(bytes, &CP1251),
        Encoding::Koi8R => decode_table(bytes, &KOI8_R),
        Encoding::Cp1252 => decode_table(bytes, &CP1252),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn cp1251(s: &str) -> Vec<u8> {
        s.chars()
            .map(|c| {
                if (c as u32) < 0x80 {
                    c as u8
                } else {
                    (CP1251.iter().position(|x| *x == c).unwrap() as u8) + 0x80
                }
            })
            .collect()
    }

    #[test]
    fn detects_cp1251() {
        let b = cp1251("Имя;Город\nИван Петров;Екатеринбург\nОльга;Москва\n");
        assert_eq!(detect(&b), Encoding::Cp1251);
        assert!(decode(&b).0.contains("Екатеринбург"));
    }

    #[test]
    fn detects_koi8() {
        let s = "привет, это проверка кодировки koi8 для русского текста";
        let b: Vec<u8> = s
            .chars()
            .map(|c| if (c as u32) < 0x80 { c as u8 } else { (KOI8_R.iter().position(|x| *x == c).unwrap() as u8) + 0x80 })
            .collect();
        assert_eq!(detect(&b), Encoding::Koi8R);
        assert_eq!(decode(&b).0, s);
    }

    #[test]
    fn detects_utf8_and_bom() {
        assert_eq!(detect("Привет".as_bytes()), Encoding::Utf8);
        let mut b = vec![0xEF, 0xBB, 0xBF];
        b.extend_from_slice("Привет".as_bytes());
        assert_eq!(detect(&b), Encoding::Utf8Bom);
        assert_eq!(decode(&b).0, "Привет");
    }

    #[test]
    fn detects_utf16() {
        let mut b = vec![0xFF, 0xFE];
        for u in "a;б\n".encode_utf16() {
            b.extend_from_slice(&u.to_le_bytes());
        }
        assert_eq!(decode(&b).0, "a;б\n");
    }
}
