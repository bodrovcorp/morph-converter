//! Чтение/запись CSV с автоопределением разделителя (RFC 4180 + распространённые отклонения).

pub type Table = Vec<Vec<String>>;

/// Разбирает CSV с заданным разделителем.
pub fn parse(text: &str, delim: char) -> Table {
    let mut rows = Vec::new();
    let mut row: Vec<String> = Vec::new();
    let mut field = String::new();
    let mut in_quotes = false;
    let mut field_started = false;
    let mut chars = text.chars().peekable();
    while let Some(c) = chars.next() {
        if in_quotes {
            if c == '"' {
                if chars.peek() == Some(&'"') {
                    field.push('"');
                    chars.next();
                } else {
                    in_quotes = false;
                }
            } else {
                field.push(c);
            }
            continue;
        }
        if c == '"' && !field_started {
            in_quotes = true;
            field_started = true;
        } else if c == delim {
            row.push(std::mem::take(&mut field));
            field_started = false;
        } else if c == '\r' {
            if chars.peek() == Some(&'\n') {
                chars.next();
            }
            row.push(std::mem::take(&mut field));
            rows.push(std::mem::take(&mut row));
            field_started = false;
        } else if c == '\n' {
            row.push(std::mem::take(&mut field));
            rows.push(std::mem::take(&mut row));
            field_started = false;
        } else {
            field.push(c);
            field_started = true;
        }
    }
    if field_started || !field.is_empty() || !row.is_empty() {
        row.push(field);
        rows.push(row);
    }
    // убираем полностью пустые строки в конце
    while rows.last().map(|r| r.iter().all(|f| f.is_empty())).unwrap_or(false) {
        rows.pop();
    }
    rows
}

/// Определяет разделитель: выбираем тот, что даёт одинаковое (и > 1) число столбцов в первых строках.
pub fn sniff_delimiter(text: &str) -> char {
    let sample: String = text.lines().take(50).collect::<Vec<_>>().join("\n");
    let candidates = [';', ',', '\t', '|'];
    let mut best = (',', 0.0f64);
    for &d in &candidates {
        let rows = parse(&sample, d);
        if rows.is_empty() {
            continue;
        }
        let counts: Vec<usize> = rows.iter().map(|r| r.len()).collect();
        let first = counts[0];
        if first < 2 {
            continue;
        }
        let same = counts.iter().filter(|c| **c == first).count() as f64 / counts.len() as f64;
        // Больше столбцов и выше согласованность — лучше
        let score = same * 100.0 + (first as f64).min(50.0);
        if score > best.1 {
            best = (d, score);
        }
    }
    best.0
}

fn needs_quotes(f: &str, delim: char) -> bool {
    f.contains(delim) || f.contains('"') || f.contains('\n') || f.contains('\r') || f.starts_with(' ') || f.ends_with(' ')
}

/// Записывает таблицу в CSV (CRLF — так ожидает Excel).
pub fn write(table: &Table, delim: char) -> String {
    let mut out = String::new();
    for row in table {
        let line: Vec<String> = row
            .iter()
            .map(|f| if needs_quotes(f, delim) { format!("\"{}\"", f.replace('"', "\"\"")) } else { f.clone() })
            .collect();
        out.push_str(&line.join(&delim.to_string()));
        out.push_str("\r\n");
    }
    out
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parses_quotes_and_newlines() {
        let t = parse("a,b\n\"x, y\",\"он сказал \"\"да\"\"\"\n\"много\nстрок\",2\n", ',');
        assert_eq!(t.len(), 3);
        assert_eq!(t[1][0], "x, y");
        assert_eq!(t[1][1], "он сказал \"да\"");
        assert_eq!(t[2][0], "много\nстрок");
    }

    #[test]
    fn sniffs() {
        assert_eq!(sniff_delimiter("имя;сумма\nИван;1,5\nОля;2,25\n"), ';');
        assert_eq!(sniff_delimiter("a,b,c\n1,2,3\n"), ',');
        assert_eq!(sniff_delimiter("a\tb\n1\t2\n"), '\t');
        assert_eq!(sniff_delimiter("a|b\n1|2\n"), '|');
    }

    #[test]
    fn roundtrip() {
        let t = vec![vec!["a;b".to_string(), "c\"d".to_string()], vec!["".to_string(), "ж".to_string()]];
        assert_eq!(parse(&write(&t, ';'), ';'), t);
    }
}
