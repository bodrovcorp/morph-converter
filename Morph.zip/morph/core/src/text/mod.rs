//! Работа с текстом: кодировки, CSV, JSON.
pub mod csv;
pub mod encoding;
pub mod json;
mod tables;
