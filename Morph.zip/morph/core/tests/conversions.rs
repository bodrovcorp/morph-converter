//! Матрица конвертаций: каждый образец × каждая цель, для которой есть движок.
//! Проверяется, что результат существует, не пустой, открывается своим инструментом
//! и (для текстовых форматов) сохраняет русский текст.
//!
//! Итоговый отчёт пишется в docs/TEST_REPORT.md.

mod common;
use common::*;
use morph_core::formats::detect;
use morph_core::queue::Status;
use morph_core::registry::Registry;
use std::collections::BTreeMap;
use std::fmt::Write as _;
use std::path::PathBuf;
use std::time::{Duration, Instant};

#[test]
fn conversion_matrix() {
    let Some(fx) = fixtures() else { return };
    let only = std::env::var("MORPH_ONLY").ok(); // например MORPH_ONLY=docx,pdf
    let r = runner(3);
    let reg = Registry::new();
    let out_root = scratch("matrix");
    let started = Instant::now();

    let mut inputs: Vec<PathBuf> = std::fs::read_dir(&fx).unwrap().flatten().map(|e| e.path()).collect();
    inputs.sort();
    // (формат, цель) → id задачи
    let mut planned = Vec::new();
    let mut skipped = Vec::new();
    for inp in &inputs {
        let f = detect(inp).expect("формат образца не определился");
        if let Some(o) = &only {
            if !o.split(',').any(|x| x == f.id) {
                continue;
            }
        }
        for offer in reg.offers_for(f, &r.q.engines()) {
            if !offer.missing.is_empty() {
                skipped.push((f.id, offer.id.clone(), offer.missing.iter().map(|e| e.title()).collect::<Vec<_>>().join(", ")));
                continue;
            }
            let out = out_root.join(f.id).join(&offer.id);
            std::fs::create_dir_all(&out).unwrap();
            let batch = r.q.submit(req(vec![inp.clone()], &offer.id, &out));
            planned.push((f.id, offer.id.clone(), offer.title.clone(), batch));
        }
    }
    assert!(r.q.wait_idle(Duration::from_secs(3600)), "очередь не завершилась за час");
    let snap = r.q.snapshot();

    let mut ok = 0;
    let mut failures = Vec::new();
    let mut by_src: BTreeMap<&str, Vec<String>> = BTreeMap::new();
    for (src, target, title, batch) in &planned {
        let job = snap.iter().find(|j| j.batch == *batch).unwrap();
        let cell = if job.status == Status::Done {
            let p = &job.outputs[0];
            match validate(p, source_has_text(src) && !matches!(target.as_str(), "zip" | "7z" | "targz")) {
                Ok(desc) => {
                    ok += 1;
                    format!("✓ {title} — {desc}, {:.1} с", job.elapsed_secs)
                }
                Err(e) => {
                    failures.push(format!("{src} → {target}: результат не прошёл проверку: {e} ({})", p.display()));
                    format!("✗ {title} — {e}")
                }
            }
        } else {
            let msg = job.error.clone().unwrap_or_default();
            failures.push(format!("{src} → {target}: {msg}\n{}", job.details.lines().rev().take(6).collect::<Vec<_>>().join("\n")));
            format!("✗ {title} — {msg}")
        };
        by_src.entry(src).or_default().push(cell);
    }

    let mut report = String::new();
    let _ = writeln!(report, "# Отчёт автотестов конвертаций\n");
    let _ = writeln!(
        report,
        "Сгенерировано тестом `core/tests/conversions.rs` на Linux с настоящими движками. Всего проверено: **{}**, успешно: **{ok}**, ошибок: **{}**, пропущено из‑за отсутствия движка: **{}**. Время: {:.0} с.\n",
        planned.len(),
        failures.len(),
        skipped.len(),
        started.elapsed().as_secs_f64()
    );
    let _ = writeln!(report, "Каждый результат открыт своим инструментом (ImageMagick, ffprobe, qpdf/pdfinfo, unzip, tar, JSON/CSV-парсер). Для документов, таблиц и книг дополнительно проверено, что русский текст сохранился без искажений.\n");
    for (src, cells) in &by_src {
        let _ = writeln!(report, "## {}\n", src.to_uppercase());
        for c in cells {
            let _ = writeln!(report, "- {c}");
        }
        let _ = writeln!(report);
    }
    if !skipped.is_empty() {
        let _ = writeln!(report, "## Пропущено: нет движка на тестовой машине\n");
        for (s, t, m) in &skipped {
            let _ = writeln!(report, "- {s} → {t}: нужен {m}");
        }
    }
    let path = std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("../docs/TEST_REPORT.md");
    if only.is_none() {
        std::fs::write(&path, report).unwrap();
    }
    for f in &failures {
        eprintln!("FAIL {f}\n");
    }
    eprintln!("Итого: {ok}/{} успешно, пропущено {}", planned.len(), skipped.len());
    assert!(failures.is_empty(), "{} конвертаций не прошли", failures.len());
}
