//! Общие помощники автотестов: поиск образцов, запуск очереди, проверка, что результат открывается.
#![allow(dead_code)]

use morph_core::engines::{EngineConfig, Engines};
use morph_core::formats::split_name;
use morph_core::naming::Conflict;
use morph_core::options::Options;
use morph_core::queue::{Dest, JobInfo, JobRequest, Queue};
use std::path::{Path, PathBuf};
use std::process::Command;
use std::sync::{Arc, Mutex};
use std::time::Duration;

pub fn fixtures() -> Option<PathBuf> {
    let p = std::env::var_os("MORPH_FIXTURES").map(PathBuf::from).unwrap_or_else(|| {
        Path::new(env!("CARGO_MANIFEST_DIR")).join("../tests/fixtures/out/образцы с пробелами")
    });
    if p.is_dir() {
        Some(p)
    } else {
        eprintln!("Образцов нет ({}). Запустите: python3 tests/make_fixtures.py", p.display());
        None
    }
}

pub fn scratch(name: &str) -> PathBuf {
    let d = std::env::temp_dir().join("morph-tests").join(name);
    let _ = std::fs::remove_dir_all(&d);
    std::fs::create_dir_all(&d).unwrap();
    d
}

pub fn engines() -> Arc<Engines> {
    Arc::new(Engines::discover(&EngineConfig::default()))
}

pub struct Runner {
    pub q: Queue,
    pub events: Arc<Mutex<Vec<JobInfo>>>,
}

pub fn runner(workers: usize) -> Runner {
    let events = Arc::new(Mutex::new(Vec::new()));
    let ev2 = events.clone();
    let q = Queue::new(engines(), workers, Arc::new(move |j: &JobInfo| ev2.lock().unwrap().push(j.clone())));
    Runner { q, events }
}

pub fn req(inputs: Vec<PathBuf>, target: &str, out: &Path) -> JobRequest {
    JobRequest { inputs, target: target.into(), options: Options::default(), dest: Dest::Folder(out.to_path_buf()), conflict: Conflict::Suffix }
}

/// Запускает одну задачу и ждёт результат
pub fn convert_one(r: &Runner, r_: JobRequest) -> Vec<JobInfo> {
    let batch = r.q.submit(r_);
    assert!(r.q.wait_idle(Duration::from_secs(900)), "задача зависла");
    r.q.snapshot().into_iter().filter(|j| j.batch == batch).collect()
}

fn run(cmd: &str, args: &[&str]) -> Result<String, String> {
    let out = Command::new(cmd).args(args).output().map_err(|e| format!("{cmd}: {e}"))?;
    if !out.status.success() {
        return Err(format!("{cmd} {:?}: {}", args, String::from_utf8_lossy(&out.stderr).lines().last().unwrap_or("")));
    }
    Ok(format!("{}{}", String::from_utf8_lossy(&out.stdout), String::from_utf8_lossy(&out.stderr)))
}

const MARKERS: &[&str] = &["Екатеринбург", "Привет", "Москва", "Морф", "Слайд", "Заголовок", "Город", "Всего", "архива", "Пример"];

pub fn has_cyrillic_marker(s: &str) -> bool {
    MARKERS.iter().any(|m| s.contains(m))
}

/// Проверяет, что файл (или папка) — корректный непустой результат. Возвращает краткое описание.
/// `expect_text` — исходник содержал русский текст, и он должен сохраниться без «кракозябр».
pub fn validate(p: &Path, expect_text: bool) -> Result<String, String> {
    let meta = std::fs::metadata(p).map_err(|e| format!("нет результата: {e}"))?;
    if meta.is_dir() {
        let mut files: Vec<PathBuf> = walk(p);
        files.sort();
        if files.is_empty() {
            return Err("пустая папка".into());
        }
        let mut seen_text = !expect_text;
        for f in &files {
            let ext = split_name(&f.file_name().unwrap().to_string_lossy()).1;
            // в распакованных архивах — произвольные файлы: проверяем только размер
            if matches!(ext.as_str(), "png" | "jpg" | "pdf" | "csv") {
                validate(f, false)?;
            }
            if expect_text && std::fs::read_to_string(f).map(|s| has_cyrillic_marker(&s)).unwrap_or(false) {
                seen_text = true;
            }
        }
        if expect_text && !seen_text {
            // для страниц-картинок текст не проверяем
            let any_img = files.iter().any(|f| matches!(split_name(&f.to_string_lossy()).1.as_str(), "png" | "jpg" | "pdf"));
            if !any_img {
                return Err("в результате нет исходного русского текста".into());
            }
        }
        return Ok(format!("папка, {} файл(ов)", files.len()));
    }
    if meta.len() == 0 {
        return Err("пустой файл".into());
    }
    let s = p.to_string_lossy().to_string();
    let ext = split_name(&p.file_name().unwrap().to_string_lossy()).1;
    let text_ok = |t: &str| -> Result<(), String> {
        if expect_text && !has_cyrillic_marker(t) {
            Err(format!("русский текст потерян или искажён: «{}»", t.chars().take(80).collect::<String>().replace('\n', " ")))
        } else {
            Ok(())
        }
    };
    let zip_list = |s: &str| run("unzip", &["-l", s]);
    let zip_part = |s: &str, part: &str| run("unzip", &["-p", s, part]);
    match ext.as_str() {
        "jpg" | "png" | "webp" | "gif" | "bmp" | "tiff" | "ico" | "avif" | "tga" | "psd" | "heic" => {
            let m = if which("magick") { "magick" } else { "convert" };
            let info = run(m, &[&format!("{s}[0]"), "-format", "%wx%h", "info:"])?;
            if !info.contains('x') || info.starts_with("0x") {
                return Err(format!("странный размер: {info}"));
            }
            Ok(format!("{} {}", ext, info.trim()))
        }
        "mp4" | "mov" | "mkv" | "avi" | "webm" | "wmv" | "flv" | "mpg" | "3gp" | "ts" | "mp3" | "wav" | "flac" | "m4a" | "aac" | "ogg" | "opus" | "wma" | "aiff" => {
            let d = run("ffprobe", &["-v", "error", "-show_entries", "format=duration", "-of", "default=nw=1:nk=1", &s])?;
            let secs: f64 = d.trim().lines().next().unwrap_or("0").parse().unwrap_or(0.0);
            if secs <= 0.1 {
                return Err(format!("длительность {secs}"));
            }
            Ok(format!("{ext} {secs:.1} с"))
        }
        "pdf" => {
            run("qpdf", &["--check", &s])?;
            let info = run("pdfinfo", &[&s])?;
            let pages = info.lines().find(|l| l.starts_with("Pages:")).unwrap_or("Pages: 0").split_whitespace().last().unwrap_or("0").to_string();
            if pages == "0" {
                return Err("0 страниц".into());
            }
            if expect_text {
                let t = run("pdftotext", &["-enc", "UTF-8", &s, "-"])?;
                text_ok(&t)?;
            }
            Ok(format!("PDF, {pages} стр."))
        }
        "docx" => {
            let l = zip_list(&s)?;
            if !l.contains("word/document.xml") {
                return Err("нет word/document.xml".into());
            }
            if expect_text {
                text_ok(&zip_part(&s, "word/document.xml")?)?;
            }
            Ok("DOCX".into())
        }
        "xlsx" => {
            let l = zip_list(&s)?;
            if !l.contains("xl/workbook.xml") {
                return Err("нет xl/workbook.xml".into());
            }
            if expect_text {
                let shared = zip_part(&s, "xl/sharedStrings.xml").unwrap_or_default();
                let sheet = zip_part(&s, "xl/worksheets/sheet1.xml").unwrap_or_default();
                text_ok(&format!("{shared}{sheet}"))?;
            }
            Ok("XLSX".into())
        }
        "pptx" => {
            let l = zip_list(&s)?;
            if !l.contains("ppt/presentation.xml") {
                return Err("нет ppt/presentation.xml".into());
            }
            Ok("PPTX".into())
        }
        "odt" | "ods" | "odp" => {
            let c = zip_part(&s, "content.xml")?;
            if expect_text {
                text_ok(&c)?;
            }
            Ok(ext.to_uppercase())
        }
        "epub" => {
            let l = zip_list(&s)?;
            if !l.contains("META-INF/container.xml") {
                return Err("нет container.xml".into());
            }
            if expect_text {
                let all = run("unzip", &["-p", &s])?;
                text_ok(&all)?;
            }
            Ok("EPUB".into())
        }
        "doc" | "xls" | "ppt" => {
            let b = std::fs::read(p).unwrap();
            if !b.starts_with(&[0xD0, 0xCF, 0x11, 0xE0]) {
                return Err("не OLE-файл".into());
            }
            Ok(ext.to_uppercase())
        }
        "rtf" => {
            let b = std::fs::read(p).unwrap();
            if !b.starts_with(b"{\\rtf") {
                return Err("не RTF".into());
            }
            Ok("RTF".into())
        }
        "txt" | "md" | "csv" | "tsv" | "html" | "json" | "fb2" => {
            let b = std::fs::read(p).unwrap();
            let t = String::from_utf8(b.strip_prefix(&[0xEF, 0xBB, 0xBF]).unwrap_or(&b).to_vec()).map_err(|_| "не UTF-8".to_string())?;
            if t.trim().is_empty() {
                return Err("пустой текст".into());
            }
            match ext.as_str() {
                "json" => {
                    morph_core::text::json::parse(&t).map_err(|e| format!("JSON не разбирается: {}", e.msg))?;
                }
                "html" if !t.to_lowercase().contains("<html") => return Err("не HTML".into()),
                "fb2" if !t.contains("<FictionBook") => return Err("не FB2".into()),
                "csv" | "tsv" => {
                    let d = if ext == "tsv" { '\t' } else { morph_core::text::csv::sniff_delimiter(&t) };
                    if morph_core::text::csv::parse(&t, d).is_empty() {
                        return Err("CSV без строк".into());
                    }
                }
                _ => {}
            }
            text_ok(&t)?;
            Ok(format!("{} {} симв.", ext.to_uppercase(), t.chars().count()))
        }
        "zip" => {
            run("unzip", &["-t", &s])?;
            Ok("ZIP".into())
        }
        "tar.gz" | "tar" | "tar.bz2" | "tar.xz" => {
            run("tar", &["-tf", &s])?;
            Ok(ext.to_uppercase())
        }
        "7z" => Ok("7Z (не проверен — нет 7-Zip)".into()),
        other => Err(format!("нет проверки для .{other}")),
    }
}

pub fn which(t: &str) -> bool {
    std::env::var_os("PATH").map(|p| std::env::split_paths(&p).any(|d| d.join(t).is_file())).unwrap_or(false)
}

pub fn walk(p: &Path) -> Vec<PathBuf> {
    let mut v = Vec::new();
    if let Ok(rd) = std::fs::read_dir(p) {
        for e in rd.flatten() {
            let path = e.path();
            if path.is_dir() {
                v.extend(walk(&path));
            } else {
                v.push(path);
            }
        }
    }
    v
}

/// Исходники, в которых есть русский текст — его наличие проверяем в результате
pub fn source_has_text(fmt: &str) -> bool {
    matches!(fmt, "docx" | "doc" | "odt" | "rtf" | "txt" | "md" | "html" | "pdf" | "epub" | "fb2" | "csv" | "tsv" | "json" | "xlsx" | "xls" | "ods" | "pptx" | "ppt" | "odp")
}
