//! Крайние случаи: кириллица/пробелы/скобки в путях, совпадение имён, повреждённые и пустые файлы,
//! нет прав на запись, пакет из 25+ файлов, отмена посреди конвертации, большие файлы,
//! отсутствующий движок, объединение файлов.

mod common;
use common::*;
use morph_core::engines::{EngineConfig, Engines};
use morph_core::naming::Conflict;
use morph_core::options::Options;
use morph_core::queue::{Dest, JobInfo, JobRequest, Queue, Status};
use std::fs;
use std::path::{Path, PathBuf};
use std::process::Command;
use std::sync::{Arc, Mutex};
use std::time::{Duration, Instant};

fn fx(name: &str) -> Option<PathBuf> {
    fixtures().map(|d| d.join(name))
}

fn files_in(d: &Path) -> Vec<String> {
    let mut v: Vec<String> = fs::read_dir(d).unwrap().flatten().map(|e| e.file_name().to_string_lossy().to_string()).collect();
    v.sort();
    v
}

#[test]
fn cyrillic_spaces_and_brackets_in_path() {
    let Some(src) = fx("Пример файла.png") else { return };
    let dir = scratch("пути").join("Папка с пробелами [и скобками]");
    fs::create_dir_all(&dir).unwrap();
    let input = dir.join("Отчёт [финал] (копия) №2 — итог.png");
    fs::copy(&src, &input).unwrap();
    let r = runner(2);
    for target in ["jpg", "webp", "pdf", "zip"] {
        let jobs = convert_one(&r, JobRequest { dest: Dest::Beside, ..req(vec![input.clone()], target, &dir) });
        assert_eq!(jobs[0].status, Status::Done, "{target}: {:?}", jobs[0].error);
        let out = &jobs[0].outputs[0];
        assert_eq!(out.file_stem().unwrap().to_string_lossy().trim_end_matches(".tar"), "Отчёт [финал] (копия) №2 — итог");
        validate(out, false).unwrap();
    }
}

#[test]
fn name_conflicts_suffix_and_overwrite() {
    let Some(src) = fx("Пример файла.png") else { return };
    let dir = scratch("конфликты");
    let input = dir.join("фото.png");
    fs::copy(&src, &input).unwrap();
    let r = runner(2);
    // Два раза подряд → «фото.jpg» и «фото (1).jpg»
    for _ in 0..2 {
        convert_one(&r, req(vec![input.clone()], "jpg", &dir));
    }
    assert_eq!(files_in(&dir), vec!["фото (1).jpg", "фото.jpg", "фото.png"]);
    // Перезапись: файлов не прибавляется, содержимое обновлено
    let before = fs::metadata(dir.join("фото.jpg")).unwrap().modified().unwrap();
    std::thread::sleep(Duration::from_millis(1100));
    let jobs = convert_one(&r, JobRequest { conflict: Conflict::Overwrite, ..req(vec![input.clone()], "jpg", &dir) });
    assert_eq!(jobs[0].status, Status::Done);
    assert_eq!(files_in(&dir).len(), 3);
    assert!(fs::metadata(dir.join("фото.jpg")).unwrap().modified().unwrap() > before);
    // Одновременно два разных файла с одинаковой основой → разные имена, ничего не затёрто
    let input2 = dir.join("фото.bmp");
    fs::copy(fx("Пример файла.bmp").unwrap(), &input2).unwrap();
    let out2 = dir.join("вместе");
    fs::create_dir_all(&out2).unwrap();
    r.q.submit(req(vec![input.clone()], "webp", &out2));
    r.q.submit(req(vec![input2.clone()], "webp", &out2));
    r.q.wait_idle(Duration::from_secs(120));
    assert_eq!(files_in(&out2), vec!["фото (1).webp", "фото.webp"]);
}

#[test]
fn corrupted_and_empty_files_give_clear_errors() {
    let Some(jpg) = fx("Пример файла.jpg") else { return };
    let dir = scratch("повреждённые");
    let out = dir.join("результат");
    fs::create_dir_all(&out).unwrap();
    let full = fs::read(&jpg).unwrap();
    let cases: Vec<(&str, Vec<u8>, &str)> = vec![
        ("обрезанное фото.jpg", full[..600].to_vec(), "png"),
        ("мусор.mp4", (0..200_000u32).map(|i| (i.wrapping_mul(2654435761) >> 13) as u8).collect(), "mp3"),
        ("не pdf.pdf", b"%PDF-1.7\n1 0 obj << /Type /Catalog >> broken".to_vec(), "png_pages"),
        ("битый.docx", b"PK\x03\x04word/document.xml garbage garbage".to_vec(), "pdf"),
        ("кривой.json", "[{\"а\": 1,,}]".as_bytes().to_vec(), "csv"),
        ("пустой.png", vec![], "jpg"),
        ("архив.zip", b"PK\x03\x04 not really a zip".to_vec(), "unpack"),
    ];
    let r = runner(3);
    for (name, bytes, target) in &cases {
        let p = dir.join(name);
        fs::write(&p, bytes).unwrap();
        let jobs = convert_one(&r, req(vec![p.clone()], target, &out));
        let j = &jobs[0];
        assert_eq!(j.status, Status::Failed, "{name} должен был не сконвертироваться");
        let msg = j.error.clone().unwrap();
        eprintln!("{name}: {msg}");
        assert!(!msg.contains("panicked") && !msg.contains("RUST_BACKTRACE"), "трейсбек в сообщении: {msg}");
        assert!(msg.chars().any(|c| ('а'..='я').contains(&c)), "сообщение не по-русски: {msg}");
    }
    assert!(files_in(&out).is_empty(), "после ошибок в папке остались файлы: {:?}", files_in(&out));
}

#[test]
fn no_write_permission() {
    let Some(png) = fx("Пример файла.png") else { return };
    let dir = scratch("права");
    let input = dir.join("снимок.png");
    fs::copy(&png, &input).unwrap();
    let ro = dir.join("только чтение");
    fs::create_dir_all(&ro).unwrap();
    let is_root = Command::new("id").arg("-u").output().map(|o| String::from_utf8_lossy(&o.stdout).trim() == "0").unwrap_or(false);
    // root игнорирует права — запускаем CLI от имени nobody
    let cli = PathBuf::from(env!("CARGO_BIN_EXE_morph-cli"));
    let local_cli = dir.join("morph-cli");
    fs::copy(&cli, &local_cli).unwrap();
    for p in [&dir, &ro] {
        Command::new("chmod").arg(if p == &ro { "555" } else { "755" }).arg(p).status().unwrap();
    }
    Command::new("chmod").args(["-R", "a+rX"]).arg(std::env::temp_dir().join("morph-tests")).status().unwrap();
    Command::new("chmod").arg("555").arg(&ro).status().unwrap();
    let mut cmd = if is_root && which("setpriv") {
        let mut c = Command::new("setpriv");
        c.args(["--reuid=65534", "--regid=65534", "--clear-groups"]).arg(&local_cli);
        c
    } else {
        Command::new(&local_cli)
    };
    let out = cmd.args(["convert", "--to", "jpg", "--out-dir"]).arg(&ro).arg(&input).env("HOME", "/tmp").output().unwrap();
    let text = String::from_utf8_lossy(&out.stdout);
    eprintln!("{}", text.lines().last().unwrap_or(""));
    assert!(!out.status.success());
    assert!(text.contains("Нет прав на запись"), "ожидалось понятное сообщение о правах: {text}");
    assert!(files_in(&ro).is_empty());
}

#[test]
fn batch_of_26_files_with_name_collision() {
    let Some(png) = fx("Пример файла.png") else { return };
    let dir = scratch("пакет");
    let out = dir.join("готово");
    fs::create_dir_all(&out).unwrap();
    let mut inputs = Vec::new();
    for i in 1..=25 {
        let p = dir.join(format!("кадр {i:02}.png"));
        fs::copy(&png, &p).unwrap();
        inputs.push(p);
    }
    let bmp = dir.join("кадр 01.bmp");
    fs::copy(fx("Пример файла.bmp").unwrap(), &bmp).unwrap();
    inputs.push(bmp);
    let r = runner(3);
    let t = Instant::now();
    let jobs = convert_one(&r, req(inputs, "jpg", &out));
    assert_eq!(jobs.len(), 26);
    assert!(jobs.iter().all(|j| j.status == Status::Done), "{:?}", jobs.iter().filter_map(|j| j.error.clone()).collect::<Vec<_>>());
    let names = files_in(&out);
    assert_eq!(names.len(), 26);
    assert!(names.contains(&"кадр 01 (1).jpg".to_string()));
    for n in &names {
        validate(&out.join(n), false).unwrap();
    }
    eprintln!("26 файлов за {:.1} с", t.elapsed().as_secs_f64());
}

#[test]
fn cancel_in_the_middle() {
    let dir = scratch("отмена");
    let video = dir.join("длинное видео.mp4");
    // 40 секунд 1080p — в VP9 это кодируется долго, есть время отменить
    let st = Command::new("ffmpeg")
        .args(["-y", "-loglevel", "error", "-f", "lavfi", "-i", "testsrc2=size=1920x1080:rate=30:duration=40", "-c:v", "libx264", "-preset", "ultrafast"])
        .arg(&video)
        .status()
        .unwrap();
    assert!(st.success());
    let out = dir.join("результат");
    fs::create_dir_all(&out).unwrap();
    let r = runner(2);
    let batch = r.q.submit(req(vec![video.clone()], "webm", &out));
    // ждём реального старта и первых процентов
    let t = Instant::now();
    loop {
        let s = r.q.snapshot();
        if s.iter().any(|j| j.batch == batch && j.status == Status::Running && j.progress > 0.0) || t.elapsed() > Duration::from_secs(30) {
            break;
        }
        std::thread::sleep(Duration::from_millis(100));
    }
    std::thread::sleep(Duration::from_millis(800));
    let t_cancel = Instant::now();
    r.q.cancel(batch);
    assert!(r.q.wait_idle(Duration::from_secs(10)), "отмена не сработала за 10 с");
    let j = r.q.snapshot().into_iter().find(|j| j.batch == batch).unwrap();
    eprintln!("отменено через {:.2} с после нажатия, прогресс был {:.0}%", t_cancel.elapsed().as_secs_f64(), j.progress * 100.0);
    assert_eq!(j.status, Status::Cancelled);
    assert!(t_cancel.elapsed() < Duration::from_secs(3));
    assert!(files_in(&out).is_empty(), "после отмены остались файлы: {:?}", files_in(&out));
    let work = morph_core::queue::work_root().join(j.id.to_string());
    assert!(!work.exists(), "временная папка не удалена");
}

#[test]
fn large_files_with_progress_and_eta() {
    let dir = scratch("большие");
    // 1) 25 минут звука (~260 МБ WAV) → MP3: прогресс растёт, есть оценка оставшегося времени
    let wav = dir.join("долгая запись.wav");
    let st = Command::new("ffmpeg").args(["-y", "-loglevel", "error", "-f", "lavfi", "-i", "sine=frequency=220:duration=1500:sample_rate=44100", "-ac", "2"]).arg(&wav).status().unwrap();
    assert!(st.success());
    eprintln!("WAV: {} МБ", fs::metadata(&wav).unwrap().len() / 1_000_000);
    let events: Arc<Mutex<Vec<JobInfo>>> = Arc::new(Mutex::new(Vec::new()));
    let ev = events.clone();
    let q = Queue::new(engines(), 1, Arc::new(move |j: &JobInfo| ev.lock().unwrap().push(j.clone())));
    q.submit(JobRequest { inputs: vec![wav.clone()], target: "mp3".into(), options: Options::default(), dest: Dest::Beside, conflict: Conflict::Suffix });
    assert!(q.wait_idle(Duration::from_secs(600)));
    let ev = events.lock().unwrap();
    let last = ev.last().unwrap();
    assert_eq!(last.status, Status::Done, "{:?}", last.error);
    let progress: Vec<f64> = ev.iter().filter(|j| j.status == Status::Running).map(|j| j.progress).collect();
    assert!(progress.len() >= 5, "слишком мало событий прогресса: {}", progress.len());
    assert!(progress.windows(2).all(|w| w[1] >= w[0]), "прогресс не монотонный");
    assert!(ev.iter().any(|j| j.eta_secs.is_some()), "нет оценки оставшегося времени");
    validate(&last.outputs[0], false).unwrap();
    eprintln!("MP3 готов за {:.1} с, событий прогресса: {}", last.elapsed_secs, progress.len());

    // 2) Файл 1,2 ГБ → ZIP (потоковая упаковка, без загрузки в память)
    let big = dir.join("образ диска.bin");
    let f = fs::File::create(&big).unwrap();
    f.set_len(1_200_000_000).unwrap();
    drop(f);
    let r = runner(1);
    let jobs = convert_one(&r, JobRequest { dest: Dest::Beside, ..req(vec![big.clone()], "zip", &dir) });
    assert_eq!(jobs[0].status, Status::Done, "{:?}", jobs[0].error);
    validate(&jobs[0].outputs[0], false).unwrap();
    eprintln!("1,2 ГБ → ZIP {} КБ за {:.1} с", fs::metadata(&jobs[0].outputs[0]).unwrap().len() / 1024, jobs[0].elapsed_secs);
    let _ = fs::remove_file(&big);
}

#[test]
fn missing_engine_is_explained() {
    let Some(docx) = fx("Пример файла.docx") else { return };
    let out = scratch("нет движка");
    // Никаких движков: ни PATH, ни встроенных
    let e = Arc::new(Engines::discover(&EngineConfig { no_path: true, ..Default::default() }));
    if e.has(morph_core::engines::EngineId::Soffice) {
        return; // LibreOffice установлен в стандартную папку — проверить «отсутствие» нельзя
    }
    let menu = morph_core::menu_json(&[docx.clone()], &e);
    let txt = morph_core::text::json::to_string(&menu);
    assert!(txt.contains("\"missing\":[\"libreoffice\"]"), "пункт должен быть помечен «нужен LibreOffice»");
    let q = Queue::new(e, 1, Arc::new(|_: &JobInfo| {}));
    q.submit(req(vec![docx], "pdf", &out));
    q.wait_idle(Duration::from_secs(30));
    let j = &q.snapshot()[0];
    assert_eq!(j.status, Status::Failed);
    assert!(j.error.as_ref().unwrap().contains("Не установлен компонент «LibreOffice»"), "{:?}", j.error);
}

#[test]
fn combine_many_into_one() {
    let Some(pdf) = fx("Пример файла.pdf") else { return };
    let dir = scratch("объединение");
    let mut pdfs = Vec::new();
    for n in ["глава 1.pdf", "глава 2.pdf", "глава 3.pdf"] {
        let p = dir.join(n);
        fs::copy(&pdf, &p).unwrap();
        pdfs.push(p);
    }
    let r = runner(2);
    let jobs = convert_one(&r, JobRequest { dest: Dest::Beside, ..req(pdfs.clone(), "merge_pdf", &dir) });
    assert_eq!(jobs.len(), 1);
    assert_eq!(jobs[0].status, Status::Done, "{:?}", jobs[0].error);
    let out = &jobs[0].outputs[0];
    assert_eq!(out.file_name().unwrap(), "глава 1 + ещё 2.pdf");
    let info = Command::new("pdfinfo").arg(out).output().unwrap();
    assert!(String::from_utf8_lossy(&info.stdout).contains("Pages:           6"), "ожидалось 2×3 = 6 страниц");

    let imgs: Vec<PathBuf> = ["Пример файла.jpg", "Пример файла.png", "Пример файла.webp"].iter().map(|n| fx(n).unwrap()).collect();
    let jobs = convert_one(&r, req(imgs.clone(), "pdf_images", &dir));
    assert_eq!(jobs[0].status, Status::Done, "{:?}", jobs[0].error);
    let info = Command::new("pdfinfo").arg(&jobs[0].outputs[0]).output().unwrap();
    assert!(String::from_utf8_lossy(&info.stdout).contains("Pages:           3"));

    let jobs = convert_one(&r, req(imgs, "zip_all", &dir));
    assert_eq!(jobs[0].status, Status::Done, "{:?}", jobs[0].error);
    let l = Command::new("unzip").arg("-l").arg(&jobs[0].outputs[0]).output().unwrap();
    assert!(String::from_utf8_lossy(&l.stdout).contains("3 files"));
}

#[test]
fn unpack_puts_single_folder_directly() {
    let dir = scratch("распаковка");
    let tree = dir.join("Проект");
    fs::create_dir_all(tree.join("вложенная")).unwrap();
    fs::write(tree.join("вложенная/файл.txt"), "привет").unwrap();
    let r = runner(1);
    // папка → zip → распаковать: получаем «Проект (1)» (имя занято исходной папкой)
    let jobs = convert_one(&r, JobRequest { dest: Dest::Beside, ..req(vec![tree.clone()], "zip", &dir) });
    assert_eq!(jobs[0].status, Status::Done, "{:?}", jobs[0].error);
    let zip = jobs[0].outputs[0].clone();
    assert_eq!(zip.file_name().unwrap(), "Проект.zip");
    let jobs = convert_one(&r, JobRequest { dest: Dest::Beside, ..req(vec![zip], "unpack", &dir) });
    assert_eq!(jobs[0].status, Status::Done, "{:?}", jobs[0].error);
    let out = &jobs[0].outputs[0];
    assert_eq!(out.file_name().unwrap(), "Проект (1)");
    assert_eq!(fs::read_to_string(out.join("вложенная/файл.txt")).unwrap(), "привет");
}
