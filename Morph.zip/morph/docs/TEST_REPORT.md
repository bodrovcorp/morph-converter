# Отчёт автотестов конвертаций

Сгенерировано тестом `core/tests/conversions.rs` на Linux с настоящими движками. Всего проверено: **540**, успешно: **540**, ошибок: **0**, пропущено из‑за отсутствия движка: **72**. Время: 66 с.

Каждый результат открыт своим инструментом (ImageMagick, ffprobe, qpdf/pdfinfo, unzip, tar, JSON/CSV-парсер). Для документов, таблиц и книг дополнительно проверено, что русский текст сохранился без искажений.

## 3GP

- ✓ MP4 — mp4 3.0 с, 0.5 с
- ✓ Сжать видео — mp4 3.0 с, 0.3 с
- ✓ GIF — gif 352x288, 0.4 с
- ✓ MP3 (звук) — mp3 3.1 с, 0.2 с
- ✓ WEBM — webm 3.0 с, 0.6 с
- ✓ MOV — mov 3.0 с, 0.2 с
- ✓ MKV — mkv 3.1 с, 0.4 с
- ✓ AVI — avi 3.1 с, 0.2 с
- ✓ M4A (звук) — m4a 3.0 с, 0.2 с
- ✓ WAV (звук) — wav 3.0 с, 0.2 с
- ✓ FLAC (звук) — flac 3.0 с, 0.2 с
- ✓ OGG (звук) — ogg 3.0 с, 0.1 с
- ✓ OPUS (звук) — opus 3.0 с, 0.1 с
- ✓ ZIP-архив — ZIP, 0.1 с
- ✓ TAR.GZ-архив — TAR.GZ, 0.1 с

## AAC

- ✓ MP3 — mp3 4.1 с, 0.2 с
- ✓ M4A — m4a 4.0 с, 0.3 с
- ✓ WAV — wav 4.0 с, 0.2 с
- ✓ FLAC — flac 4.0 с, 0.2 с
- ✓ OGG — ogg 4.0 с, 0.2 с
- ✓ OPUS — opus 4.0 с, 0.2 с
- ✓ AIFF — aiff 4.0 с, 0.2 с
- ✓ WMA — wma 4.0 с, 0.1 с
- ✓ ZIP-архив — ZIP, 0.1 с
- ✓ TAR.GZ-архив — TAR.GZ, 0.1 с

## AIFF

- ✓ MP3 — mp3 4.0 с, 0.2 с
- ✓ M4A — m4a 4.0 с, 0.2 с
- ✓ WAV — wav 4.0 с, 0.2 с
- ✓ FLAC — flac 4.0 с, 0.1 с
- ✓ OGG — ogg 4.0 с, 0.2 с
- ✓ OPUS — opus 4.0 с, 0.2 с
- ✓ AAC — aac 4.1 с, 0.4 с
- ✓ WMA — wma 4.0 с, 0.2 с
- ✓ ZIP-архив — ZIP, 0.1 с
- ✓ TAR.GZ-архив — TAR.GZ, 0.1 с

## AVI

- ✓ MP4 — mp4 3.0 с, 1.4 с
- ✓ Сжать видео — mp4 3.0 с, 0.7 с
- ✓ GIF — gif 480x270, 0.7 с
- ✓ MP3 (звук) — mp3 3.1 с, 0.2 с
- ✓ WEBM — webm 3.0 с, 1.6 с
- ✓ MOV — mov 3.0 с, 1.3 с
- ✓ MKV — mkv 3.1 с, 1.4 с
- ✓ M4A (звук) — m4a 3.0 с, 0.5 с
- ✓ WAV (звук) — wav 3.0 с, 0.4 с
- ✓ FLAC (звук) — flac 3.0 с, 0.2 с
- ✓ OGG (звук) — ogg 3.0 с, 0.2 с
- ✓ OPUS (звук) — opus 3.0 с, 0.2 с
- ✓ ZIP-архив — ZIP, 0.1 с
- ✓ TAR.GZ-архив — TAR.GZ, 0.1 с

## AVIF

- ✓ JPG — jpg 640x420, 0.1 с
- ✓ PNG — png 640x420, 0.1 с
- ✓ WEBP — webp 640x420, 0.1 с
- ✓ PDF — PDF, 1 стр., 0.1 с
- ✓ TIFF — tiff 640x420, 0.1 с
- ✓ GIF — gif 640x420, 0.1 с
- ✓ BMP — bmp 640x420, 0.1 с
- ✓ ICO — ico 256x256, 0.1 с
- ✓ ZIP-архив — ZIP, 0.0 с
- ✓ TAR.GZ-архив — TAR.GZ, 0.1 с

## BMP

- ✓ JPG — jpg 640x420, 0.1 с
- ✓ PNG — png 640x420, 0.1 с
- ✓ WEBP — webp 640x420, 0.1 с
- ✓ AVIF — avif 640x420, 0.4 с
- ✓ PDF — PDF, 1 стр., 0.1 с
- ✓ TIFF — tiff 640x420, 0.1 с
- ✓ GIF — gif 640x420, 0.2 с
- ✓ ICO — ico 256x256, 0.1 с
- ✓ ZIP-архив — ZIP, 0.1 с
- ✓ TAR.GZ-архив — TAR.GZ, 0.1 с

## CSV

- ✓ XLSX — XLSX, 0.5 с
- ✓ JSON — JSON 254 симв., 0.0 с
- ✓ PDF — PDF, 1 стр., 0.7 с
- ✓ ODS — ODS, 0.9 с
- ✓ XLS — XLS, 0.6 с
- ✓ TSV — TSV 99 симв., 0.0 с
- ✓ HTML — HTML 2217 симв., 0.7 с
- ✓ ZIP-архив — ZIP, 0.1 с
- ✓ TAR.GZ-архив — TAR.GZ, 0.1 с

## DNG

- ✓ JPG — jpg 64x48, 0.1 с
- ✓ PNG — png 64x48, 0.1 с
- ✓ TIFF — tiff 64x48, 0.1 с
- ✓ WEBP — webp 64x48, 0.1 с
- ✓ AVIF — avif 64x48, 0.2 с
- ✓ PDF — PDF, 1 стр., 0.1 с
- ✓ GIF — gif 64x48, 0.1 с
- ✓ BMP — bmp 64x48, 0.1 с
- ✓ ICO — ico 256x256, 0.1 с
- ✓ ZIP-архив — ZIP, 0.1 с
- ✓ TAR.GZ-архив — TAR.GZ, 0.1 с

## DOC

- ✓ PDF — PDF, 2 стр., 0.2 с
- ✓ DOCX — DOCX, 0.5 с
- ✓ TXT — TXT 273 симв., 0.7 с
- ✓ ODT — ODT, 0.8 с
- ✓ RTF — RTF, 0.8 с
- ✓ HTML — HTML 6396 симв., 0.9 с
- ✓ MD — MD 377 симв., 0.9 с
- ✓ EPUB — EPUB, 1.6 с
- ✓ ZIP-архив — ZIP, 0.1 с
- ✓ TAR.GZ-архив — TAR.GZ, 0.1 с

## DOCX

- ✓ PDF — PDF, 2 стр., 0.4 с
- ✓ TXT — TXT 273 симв., 0.5 с
- ✓ ODT — ODT, 0.9 с
- ✓ RTF — RTF, 0.9 с
- ✓ DOC — DOC, 0.8 с
- ✓ HTML — HTML 1986 симв., 0.2 с
- ✓ MD — MD 352 симв., 0.1 с
- ✓ EPUB — EPUB, 0.1 с
- ✓ ZIP-архив — ZIP, 0.1 с
- ✓ TAR.GZ-архив — TAR.GZ, 0.1 с

## EPUB

- ✓ PDF — PDF, 1 стр., 0.6 с
- ✓ FB2 — FB2 1152 симв., 0.1 с
- ✓ DOCX — DOCX, 0.2 с
- ✓ TXT — TXT 379 симв., 0.1 с
- ✓ HTML — HTML 5055 симв., 0.2 с
- ✓ ZIP-архив — ZIP, 0.1 с
- ✓ TAR.GZ-архив — TAR.GZ, 0.1 с

## FB2

- ✓ EPUB — EPUB, 0.1 с
- ✓ PDF — PDF, 1 стр., 0.4 с
- ✓ DOCX — DOCX, 0.1 с
- ✓ TXT — TXT 421 симв., 0.1 с
- ✓ HTML — HTML 1836 симв., 0.1 с
- ✓ ZIP-архив — ZIP, 0.1 с
- ✓ TAR.GZ-архив — TAR.GZ, 0.1 с

## FLAC

- ✓ MP3 — mp3 4.0 с, 0.2 с
- ✓ M4A — m4a 4.0 с, 0.3 с
- ✓ WAV — wav 4.0 с, 0.1 с
- ✓ OGG — ogg 4.0 с, 0.2 с
- ✓ OPUS — opus 4.0 с, 0.2 с
- ✓ AAC — aac 4.1 с, 0.3 с
- ✓ AIFF — aiff 4.0 с, 0.2 с
- ✓ WMA — wma 4.0 с, 0.2 с
- ✓ ZIP-архив — ZIP, 0.1 с
- ✓ TAR.GZ-архив — TAR.GZ, 0.1 с

## FLV

- ✓ MP4 — mp4 3.0 с, 1.2 с
- ✓ Сжать видео — mp4 3.0 с, 0.6 с
- ✓ GIF — gif 480x270, 0.7 с
- ✓ MP3 (звук) — mp3 3.1 с, 0.1 с
- ✓ WEBM — webm 3.0 с, 1.6 с
- ✓ MOV — mov 3.0 с, 1.2 с
- ✓ MKV — mkv 3.1 с, 1.3 с
- ✓ AVI — avi 3.1 с, 0.5 с
- ✓ M4A (звук) — m4a 3.0 с, 0.5 с
- ✓ WAV (звук) — wav 3.0 с, 0.2 с
- ✓ FLAC (звук) — flac 3.0 с, 0.2 с
- ✓ OGG (звук) — ogg 3.0 с, 0.2 с
- ✓ OPUS (звук) — opus 3.0 с, 0.2 с
- ✓ ZIP-архив — ZIP, 0.1 с
- ✓ TAR.GZ-архив — TAR.GZ, 0.1 с

## FOLDER

- ✓ ZIP-архив — ZIP, 0.1 с
- ✓ TAR.GZ-архив — TAR.GZ, 0.1 с

## GIF

- ✓ JPG — jpg 320x200, 0.1 с
- ✓ MP4 — mp4 1.0 с, 0.3 с
- ✓ PNG — png 320x200, 0.1 с
- ✓ WEBM — webm 1.0 с, 0.2 с
- ✓ WEBP — webp 320x200, 0.2 с
- ✓ AVIF — avif 320x200, 0.2 с
- ✓ PDF — PDF, 1 стр., 0.1 с
- ✓ MOV — mov 1.0 с, 0.2 с
- ✓ MKV — mkv 1.0 с, 0.3 с
- ✓ AVI — avi 1.0 с, 0.1 с
- ✓ TIFF — tiff 320x200, 0.1 с
- ✓ BMP — bmp 320x200, 0.1 с
- ✓ ICO — ico 256x256, 0.1 с
- ✓ ZIP-архив — ZIP, 0.1 с
- ✓ TAR.GZ-архив — TAR.GZ, 0.1 с

## HTML

- ✓ PDF — PDF, 1 стр., 0.2 с
- ✓ DOCX — DOCX, 0.3 с
- ✓ MD — MD 572 симв., 0.1 с
- ✓ TXT — TXT 297 симв., 0.4 с
- ✓ ODT — ODT, 0.5 с
- ✓ RTF — RTF, 0.1 с
- ✓ EPUB — EPUB, 0.2 с
- ✓ DOC — DOC, 0.4 с
- ✓ ZIP-архив — ZIP, 0.1 с
- ✓ TAR.GZ-архив — TAR.GZ, 0.1 с

## ICO

- ✓ JPG — jpg 64x42, 0.1 с
- ✓ PNG — png 64x42, 0.1 с
- ✓ WEBP — webp 64x42, 0.1 с
- ✓ AVIF — avif 64x42, 0.1 с
- ✓ PDF — PDF, 1 стр., 0.1 с
- ✓ TIFF — tiff 64x42, 0.1 с
- ✓ GIF — gif 64x42, 0.1 с
- ✓ BMP — bmp 64x42, 0.1 с
- ✓ ZIP-архив — ZIP, 0.1 с
- ✓ TAR.GZ-архив — TAR.GZ, 0.1 с

## JPG

- ✓ PNG — png 640x420, 0.1 с
- ✓ WEBP — webp 640x420, 0.1 с
- ✓ AVIF — avif 640x420, 0.3 с
- ✓ PDF — PDF, 1 стр., 0.1 с
- ✓ TIFF — tiff 640x420, 0.1 с
- ✓ GIF — gif 640x420, 0.1 с
- ✓ BMP — bmp 640x420, 0.1 с
- ✓ ICO — ico 256x256, 0.1 с
- ✓ ZIP-архив — ZIP, 0.1 с
- ✓ TAR.GZ-архив — TAR.GZ, 0.1 с

## JSON

- ✓ CSV — CSV 83 симв., 0.0 с
- ✓ XLSX — XLSX, 0.2 с
- ✓ ODS — ODS, 0.5 с
- ✓ ZIP-архив — ZIP, 0.1 с
- ✓ TAR.GZ-архив — TAR.GZ, 0.1 с

## M4A

- ✓ MP3 — mp3 4.0 с, 0.2 с
- ✓ WAV — wav 4.0 с, 0.2 с
- ✓ FLAC — flac 4.0 с, 0.1 с
- ✓ OGG — ogg 4.0 с, 0.2 с
- ✓ OPUS — opus 4.0 с, 0.2 с
- ✓ AAC — aac 3.9 с, 0.3 с
- ✓ AIFF — aiff 4.0 с, 0.2 с
- ✓ WMA — wma 4.0 с, 0.2 с
- ✓ ZIP-архив — ZIP, 0.0 с
- ✓ TAR.GZ-архив — TAR.GZ, 0.1 с

## MD

- ✓ HTML — HTML 4705 симв., 0.1 с
- ✓ DOCX — DOCX, 0.1 с
- ✓ PDF — PDF, 1 стр., 0.4 с
- ✓ ODT — ODT, 0.1 с
- ✓ RTF — RTF, 0.1 с
- ✓ EPUB — EPUB, 0.1 с
- ✓ TXT — TXT 344 симв., 0.1 с
- ✓ DOC — DOC, 0.8 с
- ✓ ZIP-архив — ZIP, 0.1 с
- ✓ TAR.GZ-архив — TAR.GZ, 0.1 с

## MKV

- ✓ MP4 — mp4 3.0 с, 0.9 с
- ✓ Сжать видео — mp4 3.0 с, 0.8 с
- ✓ GIF — gif 480x270, 0.9 с
- ✓ MP3 (звук) — mp3 3.1 с, 0.2 с
- ✓ WEBM — webm 3.0 с, 1.6 с
- ✓ MOV — mov 3.0 с, 1.2 с
- ✓ AVI — avi 3.1 с, 1.0 с
- ✓ M4A (звук) — m4a 3.0 с, 0.4 с
- ✓ WAV (звук) — wav 3.0 с, 0.2 с
- ✓ FLAC (звук) — flac 3.0 с, 0.2 с
- ✓ OGG (звук) — ogg 3.0 с, 0.1 с
- ✓ OPUS (звук) — opus 3.0 с, 0.2 с
- ✓ ZIP-архив — ZIP, 0.1 с
- ✓ TAR.GZ-архив — TAR.GZ, 0.1 с

## MOV

- ✓ MP4 — mp4 3.0 с, 0.7 с
- ✓ Сжать видео — mp4 3.0 с, 0.5 с
- ✓ GIF — gif 480x270, 0.7 с
- ✓ MP3 (звук) — mp3 3.1 с, 0.3 с
- ✓ WEBM — webm 3.0 с, 1.4 с
- ✓ MKV — mkv 3.0 с, 0.4 с
- ✓ AVI — avi 3.1 с, 0.2 с
- ✓ M4A (звук) — m4a 3.0 с, 0.3 с
- ✓ WAV (звук) — wav 3.0 с, 0.3 с
- ✓ FLAC (звук) — flac 3.0 с, 0.2 с
- ✓ OGG (звук) — ogg 3.0 с, 0.3 с
- ✓ OPUS (звук) — opus 3.0 с, 0.3 с
- ✓ ZIP-архив — ZIP, 0.1 с
- ✓ TAR.GZ-архив — TAR.GZ, 0.1 с

## MP3

- ✓ M4A — m4a 4.0 с, 0.4 с
- ✓ WAV — wav 4.0 с, 0.2 с
- ✓ FLAC — flac 4.0 с, 0.2 с
- ✓ OGG — ogg 4.0 с, 0.2 с
- ✓ OPUS — opus 4.0 с, 0.2 с
- ✓ AAC — aac 4.0 с, 0.3 с
- ✓ AIFF — aiff 4.0 с, 0.1 с
- ✓ WMA — wma 4.0 с, 0.1 с
- ✓ ZIP-архив — ZIP, 0.1 с
- ✓ TAR.GZ-архив — TAR.GZ, 0.1 с

## MP4

- ✓ Сжать видео — mp4 3.0 с, 0.6 с
- ✓ GIF — gif 480x270, 0.6 с
- ✓ MP3 (звук) — mp3 3.1 с, 0.6 с
- ✓ WEBM — webm 3.0 с, 1.6 с
- ✓ MOV — mov 3.0 с, 0.3 с
- ✓ MKV — mkv 3.0 с, 0.4 с
- ✓ AVI — avi 3.1 с, 0.4 с
- ✓ M4A (звук) — m4a 3.0 с, 0.4 с
- ✓ WAV (звук) — wav 3.0 с, 0.3 с
- ✓ FLAC (звук) — flac 3.0 с, 0.2 с
- ✓ OGG (звук) — ogg 3.0 с, 0.2 с
- ✓ OPUS (звук) — opus 3.0 с, 0.2 с
- ✓ ZIP-архив — ZIP, 0.1 с
- ✓ TAR.GZ-архив — TAR.GZ, 0.1 с

## MPEG

- ✓ MP4 — mp4 3.0 с, 0.9 с
- ✓ Сжать видео — mp4 3.0 с, 0.7 с
- ✓ GIF — gif 480x270, 1.1 с
- ✓ MP3 (звук) — mp3 3.0 с, 0.3 с
- ✓ WEBM — webm 3.0 с, 1.6 с
- ✓ MOV — mov 3.0 с, 1.0 с
- ✓ MKV — mkv 3.0 с, 1.4 с
- ✓ AVI — avi 3.0 с, 0.8 с
- ✓ M4A (звук) — m4a 3.0 с, 0.4 с
- ✓ WAV (звук) — wav 3.0 с, 0.2 с
- ✓ FLAC (звук) — flac 3.0 с, 0.2 с
- ✓ OGG (звук) — ogg 3.0 с, 0.2 с
- ✓ OPUS (звук) — opus 3.0 с, 0.2 с
- ✓ ZIP-архив — ZIP, 0.1 с
- ✓ TAR.GZ-архив — TAR.GZ, 0.1 с

## ODP

- ✓ PDF — PDF, 3 стр., 0.4 с
- ✓ PNG — папка, 3 файл(ов), 0.9 с
- ✓ JPG — папка, 3 файл(ов), 1.2 с
- ✓ PPTX — PPTX, 1.2 с
- ✓ PPT — PPT, 1.1 с
- ✓ ZIP-архив — ZIP, 0.1 с
- ✓ TAR.GZ-архив — TAR.GZ, 0.1 с

## ODS

- ✓ CSV — папка, 2 файл(ов), 0.9 с
- ✓ PDF — PDF, 2 стр., 1.0 с
- ✓ JSON — JSON 163 симв., 0.7 с
- ✓ XLSX — XLSX, 1.0 с
- ✓ XLS — XLS, 0.5 с
- ✓ HTML — HTML 3026 симв., 0.8 с
- ✓ ZIP-архив — ZIP, 0.1 с
- ✓ TAR.GZ-архив — TAR.GZ, 0.1 с

## ODT

- ✓ PDF — PDF, 2 стр., 0.7 с
- ✓ DOCX — DOCX, 0.9 с
- ✓ TXT — TXT 273 симв., 1.0 с
- ✓ RTF — RTF, 1.0 с
- ✓ DOC — DOC, 1.2 с
- ✓ HTML — HTML 1837 симв., 0.1 с
- ✓ MD — MD 364 симв., 0.1 с
- ✓ EPUB — EPUB, 0.1 с
- ✓ ZIP-архив — ZIP, 0.1 с
- ✓ TAR.GZ-архив — TAR.GZ, 0.1 с

## OGG

- ✓ MP3 — mp3 4.0 с, 0.2 с
- ✓ M4A — m4a 4.0 с, 0.4 с
- ✓ WAV — wav 4.0 с, 0.1 с
- ✓ FLAC — flac 4.0 с, 0.1 с
- ✓ OPUS — opus 4.0 с, 0.2 с
- ✓ AAC — aac 4.0 с, 0.3 с
- ✓ AIFF — aiff 4.0 с, 0.2 с
- ✓ WMA — wma 4.0 с, 0.2 с
- ✓ ZIP-архив — ZIP, 0.0 с
- ✓ TAR.GZ-архив — TAR.GZ, 0.1 с

## OPUS

- ✓ MP3 — mp3 4.0 с, 0.2 с
- ✓ M4A — m4a 4.0 с, 0.3 с
- ✓ WAV — wav 4.0 с, 0.2 с
- ✓ FLAC — flac 4.0 с, 0.2 с
- ✓ OGG — ogg 4.0 с, 0.2 с
- ✓ AAC — aac 4.0 с, 0.3 с
- ✓ AIFF — aiff 4.0 с, 0.2 с
- ✓ WMA — wma 4.0 с, 0.2 с
- ✓ ZIP-архив — ZIP, 0.0 с
- ✓ TAR.GZ-архив — TAR.GZ, 0.1 с

## PDF

- ✓ PNG — папка, 2 файл(ов), 0.1 с
- ✓ JPG — папка, 2 файл(ов), 0.1 с
- ✓ DOCX — DOCX, 0.3 с
- ✓ TXT — TXT 356 симв., 0.1 с
- ✓ Сжать PDF — PDF, 2 стр., 0.1 с
- ✓ Разделить — папка, 2 файл(ов), 0.1 с
- ✓ ODT — ODT, 0.6 с
- ✓ ZIP-архив — ZIP, 0.1 с
- ✓ TAR.GZ-архив — TAR.GZ, 0.1 с

## PNG

- ✓ JPG — jpg 640x420, 0.1 с
- ✓ WEBP — webp 640x420, 0.1 с
- ✓ AVIF — avif 640x420, 0.3 с
- ✓ PDF — PDF, 1 стр., 0.1 с
- ✓ TIFF — tiff 640x420, 0.1 с
- ✓ GIF — gif 640x420, 0.2 с
- ✓ BMP — bmp 640x420, 0.1 с
- ✓ ICO — ico 256x256, 0.1 с
- ✓ ZIP-архив — ZIP, 0.1 с
- ✓ TAR.GZ-архив — TAR.GZ, 0.1 с

## PPT

- ✓ PDF — PDF, 3 стр., 0.2 с
- ✓ PNG — папка, 3 файл(ов), 0.7 с
- ✓ JPG — папка, 3 файл(ов), 0.9 с
- ✓ PPTX — PPTX, 0.9 с
- ✓ ODP — ODP, 0.8 с
- ✓ ZIP-архив — ZIP, 0.1 с
- ✓ TAR.GZ-архив — TAR.GZ, 0.1 с

## PPTX

- ✓ PDF — PDF, 3 стр., 0.8 с
- ✓ PNG — папка, 3 файл(ов), 1.3 с
- ✓ JPG — папка, 3 файл(ов), 1.2 с
- ✓ ODP — ODP, 1.2 с
- ✓ PPT — PPT, 1.4 с
- ✓ ZIP-архив — ZIP, 0.1 с
- ✓ TAR.GZ-архив — TAR.GZ, 0.1 с

## PSD

- ✓ JPG — jpg 640x420, 0.1 с
- ✓ PNG — png 640x420, 0.1 с
- ✓ WEBP — webp 640x420, 0.1 с
- ✓ AVIF — avif 640x420, 0.6 с
- ✓ PDF — PDF, 1 стр., 0.1 с
- ✓ TIFF — tiff 640x420, 0.1 с
- ✓ GIF — gif 640x420, 0.2 с
- ✓ BMP — bmp 640x420, 0.1 с
- ✓ ICO — ico 256x256, 0.1 с
- ✓ ZIP-архив — ZIP, 0.1 с
- ✓ TAR.GZ-архив — TAR.GZ, 0.1 с

## RTF

- ✓ PDF — PDF, 2 стр., 0.4 с
- ✓ DOCX — DOCX, 0.6 с
- ✓ TXT — TXT 273 симв., 0.7 с
- ✓ ODT — ODT, 0.8 с
- ✓ DOC — DOC, 0.8 с
- ✓ HTML — HTML 1913 симв., 0.1 с
- ✓ MD — MD 506 симв., 0.1 с
- ✓ EPUB — EPUB, 0.1 с
- ✓ ZIP-архив — ZIP, 0.1 с
- ✓ TAR.GZ-архив — TAR.GZ, 0.1 с

## SVG

- ✓ JPG — jpg 400x240, 0.1 с
- ✓ PNG — png 400x240, 0.1 с
- ✓ WEBP — webp 400x240, 0.1 с
- ✓ AVIF — avif 400x240, 0.2 с
- ✓ PDF — PDF, 1 стр., 0.1 с
- ✓ TIFF — tiff 400x240, 0.1 с
- ✓ GIF — gif 400x240, 0.2 с
- ✓ BMP — bmp 400x240, 0.2 с
- ✓ ICO — ico 256x256, 0.1 с
- ✓ ZIP-архив — ZIP, 0.1 с
- ✓ TAR.GZ-архив — TAR.GZ, 0.1 с

## TAR

- ✓ Распаковать — папка, 3 файл(ов), 0.1 с
- ✓ ZIP — ZIP, 0.1 с
- ✓ TAR.GZ — TAR.GZ, 0.2 с

## TARBZ2

- ✓ Распаковать — папка, 3 файл(ов), 0.1 с
- ✓ ZIP — ZIP, 0.1 с
- ✓ TAR.GZ — TAR.GZ, 0.2 с

## TARGZ

- ✓ Распаковать — папка, 3 файл(ов), 0.1 с
- ✓ ZIP — ZIP, 0.1 с

## TARXZ

- ✓ Распаковать — папка, 3 файл(ов), 0.1 с
- ✓ ZIP — ZIP, 0.1 с
- ✓ TAR.GZ — TAR.GZ, 0.1 с

## TGA

- ✓ JPG — jpg 640x420, 0.1 с
- ✓ PNG — png 640x420, 0.1 с
- ✓ WEBP — webp 640x420, 0.1 с
- ✓ AVIF — avif 640x420, 0.4 с
- ✓ PDF — PDF, 1 стр., 0.1 с
- ✓ TIFF — tiff 640x420, 0.1 с
- ✓ GIF — gif 640x420, 0.2 с
- ✓ BMP — bmp 640x420, 0.1 с
- ✓ ICO — ico 256x256, 0.1 с
- ✓ ZIP-архив — ZIP, 0.1 с
- ✓ TAR.GZ-архив — TAR.GZ, 0.1 с

## TIFF

- ✓ JPG — jpg 640x420, 0.1 с
- ✓ PNG — png 640x420, 0.1 с
- ✓ WEBP — webp 640x420, 0.1 с
- ✓ AVIF — avif 640x420, 0.2 с
- ✓ PDF — PDF, 1 стр., 0.1 с
- ✓ GIF — gif 640x420, 0.3 с
- ✓ BMP — bmp 640x420, 0.1 с
- ✓ ICO — ico 256x256, 0.1 с
- ✓ ZIP-архив — ZIP, 0.1 с
- ✓ TAR.GZ-архив — TAR.GZ, 0.1 с

## TS

- ✓ MP4 — mp4 3.0 с, 0.8 с
- ✓ Сжать видео — mp4 3.0 с, 0.7 с
- ✓ GIF — gif 480x270, 0.9 с
- ✓ MP3 (звук) — mp3 3.1 с, 0.2 с
- ✓ WEBM — webm 3.0 с, 1.7 с
- ✓ MOV — mov 3.0 с, 0.3 с
- ✓ MKV — mkv 3.0 с, 0.4 с
- ✓ AVI — avi 3.1 с, 0.4 с
- ✓ M4A (звук) — m4a 3.0 с, 0.6 с
- ✓ WAV (звук) — wav 3.0 с, 0.4 с
- ✓ FLAC (звук) — flac 3.0 с, 0.2 с
- ✓ OGG (звук) — ogg 3.0 с, 0.3 с
- ✓ OPUS (звук) — opus 3.0 с, 0.2 с
- ✓ ZIP-архив — ZIP, 0.1 с
- ✓ TAR.GZ-архив — TAR.GZ, 0.1 с

## TSV

- ✓ XLSX — XLSX, 0.2 с
- ✓ JSON — JSON 109 симв., 0.0 с
- ✓ PDF — PDF, 1 стр., 0.4 с
- ✓ CSV — CSV 45 симв., 0.0 с
- ✓ ODS — ODS, 0.6 с
- ✓ XLS — XLS, 0.6 с
- ✓ HTML — HTML 1540 симв., 0.6 с
- ✓ ZIP-архив — ZIP, 0.0 с
- ✓ TAR.GZ-архив — TAR.GZ, 0.1 с

## TXT

- ✓ PDF — PDF, 1 стр., 0.5 с
- ✓ DOCX — DOCX, 0.6 с
- ✓ ODT — ODT, 0.7 с
- ✓ RTF — RTF, 0.7 с
- ✓ DOC — DOC, 0.7 с
- ✓ HTML — HTML 2343 симв., 0.8 с
- ✓ MD — MD 171 симв., 0.1 с
- ✓ EPUB — EPUB, 0.1 с
- ✓ ZIP-архив — ZIP, 0.1 с
- ✓ TAR.GZ-архив — TAR.GZ, 0.1 с

## WAV

- ✓ MP3 — mp3 4.0 с, 0.2 с
- ✓ M4A — m4a 4.0 с, 0.5 с
- ✓ FLAC — flac 4.0 с, 0.1 с
- ✓ OGG — ogg 4.0 с, 0.2 с
- ✓ OPUS — opus 4.0 с, 0.2 с
- ✓ AAC — aac 4.1 с, 0.3 с
- ✓ AIFF — aiff 4.0 с, 0.2 с
- ✓ WMA — wma 4.0 с, 0.2 с
- ✓ ZIP-архив — ZIP, 0.0 с
- ✓ TAR.GZ-архив — TAR.GZ, 0.1 с

## WEBM

- ✓ MP4 — mp4 3.0 с, 0.8 с
- ✓ Сжать видео — mp4 3.0 с, 0.7 с
- ✓ GIF — gif 480x270, 1.4 с
- ✓ MP3 (звук) — mp3 3.0 с, 0.2 с
- ✓ MOV — mov 3.0 с, 0.8 с
- ✓ MKV — mkv 3.0 с, 0.7 с
- ✓ AVI — avi 3.0 с, 0.3 с
- ✓ M4A (звук) — m4a 3.0 с, 0.3 с
- ✓ WAV (звук) — wav 3.0 с, 0.3 с
- ✓ FLAC (звук) — flac 3.0 с, 0.2 с
- ✓ OGG (звук) — ogg 3.0 с, 0.2 с
- ✓ OPUS (звук) — opus 3.0 с, 0.2 с
- ✓ ZIP-архив — ZIP, 0.1 с
- ✓ TAR.GZ-архив — TAR.GZ, 0.1 с

## WEBP

- ✓ JPG — jpg 640x420, 0.1 с
- ✓ PNG — png 640x420, 0.1 с
- ✓ AVIF — avif 640x420, 0.4 с
- ✓ PDF — PDF, 1 стр., 0.1 с
- ✓ TIFF — tiff 640x420, 0.1 с
- ✓ GIF — gif 640x420, 0.3 с
- ✓ BMP — bmp 640x420, 0.1 с
- ✓ ICO — ico 256x256, 0.1 с
- ✓ ZIP-архив — ZIP, 0.1 с
- ✓ TAR.GZ-архив — TAR.GZ, 0.1 с

## WMA

- ✓ MP3 — mp3 4.0 с, 0.2 с
- ✓ M4A — m4a 4.0 с, 0.3 с
- ✓ WAV — wav 4.0 с, 0.2 с
- ✓ FLAC — flac 4.0 с, 0.2 с
- ✓ OGG — ogg 4.0 с, 0.2 с
- ✓ OPUS — opus 4.1 с, 0.2 с
- ✓ AAC — aac 4.0 с, 0.3 с
- ✓ AIFF — aiff 4.0 с, 0.1 с
- ✓ ZIP-архив — ZIP, 0.1 с
- ✓ TAR.GZ-архив — TAR.GZ, 0.1 с

## WMV

- ✓ MP4 — mp4 3.1 с, 0.9 с
- ✓ Сжать видео — mp4 3.1 с, 0.6 с
- ✓ GIF — gif 480x270, 1.4 с
- ✓ MP3 (звук) — mp3 3.0 с, 0.3 с
- ✓ WEBM — webm 3.1 с, 1.6 с
- ✓ MOV — mov 3.1 с, 1.3 с
- ✓ MKV — mkv 3.1 с, 1.4 с
- ✓ AVI — avi 3.1 с, 0.5 с
- ✓ M4A (звук) — m4a 3.0 с, 0.5 с
- ✓ WAV (звук) — wav 3.0 с, 0.3 с
- ✓ FLAC (звук) — flac 3.0 с, 0.1 с
- ✓ OGG (звук) — ogg 3.0 с, 0.2 с
- ✓ OPUS (звук) — opus 3.1 с, 0.2 с
- ✓ ZIP-архив — ZIP, 0.1 с
- ✓ TAR.GZ-архив — TAR.GZ, 0.1 с

## XLS

- ✓ CSV — папка, 2 файл(ов), 0.2 с
- ✓ PDF — PDF, 2 стр., 0.3 с
- ✓ JSON — JSON 163 симв., 0.5 с
- ✓ XLSX — XLSX, 0.5 с
- ✓ ODS — ODS, 0.7 с
- ✓ HTML — HTML 2872 симв., 0.7 с
- ✓ ZIP-архив — ZIP, 0.1 с
- ✓ TAR.GZ-архив — TAR.GZ, 0.1 с

## XLSX

- ✓ CSV — папка, 2 файл(ов), 0.6 с
- ✓ PDF — PDF, 2 стр., 0.7 с
- ✓ JSON — JSON 163 симв., 0.7 с
- ✓ ODS — ODS, 0.8 с
- ✓ XLS — XLS, 0.8 с
- ✓ HTML — HTML 3026 симв., 0.8 с
- ✓ ZIP-архив — ZIP, 0.1 с
- ✓ TAR.GZ-архив — TAR.GZ, 0.1 с

## ZIP

- ✓ Распаковать — папка, 3 файл(ов), 0.1 с
- ✓ TAR.GZ — TAR.GZ, 0.1 с

## Пропущено: нет движка на тестовой машине

- folder → 7z: нужен bsdtar
- 3gp → 7z: нужен bsdtar
- aac → 7z: нужен bsdtar
- aiff → 7z: нужен bsdtar
- avi → 7z: нужен bsdtar
- avif → heic: нужен ImageMagick
- avif → 7z: нужен bsdtar
- bmp → heic: нужен ImageMagick
- bmp → 7z: нужен bsdtar
- csv → 7z: нужен bsdtar
- dng → heic: нужен ImageMagick
- dng → 7z: нужен bsdtar
- doc → 7z: нужен bsdtar
- docx → 7z: нужен bsdtar
- epub → mobi: нужен Calibre
- epub → azw3: нужен Calibre
- epub → 7z: нужен bsdtar
- fb2 → mobi: нужен Calibre
- fb2 → azw3: нужен Calibre
- fb2 → 7z: нужен bsdtar
- flac → 7z: нужен bsdtar
- flv → 7z: нужен bsdtar
- gif → heic: нужен ImageMagick
- gif → 7z: нужен bsdtar
- html → 7z: нужен bsdtar
- ico → heic: нужен ImageMagick
- ico → 7z: нужен bsdtar
- jpg → heic: нужен ImageMagick
- jpg → 7z: нужен bsdtar
- json → 7z: нужен bsdtar
- m4a → 7z: нужен bsdtar
- md → 7z: нужен bsdtar
- mkv → 7z: нужен bsdtar
- mov → 7z: нужен bsdtar
- mp3 → 7z: нужен bsdtar
- mp4 → 7z: нужен bsdtar
- mpeg → 7z: нужен bsdtar
- odp → 7z: нужен bsdtar
- ods → 7z: нужен bsdtar
- odt → 7z: нужен bsdtar
- ogg → 7z: нужен bsdtar
- opus → 7z: нужен bsdtar
- pdf → 7z: нужен bsdtar
- png → heic: нужен ImageMagick
- png → 7z: нужен bsdtar
- ppt → 7z: нужен bsdtar
- pptx → 7z: нужен bsdtar
- psd → heic: нужен ImageMagick
- psd → 7z: нужен bsdtar
- rtf → 7z: нужен bsdtar
- svg → heic: нужен ImageMagick
- svg → 7z: нужен bsdtar
- tar → 7z: нужен bsdtar
- tarbz2 → 7z: нужен bsdtar
- targz → 7z: нужен bsdtar
- tarxz → 7z: нужен bsdtar
- tga → heic: нужен ImageMagick
- tga → 7z: нужен bsdtar
- tiff → heic: нужен ImageMagick
- tiff → 7z: нужен bsdtar
- ts → 7z: нужен bsdtar
- tsv → 7z: нужен bsdtar
- txt → 7z: нужен bsdtar
- wav → 7z: нужен bsdtar
- webm → 7z: нужен bsdtar
- webp → heic: нужен ImageMagick
- webp → 7z: нужен bsdtar
- wma → 7z: нужен bsdtar
- wmv → 7z: нужен bsdtar
- xls → 7z: нужен bsdtar
- xlsx → 7z: нужен bsdtar
- zip → 7z: нужен bsdtar
