# Поддерживаемые конвертации

Таблица собрана автоматически из реестра ядра (`python3 scripts/gen-conversions.py`). **Жирным** выделены цели, которые меню показывает в «Популярных», остальные лежат в «Ещё».

Кроме того, **любой файл или папку можно упаковать в ZIP, 7Z или TAR.GZ**, а при выделении нескольких файлов доступны:
- **Объединить** — несколько PDF в один;
- **Один PDF** — несколько изображений страницами одного PDF;
- **ZIP / 7Z / TAR.GZ из всех** — один архив из выделенного.

## Изображения

| Из | Во что | Движок |
|---|---|---|
| JPG (.jpg, .jpeg, .jpe, .jfif) | **PNG**, **WEBP**, **AVIF**, **PDF**, HEIC, TIFF, GIF, BMP, ICO | ImageMagick · sips · FFmpeg |
| PNG (.png) | **JPG**, **WEBP**, **AVIF**, **PDF**, HEIC, TIFF, GIF, BMP, ICO | ImageMagick · sips · FFmpeg |
| WEBP (.webp) | **JPG**, **PNG**, **AVIF**, **PDF**, HEIC, TIFF, GIF, BMP, ICO | ImageMagick · sips · FFmpeg |
| AVIF (.avif) | **JPG**, **PNG**, **WEBP**, **PDF**, HEIC, TIFF, GIF, BMP, ICO | ImageMagick · sips · FFmpeg |
| HEIC (.heic, .heif, .hif) | **JPG**, **PNG**, **WEBP**, **AVIF**, **PDF**, TIFF, GIF, BMP, ICO | ImageMagick · sips · FFmpeg |
| GIF (.gif) | **JPG**, **MP4**, **PNG**, **WEBM**, **WEBP**, **AVIF**, **PDF**, MOV, MKV, AVI, HEIC, TIFF, BMP, ICO | ImageMagick · sips · FFmpeg |
| BMP (.bmp, .dib) | **JPG**, **PNG**, **WEBP**, **AVIF**, **PDF**, HEIC, TIFF, GIF, ICO | ImageMagick · sips · FFmpeg |
| TIFF (.tiff, .tif) | **JPG**, **PNG**, **WEBP**, **AVIF**, **PDF**, HEIC, GIF, BMP, ICO | ImageMagick · sips · FFmpeg |
| ICO (.ico) | **JPG**, **PNG**, **WEBP**, **AVIF**, **PDF**, HEIC, TIFF, GIF, BMP | ImageMagick · sips · FFmpeg |
| SVG (.svg) | **JPG**, **PNG**, **WEBP**, **AVIF**, **PDF**, HEIC, TIFF, GIF, BMP, ICO | ImageMagick · sips · FFmpeg |
| PSD (.psd) | **JPG**, **PNG**, **WEBP**, **AVIF**, **PDF**, HEIC, TIFF, GIF, BMP, ICO | ImageMagick · sips · FFmpeg |
| TGA (.tga) | **JPG**, **PNG**, **WEBP**, **AVIF**, **PDF**, HEIC, TIFF, GIF, BMP, ICO | ImageMagick · sips · FFmpeg |
| CR2 (.cr2) | **JPG**, **PNG**, **TIFF**, **WEBP**, **AVIF**, **PDF**, HEIC, GIF, BMP, ICO | ImageMagick · sips · FFmpeg |
| CR3 (.cr3) | **JPG**, **PNG**, **TIFF**, **WEBP**, **AVIF**, **PDF**, HEIC, GIF, BMP, ICO | ImageMagick · sips · FFmpeg |
| NEF (.nef) | **JPG**, **PNG**, **TIFF**, **WEBP**, **AVIF**, **PDF**, HEIC, GIF, BMP, ICO | ImageMagick · sips · FFmpeg |
| ARW (.arw) | **JPG**, **PNG**, **TIFF**, **WEBP**, **AVIF**, **PDF**, HEIC, GIF, BMP, ICO | ImageMagick · sips · FFmpeg |
| DNG (.dng) | **JPG**, **PNG**, **TIFF**, **WEBP**, **AVIF**, **PDF**, HEIC, GIF, BMP, ICO | ImageMagick · sips · FFmpeg |
| ORF (.orf) | **JPG**, **PNG**, **TIFF**, **WEBP**, **AVIF**, **PDF**, HEIC, GIF, BMP, ICO | ImageMagick · sips · FFmpeg |
| RW2 (.rw2) | **JPG**, **PNG**, **TIFF**, **WEBP**, **AVIF**, **PDF**, HEIC, GIF, BMP, ICO | ImageMagick · sips · FFmpeg |
| RAF (.raf) | **JPG**, **PNG**, **TIFF**, **WEBP**, **AVIF**, **PDF**, HEIC, GIF, BMP, ICO | ImageMagick · sips · FFmpeg |

## Видео

| Из | Во что | Движок |
|---|---|---|
| MP4 (.mp4, .m4v) | **сжатое MP4**, **GIF**, **MP3 (звук)**, WEBM, MOV, MKV, AVI, M4A (звук), WAV (звук), FLAC (звук), OGG (звук), OPUS (звук) | FFmpeg |
| MOV (.mov, .qt) | **MP4**, **сжатое MP4**, **GIF**, **MP3 (звук)**, WEBM, MKV, AVI, M4A (звук), WAV (звук), FLAC (звук), OGG (звук), OPUS (звук) | FFmpeg |
| MKV (.mkv) | **MP4**, **сжатое MP4**, **GIF**, **MP3 (звук)**, WEBM, MOV, AVI, M4A (звук), WAV (звук), FLAC (звук), OGG (звук), OPUS (звук) | FFmpeg |
| AVI (.avi) | **MP4**, **сжатое MP4**, **GIF**, **MP3 (звук)**, WEBM, MOV, MKV, M4A (звук), WAV (звук), FLAC (звук), OGG (звук), OPUS (звук) | FFmpeg |
| WEBM (.webm) | **MP4**, **сжатое MP4**, **GIF**, **MP3 (звук)**, MOV, MKV, AVI, M4A (звук), WAV (звук), FLAC (звук), OGG (звук), OPUS (звук) | FFmpeg |
| WMV (.wmv, .asf) | **MP4**, **сжатое MP4**, **GIF**, **MP3 (звук)**, WEBM, MOV, MKV, AVI, M4A (звук), WAV (звук), FLAC (звук), OGG (звук), OPUS (звук) | FFmpeg |
| FLV (.flv) | **MP4**, **сжатое MP4**, **GIF**, **MP3 (звук)**, WEBM, MOV, MKV, AVI, M4A (звук), WAV (звук), FLAC (звук), OGG (звук), OPUS (звук) | FFmpeg |
| MPEG (.mpg, .mpeg, .vob) | **MP4**, **сжатое MP4**, **GIF**, **MP3 (звук)**, WEBM, MOV, MKV, AVI, M4A (звук), WAV (звук), FLAC (звук), OGG (звук), OPUS (звук) | FFmpeg |
| 3GP (.3gp, .3g2) | **MP4**, **сжатое MP4**, **GIF**, **MP3 (звук)**, WEBM, MOV, MKV, AVI, M4A (звук), WAV (звук), FLAC (звук), OGG (звук), OPUS (звук) | FFmpeg |
| TS (.ts, .mts, .m2ts) | **MP4**, **сжатое MP4**, **GIF**, **MP3 (звук)**, WEBM, MOV, MKV, AVI, M4A (звук), WAV (звук), FLAC (звук), OGG (звук), OPUS (звук) | FFmpeg |

## Аудио

| Из | Во что | Движок |
|---|---|---|
| MP3 (.mp3) | **M4A**, **WAV**, **FLAC**, OGG, OPUS, AAC, AIFF, WMA | FFmpeg |
| WAV (.wav, .wave) | **MP3**, **M4A**, **FLAC**, OGG, OPUS, AAC, AIFF, WMA | FFmpeg |
| FLAC (.flac) | **MP3**, **M4A**, **WAV**, OGG, OPUS, AAC, AIFF, WMA | FFmpeg |
| M4A (.m4a, .m4b, .alac) | **MP3**, **WAV**, **FLAC**, OGG, OPUS, AAC, AIFF, WMA | FFmpeg |
| AAC (.aac) | **MP3**, **M4A**, **WAV**, **FLAC**, OGG, OPUS, AIFF, WMA | FFmpeg |
| OGG (.ogg, .oga) | **MP3**, **M4A**, **WAV**, **FLAC**, OPUS, AAC, AIFF, WMA | FFmpeg |
| OPUS (.opus) | **MP3**, **M4A**, **WAV**, **FLAC**, OGG, AAC, AIFF, WMA | FFmpeg |
| WMA (.wma) | **MP3**, **M4A**, **WAV**, **FLAC**, OGG, OPUS, AAC, AIFF | FFmpeg |
| AIFF (.aiff, .aif, .aifc) | **MP3**, **M4A**, **WAV**, **FLAC**, OGG, OPUS, AAC, WMA | FFmpeg |
| AMR (.amr) | **MP3**, **M4A**, **WAV**, **FLAC**, OGG, OPUS, AAC, AIFF, WMA | FFmpeg |

## Документы

| Из | Во что | Движок |
|---|---|---|
| PDF (.pdf) | **PNG (страницы)**, **JPG (страницы)**, **DOCX**, **TXT**, сжатый PDF, PDF по страницам, ODT | Poppler · qpdf · LibreOffice |
| DOCX (.docx) | **PDF**, **TXT**, ODT, RTF, DOC, HTML, MD, EPUB | LibreOffice · Pandoc |
| DOC (.doc) | **PDF**, **DOCX**, **TXT**, ODT, RTF, HTML, MD, EPUB | LibreOffice · Pandoc |
| ODT (.odt) | **PDF**, **DOCX**, **TXT**, RTF, DOC, HTML, MD, EPUB | LibreOffice · Pandoc |
| RTF (.rtf) | **PDF**, **DOCX**, **TXT**, ODT, DOC, HTML, MD, EPUB | LibreOffice · Pandoc |
| TXT (.txt, .text, .log) | **PDF**, **DOCX**, ODT, RTF, DOC, HTML, MD, EPUB | LibreOffice · Pandoc |
| MD (.md, .markdown, .mdown) | **HTML**, **DOCX**, **PDF**, ODT, RTF, EPUB, TXT, DOC | LibreOffice · Pandoc |
| HTML (.html, .htm, .xhtml) | **PDF**, **DOCX**, **MD**, TXT, ODT, RTF, EPUB, DOC | LibreOffice · Pandoc |

## Таблицы и данные

| Из | Во что | Движок |
|---|---|---|
| XLSX (.xlsx, .xlsm) | **CSV**, **PDF**, **JSON**, ODS, XLS, HTML | встроено · LibreOffice |
| XLS (.xls) | **CSV**, **PDF**, **JSON**, **XLSX**, ODS, HTML | встроено · LibreOffice |
| ODS (.ods) | **CSV**, **PDF**, **JSON**, **XLSX**, XLS, HTML | встроено · LibreOffice |
| CSV (.csv) | **XLSX**, **JSON**, **PDF**, ODS, XLS, TSV, HTML | встроено · LibreOffice |
| TSV (.tsv, .tab) | **XLSX**, **JSON**, **PDF**, **CSV**, ODS, XLS, HTML | встроено · LibreOffice |
| JSON (.json) | **CSV**, **XLSX**, ODS | встроено · LibreOffice |

## Презентации

| Из | Во что | Движок |
|---|---|---|
| PPTX (.pptx, .ppsx) | **PDF**, **PNG (слайды)**, **JPG (слайды)**, ODP, PPT | LibreOffice · Poppler |
| PPT (.ppt, .pps) | **PDF**, **PNG (слайды)**, **JPG (слайды)**, **PPTX**, ODP | LibreOffice · Poppler |
| ODP (.odp) | **PDF**, **PNG (слайды)**, **JPG (слайды)**, **PPTX**, PPT | LibreOffice · Poppler |

## Электронные книги

| Из | Во что | Движок |
|---|---|---|
| EPUB (.epub) | **PDF**, **FB2**, **DOCX**, TXT, HTML, MOBI, AZW3 | Pandoc · Calibre |
| FB2 (.fb2) | **EPUB**, **PDF**, **DOCX**, TXT, HTML, MOBI, AZW3 | Pandoc · Calibre |
| MOBI (.mobi, .prc) | **EPUB**, **PDF**, **FB2**, **DOCX**, TXT, HTML, AZW3 | Pandoc · Calibre |
| AZW3 (.azw3, .azw) | **EPUB**, **PDF**, **FB2**, **DOCX**, TXT, HTML, MOBI | Pandoc · Calibre |

## Архивы

| Из | Во что | Движок |
|---|---|---|
| ZIP (.zip) | **распаковать**, 7Z, TAR.GZ | bsdtar · 7-Zip |
| 7Z (.7z) | **распаковать**, ZIP, TAR.GZ | bsdtar · 7-Zip |
| TAR.GZ (.tar.gz, .tgz) | **распаковать**, ZIP, 7Z | bsdtar · 7-Zip |
| TAR.BZ2 (.tar.bz2, .tbz2, .tbz) | **распаковать**, ZIP, 7Z, TAR.GZ | bsdtar · 7-Zip |
| TAR.XZ (.tar.xz, .txz) | **распаковать**, ZIP, 7Z, TAR.GZ | bsdtar · 7-Zip |
| TAR (.tar) | **распаковать**, ZIP, 7Z, TAR.GZ | bsdtar · 7-Zip |
| RAR (.rar) | **распаковать**, ZIP, 7Z, TAR.GZ | bsdtar · 7-Zip |

## Папки

| Из | Во что | Движок |
|---|---|---|
| Папка (—) | **ZIP**, **7Z**, **TAR.GZ** | bsdtar · 7-Zip |

## Любой другой файл

| Из | Во что | Движок |
|---|---|---|
| Файл (—) | ZIP, 7Z, TAR.GZ | bsdtar · 7-Zip |

Итого: **68 входных форматов** и **757 пар «из → в»** (вместе с упаковкой в архивы).

Пометки о движках: «встроено» — работает без внешних программ (CSV/JSON/TSV). LibreOffice и Pandoc ставятся по кнопке, когда понадобятся. Calibre нужен только для MOBI/AZW3.
