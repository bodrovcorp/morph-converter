#!/usr/bin/env python3
"""Создаёт набор тестовых файлов каждого поддерживаемого типа.

Имена и папка содержат кириллицу и пробелы — это проверка крайнего случая «на всём наборе».
Используются настоящие движки: FFmpeg, ImageMagick, LibreOffice, Pandoc + python-docx/pptx, openpyxl.
Файлы, которые нечем создать на этой машине (HEIC, RAW кроме DNG, MOBI, 7Z, RAR), пропускаются
с пояснением — тест сообщит о них как «нет образца».

    python3 tests/make_fixtures.py [ПАПКА]   (по умолчанию tests/fixtures/out)
"""
import json, os, shutil, struct, subprocess, sys, tarfile, zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.abspath(sys.argv[1]) if len(sys.argv) > 1 else os.path.join(HERE, "fixtures", "out", "образцы с пробелами")
NAME = "Пример файла"
skipped = []


def p(ext):
    return os.path.join(OUT, f"{NAME}.{ext}")


def sh(*cmd, cwd=None):
    r = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True)
    if r.returncode != 0:
        raise RuntimeError(f"{cmd[0]}: {r.stderr[-400:]}")


def have(tool):
    return shutil.which(tool) is not None


def magick():
    return "magick" if have("magick") else "convert"


def try_(label, fn):
    try:
        fn()
    except Exception as e:  # noqa
        skipped.append(f"{label}: {e}")


def images():
    m = magick()
    # PNG с прозрачностью и надписью — основа для остальных
    base = p("png")
    sh(m, "-size", "640x420", "gradient:#2b4fe0-#f2c46d", "(", "-size", "640x420", "xc:none", "-fill", "#ffffff80",
       "-draw", "circle 320,210 320,60", ")", "-composite", "-fill", "#141416", "-pointsize", "36",
       "-gravity", "center", "-annotate", "+0+0", "Morph 2026", base)
    sh(m, base, "-alpha", "set", "-channel", "A", "-evaluate", "set", "85%", "+channel", base)
    sh(m, base, "-background", "white", "-alpha", "remove", "-quality", "90", p("jpg"))
    sh(m, base, p("bmp"))
    sh(m, base, p("tiff"))
    sh(m, base, "-resize", "64x64", p("ico"))
    sh(m, base, p("psd"))
    sh(m, base, p("tga"))
    try_("webp", lambda: sh("ffmpeg", "-y", "-loglevel", "error", "-i", base, "-c:v", "libwebp", p("webp")))
    try_("avif", lambda: sh("ffmpeg", "-y", "-loglevel", "error", "-i", p("jpg"), "-c:v", "libaom-av1", "-still-picture", "1",
                            "-cpu-used", "8", "-vf", "scale=640:420", p("avif")))
    # Анимированный GIF (6 кадров)
    sh("ffmpeg", "-y", "-loglevel", "error", "-f", "lavfi", "-i", "testsrc=size=320x200:rate=6:duration=1", p("gif"))
    with open(p("svg"), "w", encoding="utf-8") as f:
        f.write('<svg xmlns="http://www.w3.org/2000/svg" width="200" height="120" viewBox="0 0 200 120">'
                '<rect width="200" height="120" rx="16" fill="#2b4fe0"/><circle cx="60" cy="60" r="30" fill="#f2c46d"/>'
                '<text x="100" y="70" font-size="22" fill="#fff" font-family="sans-serif">Тест</text></svg>')
    try_("dng", make_dng)
    skipped.append("heic: на этой машине нет кодировщика HEIC (чтение проверяется в ImageMagick через libheif)")
    skipped.append("cr2/cr3/nef/arw/orf/rw2/raf: нет образцов RAW-файлов (их обрабатывает тот же модуль, что и DNG)")


def make_dng():
    """Минимальный корректный DNG: 16-битный байер RGGB 64×48 + обязательные теги."""
    w, h = 64, 48
    pix = bytearray()
    for y in range(h):
        for x in range(w):
            even_r, even_c = y % 2 == 0, x % 2 == 0
            v = 3000 + 40 * x if even_r and even_c else (2000 + 30 * y if not even_r and not even_c else 2500)
            pix += struct.pack("<H", min(v, 16000))
    entries = []

    def tag(t, typ, count, value):
        entries.append((t, typ, count, value))
    # value: bytes (данные) — разместим после IFD при необходимости
    def short(v): return struct.pack("<H", v) + b"\0\0"
    def long_(v): return struct.pack("<I", v)
    def rationals(vals, signed=True):
        out = b""
        for num, den in vals:
            out += struct.pack("<ii" if signed else "<II", num, den)
        return out

    data_blobs = []
    tag(254, 4, 1, long_(0))                 # NewSubFileType: основное изображение
    tag(256, 4, 1, long_(w))
    tag(257, 4, 1, long_(h))
    tag(258, 3, 1, short(16))                # BitsPerSample
    tag(259, 3, 1, short(1))                 # Compression: нет
    tag(262, 3, 1, short(32803))             # Photometric: CFA
    tag(271, 2, 6, b"Morph\0")               # Make
    tag(272, 2, 5, b"Test\0")                # Model
    tag(273, 4, 1, None)                     # StripOffsets — заполним
    tag(274, 3, 1, short(1))                 # Orientation
    tag(277, 3, 1, short(1))                 # SamplesPerPixel
    tag(278, 4, 1, long_(h))                 # RowsPerStrip
    tag(279, 4, 1, long_(len(pix)))          # StripByteCounts
    tag(284, 3, 1, short(1))                 # PlanarConfig
    tag(33421, 3, 2, struct.pack("<HH", 2, 2))          # CFARepeatPatternDim
    tag(33422, 1, 4, bytes([0, 1, 1, 2]))               # CFAPattern RGGB
    tag(50706, 1, 4, bytes([1, 4, 0, 0]))               # DNGVersion
    tag(50707, 1, 4, bytes([1, 1, 0, 0]))               # DNGBackwardVersion
    tag(50708, 2, 11, b"Morph Test\0")                  # UniqueCameraModel
    tag(50714, 4, 1, long_(0))                          # BlackLevel
    tag(50717, 4, 1, long_(16383))                      # WhiteLevel
    cm = [(19, 10), (-6, 10), (-3, 10), (-4, 10), (14, 10), (1, 10), (0, 10), (2, 10), (7, 10)]
    tag(50721, 10, 9, rationals(cm))                    # ColorMatrix1
    tag(50778, 3, 1, short(21))                         # CalibrationIlluminant1: D65
    tag(50728, 5, 3, rationals([(1, 2), (1, 1), (1, 2)], signed=False))  # AsShotNeutral
    entries.sort(key=lambda e: e[0])
    n = len(entries)
    ifd_off = 8
    ifd_size = 2 + n * 12 + 4
    extra_off = ifd_off + ifd_size
    extra = b""
    body = b""
    strip_index = None
    for i, (t, typ, count, val) in enumerate(entries):
        if t == 273:
            strip_index = i
            body += struct.pack("<HHI", t, typ, count) + b"\0\0\0\0"
            continue
        if len(val) <= 4:
            body += struct.pack("<HHI", t, typ, count) + val.ljust(4, b"\0")
        else:
            off = extra_off + len(extra)
            extra += val + (b"\0" if len(val) % 2 else b"")
            body += struct.pack("<HHI", t, typ, count) + struct.pack("<I", off)
    pix_off = extra_off + len(extra)
    body = bytearray(body)
    body[strip_index * 12 + 8: strip_index * 12 + 12] = struct.pack("<I", pix_off)
    with open(p("dng"), "wb") as f:
        f.write(b"II*\0" + struct.pack("<I", ifd_off) + struct.pack("<H", n) + bytes(body) + b"\0\0\0\0" + extra + bytes(pix))


def media():
    ff = ["ffmpeg", "-y", "-loglevel", "error"]
    src = ["-f", "lavfi", "-i", "testsrc2=size=640x360:rate=25:duration=3", "-f", "lavfi", "-i", "sine=frequency=440:duration=3"]
    sh(*ff, *src, "-c:v", "libx264", "-pix_fmt", "yuv420p", "-c:a", "aac", "-shortest", p("mp4"))
    sh(*ff, *src, "-c:v", "libx264", "-pix_fmt", "yuv420p", "-c:a", "aac", "-shortest", p("mov"))
    sh(*ff, *src, "-c:v", "mpeg4", "-c:a", "libvorbis", "-shortest", p("mkv"))  # не перепаковывается в MP4 — перекодирование
    sh(*ff, *src, "-c:v", "mpeg4", "-c:a", "libmp3lame", "-shortest", p("avi"))
    sh(*ff, *src, "-c:v", "libvpx-vp9", "-deadline", "realtime", "-c:a", "libopus", "-shortest", p("webm"))
    sh(*ff, *src, "-c:v", "wmv2", "-c:a", "wmav2", "-shortest", p("wmv"))
    sh(*ff, *src, "-c:v", "flv1", "-c:a", "libmp3lame", "-ar", "44100", "-shortest", p("flv"))
    sh(*ff, *src, "-c:v", "mpeg2video", "-c:a", "mp2", "-shortest", "-f", "mpeg", p("mpg"))
    sh(*ff, *src, "-c:v", "libx264", "-pix_fmt", "yuv420p", "-c:a", "aac", "-shortest", "-f", "mpegts", p("ts"))
    sh(*ff, "-f", "lavfi", "-i", "testsrc2=size=352x288:rate=15:duration=3", "-f", "lavfi", "-i", "sine=duration=3",
       "-c:v", "libx264", "-pix_fmt", "yuv420p", "-c:a", "aac", "-ar", "16000", "-ac", "1", "-shortest", p("3gp"))
    a = ["-f", "lavfi", "-i", "sine=frequency=330:duration=4", "-metadata", "title=Тестовая мелодия"]
    sh(*ff, *a, "-c:a", "libmp3lame", p("mp3"))
    sh(*ff, *a, p("wav"))
    sh(*ff, *a, p("flac"))
    sh(*ff, *a, "-c:a", "aac", p("m4a"))
    sh(*ff, *a, "-c:a", "aac", "-f", "adts", p("aac"))
    sh(*ff, *a, "-c:a", "libvorbis", p("ogg"))
    sh(*ff, *a, "-c:a", "libopus", p("opus"))
    sh(*ff, *a, "-c:a", "wmav2", p("wma"))
    sh(*ff, *a, "-c:a", "pcm_s16be", p("aiff"))
    try_("amr", lambda: sh(*ff, *a, "-ar", "8000", "-ac", "1", "-c:a", "libopencore_amrnb", p("amr")))


RU_TEXT = ("Привет! Это тестовый документ Morph.\n\nЕкатеринбург, ноябрь 2026. "
           "Проверяем кириллицу, «ёлочки» — и длинное тире. Съешь же ещё этих мягких французских булок, да выпей чаю.\n")


def documents():
    import docx
    d = docx.Document()
    d.add_heading("Отчёт за квартал", 0)
    d.add_paragraph(RU_TEXT)
    t = d.add_table(rows=3, cols=2)
    for i, (a, b) in enumerate([("Город", "Сумма"), ("Москва", "1 500"), ("Екатеринбург", "2 250")]):
        t.cell(i, 0).text, t.cell(i, 1).text = a, b
    d.add_page_break()
    d.add_heading("Вторая страница", 1)
    d.add_paragraph("Текст второй страницы.")
    d.save(p("docx"))
    lo = ["soffice", "--headless", "--norestore", f"-env:UserInstallation=file:///tmp/morph-fixture-lo"]
    for ext, flt in [("doc", "doc:MS Word 97"), ("odt", "odt"), ("rtf", "rtf"), ("pdf", "pdf")]:
        sh(*lo, "--convert-to", flt, "--outdir", OUT, p("docx"))
    # TXT в Windows-1251 — проверка «без кракозябр»
    with open(p("txt"), "wb") as f:
        f.write(RU_TEXT.replace("\n", "\r\n").encode("cp1251"))
    md = ("# Заголовок Markdown\n\n" + RU_TEXT + "\n## Таблица\n\n| Город | Сумма |\n|---|---|\n| Москва | 1500 |\n"
          "| Екатеринбург | 2250 |\n\n```python\nprint('привет')\n```\n\n- пункт один\n- пункт **два**\n")
    with open(p("md"), "w", encoding="utf-8") as f:
        f.write(md)
    sh("pandoc", p("md"), "-s", "--metadata", "title=Пример", "-o", p("html"))
    sh("pandoc", p("md"), "-s", "--metadata", "title=Пример книги", "-o", p("epub"))
    sh("pandoc", p("md"), "-s", "--metadata", "title=Пример книги", "-t", "fb2", "-o", p("fb2"))
    skipped.append("mobi/azw3: нужен Calibre — на этой машине его нет")


def sheets():
    import openpyxl
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Продажи"
    ws.append(["Город", "Сумма", "Дата"])
    ws.append(["Москва", 1500.5, "2026-11-01"])
    ws.append(["Екатеринбург", 2250, "2026-11-02"])
    ws2 = wb.create_sheet("Итоги")
    ws2.append(["Всего", 3750.5])
    wb.save(p("xlsx"))
    lo = ["soffice", "--headless", "--norestore", f"-env:UserInstallation=file:///tmp/morph-fixture-lo"]
    sh(*lo, "--convert-to", "xls:MS Excel 97", "--outdir", OUT, p("xlsx"))
    sh(*lo, "--convert-to", "ods", "--outdir", OUT, p("xlsx"))
    # CSV: Windows-1251, разделитель «;», десятичная запятая — как выгружает российский Excel
    rows = ["Город;Сумма;Комментарий", "Москва;1500,5;\"Офис; центр\"", "Екатеринбург;2250;Филиал «Урал»", "Казань;0,75;"]
    with open(p("csv"), "wb") as f:
        f.write(("\r\n".join(rows) + "\r\n").encode("cp1251"))
    with open(p("tsv"), "w", encoding="utf-8") as f:
        f.write("Город\tСумма\nМосква\t1500\nЕкатеринбург\t2250\n")
    data = [{"id": 1, "город": "Москва", "гео": {"широта": 55.75}, "теги": ["столица"]},
            {"id": 2, "город": "Екатеринбург", "гео": {"широта": 56.84}, "теги": []}]
    with open(p("json"), "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


def slides():
    from pptx import Presentation
    from pptx.util import Inches, Pt
    pr = Presentation()
    for i, title in enumerate(["Морф: конвертер", "Что внутри", "Итоги"]):
        s = pr.slides.add_slide(pr.slide_layouts[1])
        s.shapes.title.text = title
        s.placeholders[1].text = f"Слайд {i + 1}: локально, без интернета"
    pr.save(p("pptx"))
    lo = ["soffice", "--headless", "--norestore", f"-env:UserInstallation=file:///tmp/morph-fixture-lo"]
    sh(*lo, "--convert-to", "ppt:MS PowerPoint 97", "--outdir", OUT, p("pptx"))
    sh(*lo, "--convert-to", "odp", "--outdir", OUT, p("pptx"))


def archives():
    files = {"Документы/Заметка.txt": "Привет из архива\n", "Фото/описание.md": "# Фото\n", "readme.txt": "test\n"}
    with zipfile.ZipFile(p("zip"), "w", zipfile.ZIP_DEFLATED) as z:
        for n, c in files.items():
            z.writestr(n, c)
    src = os.path.join(OUT, "_tmp_tree")
    for n, c in files.items():
        os.makedirs(os.path.dirname(os.path.join(src, n)) or src, exist_ok=True)
        with open(os.path.join(src, n), "w", encoding="utf-8") as f:
            f.write(c)
    for ext, mode in [("tar", "w"), ("tar.gz", "w:gz"), ("tar.bz2", "w:bz2"), ("tar.xz", "w:xz")]:
        with tarfile.open(p(ext), mode) as t:
            for n in files:
                t.add(os.path.join(src, n), arcname=n)
    shutil.rmtree(src)
    # Папка как вход (упаковка)
    folder = os.path.join(OUT, "Папка с файлами")
    os.makedirs(folder, exist_ok=True)
    for n, c in files.items():
        os.makedirs(os.path.dirname(os.path.join(folder, n)) or folder, exist_ok=True)
        with open(os.path.join(folder, n), "w", encoding="utf-8") as f:
            f.write(c)
    skipped.append("7z/rar: на этой машине нет 7-Zip/bsdtar, образцы не созданы")


if __name__ == "__main__":
    shutil.rmtree(OUT, ignore_errors=True)
    os.makedirs(OUT, exist_ok=True)
    for step in (images, media, documents, sheets, slides, archives):
        try_(step.__name__, step)
    made = sorted(os.listdir(OUT))
    print(f"Создано образцов: {len(made)} в {OUT}")
    for s in skipped:
        print("  пропущено —", s)
