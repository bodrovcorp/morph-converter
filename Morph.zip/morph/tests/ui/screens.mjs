// Снимки интерфейса во всех стилях/темах + проверка, что в консоли нет ошибок.
import { chromium } from "playwright";
const base = process.env.MORPH_UI || "http://localhost:8765";
const out = process.argv[2] || "/tmp/shots";
const browser = await chromium.launch();
const errors = [];
for (const style of ["glass", "minimal"]) {
  for (const theme of ["light", "dark"]) {
    const page = await browser.newPage({ viewport: { width: 1780, height: 760 }, deviceScaleFactor: 1 });
    page.on("console", (m) => m.type() === "error" && errors.push(`${style}/${theme}: ${m.text()}`));
    page.on("pageerror", (e) => errors.push(`${style}/${theme}: ${e.message}`));
    await page.goto(`${base}/preview/index.html?style=${style}&theme=${theme}&slow=600`);
    await page.waitForTimeout(1800);
    await page.screenshot({ path: `${out}/preview-${style}-${theme}.png` });
    await page.close();
  }
}
await browser.close();
console.log(errors.length ? "ОШИБКИ:\n" + errors.join("\n") : "Ошибок в консоли нет");
