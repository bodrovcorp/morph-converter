// Поведенческие UI-тесты на имитации бэкенда: клавиатура, поиск, избранное, конфликт имён,
// отсутствующий движок, отмена, настройки. Запуск: node behavior.mjs
import { chromium } from "playwright";
const base = process.env.MORPH_UI || "http://localhost:8765";
const browser = await chromium.launch();
let failed = 0, passed = 0;
async function test(name, fn) {
  const page = await browser.newPage({ viewport: { width: 420, height: 700 } });
  const errs = [];
  page.on("pageerror", (e) => errs.push(e.message));
  try {
    await fn(page);
    if (errs.length) throw new Error("ошибки JS: " + errs.join("; "));
    passed++;
    console.log("✓", name);
  } catch (e) {
    failed++;
    console.log("✗", name, "—", e.message);
  }
  await page.close();
}
const eq = (a, b, m) => { if (JSON.stringify(a) !== JSON.stringify(b)) throw new Error(`${m}: ${JSON.stringify(a)} ≠ ${JSON.stringify(b)}`); };
const ok = (c, m) => { if (!c) throw new Error(m); };
const selectedText = (p) => p.$eval('.m-row[aria-selected="true"]', (e) => e.textContent.replace(/\s+/g, " ").trim());
const menu = async (p, q = "") => { await p.goto(`${base}/menu.html?${q}`); await p.waitForSelector(".m-row"); };

await test("меню открывается, фокус в поиске, первый — избранный JPG", async (p) => {
  await menu(p);
  eq(await p.evaluate(() => document.activeElement.id), "q", "фокус");
  ok((await selectedText(p)).startsWith("JPG"), "первая строка JPG");
  ok((await p.$$eval(".m-label", (l) => l.map((x) => x.textContent))).join("|").includes("Избранное"), "группа избранного");
});
await test("стрелки двигают выбор, Enter конвертирует выбранное", async (p) => {
  await menu(p);
  await p.keyboard.press("ArrowDown");
  ok((await selectedText(p)).startsWith("PDF"), "вторая строка PDF");
  await p.keyboard.press("ArrowDown");
  await p.keyboard.press("Enter");
  await p.waitForFunction(() => window.__lastConvert);
  eq(await p.evaluate(() => window.__lastConvert.target), "png", "цель");
  ok(await p.evaluate(() => window.__menuHidden === 1), "меню закрылось");
});
await test("поиск при наборе + русская раскладка («озп» → jpg)", async (p) => {
  await menu(p);
  await p.keyboard.type("озп");
  ok((await selectedText(p)).startsWith("JPG"), "нашёлся JPG");
  await p.fill("#q", "");
  await p.keyboard.type("tif");
  ok((await selectedText(p)).startsWith("TIFF"), "нашёлся TIFF из «Ещё»");
});
await test("Esc: сначала очищает поиск, потом закрывает меню", async (p) => {
  await menu(p);
  await p.keyboard.type("png");
  await p.keyboard.press("Escape");
  eq(await p.inputValue("#q"), "", "поиск очищен");
  ok(!(await p.evaluate(() => window.__menuHidden)), "ещё открыто");
  await p.keyboard.press("Escape");
  ok(await p.evaluate(() => window.__menuHidden === 1), "закрыто");
});
await test("клик мимо меню закрывает его", async (p) => {
  await menu(p);
  await p.mouse.click(400, 690);
  ok(await p.evaluate(() => window.__menuHidden === 1), "закрыто");
});
await test("Ctrl+2 сразу конвертирует вторую строку", async (p) => {
  await menu(p);
  await p.keyboard.press("Control+2");
  await p.waitForFunction(() => window.__lastConvert);
  eq(await p.evaluate(() => window.__lastConvert.target), "pdf", "цель");
});
await test("Tab — к параметрам, параметры уходят в конвертацию", async (p) => {
  await menu(p);
  await p.keyboard.press("Tab");
  eq(await p.evaluate(() => document.activeElement.dataset.opt), "quality", "фокус на качестве");
  await p.$eval('[data-opt="quality"]', (e) => { e.value = 60; e.dispatchEvent(new Event("input", { bubbles: true })); });
  await p.click('[data-opt="stripMetadata"]');
  await p.click("#go");
  await p.waitForFunction(() => window.__lastConvert);
  const c = await p.evaluate(() => window.__lastConvert);
  eq(c.target, "jpg", "цель");
});
await test("«Ещё N форматов» раскрывается с подзаголовками", async (p) => {
  await menu(p);
  await p.click(".m-morebtn");
  const labels = await p.$$eval(".m-label", (l) => l.map((x) => x.textContent));
  ok(labels.some((l) => l.startsWith("Ещё · ")), "подзаголовки по типу: " + labels.join(","));
});
await test("звёздочка добавляет в избранное (Ctrl+D)", async (p) => {
  await menu(p);
  await p.keyboard.press("ArrowDown");
  await p.keyboard.press("ArrowDown"); // PNG
  await p.keyboard.press("Control+d");
  const favs = await p.evaluate(() => window.__menuState.settings.favorites);
  ok(favs.includes("png"), "png в избранном: " + favs);
});
await test("конфликт имён в режиме «Спросить»", async (p) => {
  await p.goto(`${base}/menu.html`);
  await p.evaluate(() => { const s = JSON.parse(sessionStorage.getItem("morph-mock-settings") || "null"); });
  await p.evaluate(async () => { const { api } = await import("./js/bridge.js"); const s = await api.invoke("get_settings"); s.conflict = "ask"; await api.invoke("set_settings", { settings: s }); });
  await p.reload();
  await p.waitForSelector(".m-row");
  await p.keyboard.press("Enter");
  await p.waitForSelector(".m-conflict");
  ok((await p.textContent(".m-conflict")).includes("IMG_2048.jpg"), "текст конфликта");
  await p.click('[data-c="suffix"]');
  await p.waitForFunction(() => window.__lastConvert);
  eq(await p.evaluate(() => window.__lastConvert.conflict), "suffix", "выбор пользователя");
});
await test("строка без движка ведёт в Настройки → Компоненты", async (p) => {
  await menu(p, "sample=docx");
  await p.keyboard.type("odt");
  ok((await p.textContent('.m-row[aria-selected="true"]')).includes("нужен LibreOffice"), "пометка");
  await p.keyboard.press("Enter");
  eq(await p.evaluate(() => window.__openSettings), "engines", "открыт раздел");
});
await test("несколько PDF → «Объединить» первым", async (p) => {
  await menu(p, "sample=pdf");
  ok((await p.textContent(".m-head")).includes("2 файла"), "заголовок про 2 файла");
  ok((await selectedText(p)).includes("Объединить") || (await p.textContent("#list")).includes("Объединить"), "есть объединение");
});
await test("прогресс: отмена задачи и «Подробнее» у ошибки", async (p) => {
  await p.setViewportSize({ width: 440, height: 700 });
  await p.goto(`${base}/progress.html?slow=600`);
  await p.waitForSelector("[data-cancel]");
  const first = await p.$eval("[data-cancel]", (b) => b.dataset.cancel);
  await p.click(`[data-cancel="${first}"]`);
  await p.waitForFunction(() => document.body.textContent.includes("Отменено"));
  await p.click("[data-details]");
  await p.waitForSelector("pre.details");
  ok((await p.textContent("pre.details")).includes("xref"), "технические подробности");
});
await test("настройки: переключение стиля и темы применяется сразу", async (p) => {
  await p.setViewportSize({ width: 900, height: 640 });
  await p.goto(`${base}/settings.html?tab=look`);
  await p.click('[data-seg="appearance.style"][data-val="minimal"]');
  eq(await p.evaluate(() => document.documentElement.dataset.style), "minimal", "стиль");
  await p.click('[data-seg="appearance.theme"][data-val="dark"]');
  eq(await p.evaluate(() => document.documentElement.dataset.theme), "dark", "тема");
  await p.click('[data-seg="appearance.style"][data-val="glass"]');
  await p.click('[data-sw="appearance.reduceTransparency"]');
  eq(await p.evaluate(() => document.documentElement.dataset.reduceTransparency), "true", "уменьшить прозрачность");
  eq(await p.evaluate(() => getComputedStyle(document.documentElement).getPropertyValue("--blur").trim()), "0px", "без размытия");
});
await test("настройки: запись горячей клавиши и отказ на занятое сочетание", async (p) => {
  await p.setViewportSize({ width: 900, height: 640 });
  await p.goto(`${base}/settings.html?tab=hotkey`);
  await p.click("#rec");
  await p.keyboard.press("Meta+Shift+KeyS");
  await p.waitForFunction(() => document.querySelector("#hkState").textContent.includes("занято"));
  await p.click("#rec");
  await p.keyboard.press("Control+Alt+KeyK");
  await p.waitForFunction(async () => { const { api } = await import("./js/bridge.js"); return (await api.invoke("get_settings")).hotkey === "Control+Alt+K"; });
});
await test("настройки: установка компонента", async (p) => {
  await p.setViewportSize({ width: 900, height: 640 });
  await p.goto(`${base}/settings.html?tab=engines&highlight=libreoffice`);
  await p.click('[data-install="libreoffice"]');
  await p.waitForFunction(() => !document.querySelector('[data-install="libreoffice"]'), null, { timeout: 5000 });
  ok((await p.textContent("#eng-libreoffice")).includes("Установлен"), "статус обновился");
});
await browser.close();
console.log(`\nUI: ${passed} прошло, ${failed} упало`);
process.exit(failed ? 1 : 0);
