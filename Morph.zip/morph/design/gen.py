"""Генерирует артборды концептов Morph для дизайн-холста (2 стиля x 3 экрана)."""
import json, os, datetime

ROOT = os.path.join(os.path.dirname(__file__), "canvas")
WALL = "/_blob/920b5d9e1726874a1ea5d3dd02bc4753"
W, H = 960, 660

MIN = dict(
    name="Минимализм", key="min",
    win_bg="#FFFFFF", win_border="1px solid rgba(20,20,24,0.08)",
    win_shadow="0 1px 2px rgba(15,15,20,0.06), 0 18px 48px rgba(15,15,20,0.24)",
    win_radius="12px", win_fx="",
    text="#141416", muted="#5C5C66", faint="#686872",
    hair="#ECECEF", accent="#2B4FE0", on_accent="#FFFFFF",
    sel_bg="#EDF0FE", sel_text="#1D3BC2", sel_shadow="none",
    row_radius="7px", input_bg="#F4F4F6", input_border="1px solid #ECECEF",
    btn_radius="8px", ext_bg="#F1F1F4", ext_text="#3A3A42",
    side_bg="#FAFAFB", track_off="#DADADF", bar_bg="#EDEDF0", bar_h="4px",
    ok="#147A4B", err="#B42318", card_bg="#FFFFFF", card_border="1px solid #ECECEF",
)
GLASS = dict(
    name="Liquid Glass", key="glass",
    win_bg="rgba(246,247,251,0.60)", win_border="1px solid rgba(255,255,255,0.62)",
    win_shadow="inset 0 1px 0 rgba(255,255,255,0.9), inset 0 0 0 1px rgba(255,255,255,0.18), 0 24px 70px rgba(8,14,40,0.40)",
    win_radius="22px", win_fx="backdrop-filter: blur(30px) saturate(1.8); -webkit-backdrop-filter: blur(30px) saturate(1.8);",
    text="#0C0F16", muted="#353B48", faint="#3F4552",
    hair="rgba(12,15,22,0.09)", accent="#1A52D4", on_accent="#FFFFFF",
    sel_bg="rgba(255,255,255,0.80)", sel_text="#1343B5",
    sel_shadow="inset 0 1px 0 rgba(255,255,255,1), 0 6px 16px rgba(20,30,70,0.14)",
    row_radius="12px", input_bg="rgba(255,255,255,0.55)", input_border="1px solid rgba(255,255,255,0.75)",
    btn_radius="999px", ext_bg="rgba(255,255,255,0.62)", ext_text="#262B36",
    side_bg="rgba(255,255,255,0.28)", track_off="rgba(12,15,22,0.18)", bar_bg="rgba(12,15,22,0.10)", bar_h="6px",
    ok="#0F6B40", err="#A01E12", card_bg="rgba(255,255,255,0.50)", card_border="1px solid rgba(255,255,255,0.7)",
)

HEAD = """<!doctype html>
<html lang="ru">
<head>
<meta charset="utf-8">
<title>%TITLE%</title>
<script src="./support.js"></script>
</head>
<body>
<x-dc>
<helmet>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&amp;family=JetBrains+Mono:wght@500;600&amp;display=swap" rel="stylesheet">
<style>
body{margin:0}
a{color:%ACCENT%}a:hover{color:%TEXT%}
input::placeholder{color:%FAINT%}
button{font:inherit}
</style>
</helmet>
"""
TAIL = """</x-dc>
<script type="text/x-dc" data-dc-script data-props='{"$preview":{"width":%W%,"height":%H%}}'>
%JS%
</script>
</body>
</html>
"""

def sub(s, t, extra=None):
    d = {k.upper(): v for k, v in t.items()}
    if extra:
        d.update(extra)
    for k, v in d.items():
        s = s.replace("%" + k + "%", str(v))
    return s

WINDOW = ("background: %WIN_BG%; border: %WIN_BORDER%; box-shadow: %WIN_SHADOW%; "
          "border-radius: %WIN_RADIUS%; %WIN_FX% color: %TEXT%; font-family: Inter, system-ui, sans-serif;")

def stage_open():
    return ('<div style="position: relative; width: %dpx; height: %dpx; overflow: hidden; font-family: Inter, system-ui, sans-serif;">\n'
            '<img src="%s" alt="" style="position: absolute; inset: 0; width: 100%%; height: 100%%; object-fit: cover;">\n') % (W, H, WALL)

ICON_SEARCH = '<svg aria-hidden="true" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="11" cy="11" r="7"></circle><path d="M20 20l-3.5-3.5"></path></svg>'
ICON_X = '<svg aria-hidden="true" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"></path></svg>'
ICON_CHECK = '<svg aria-hidden="true" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12.5l4.5 4.5L19 7.5"></path></svg>'
ICON_WARN = '<svg aria-hidden="true" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M12 3l9.5 17h-19z"></path><path d="M12 10v4.5M12 17.5v.5"></path></svg>'
ICON_CHEV = '<svg aria-hidden="true" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 6l6 6-6 6"></path></svg>'
ICON_FILE = '<svg aria-hidden="true" width="30" height="36" viewBox="0 0 30 36" fill="none"><path d="M4 1.5h15l9 9V32a2.5 2.5 0 0 1-2.5 2.5h-21A2.5 2.5 0 0 1 2 32V4a2.5 2.5 0 0 1 2-2.5z" fill="%EXT_BG%" stroke="%FAINT%" stroke-width="1.2"></path><path d="M19 1.5V9a1.5 1.5 0 0 0 1.5 1.5H28" stroke="%FAINT%" stroke-width="1.2"></path><circle cx="11" cy="19" r="2.6" fill="%ACCENT%"></circle><path d="M6 29l6-6 4 4 3-3 5 5" stroke="%ACCENT%" stroke-width="1.6" stroke-linejoin="round" fill="none"></path></svg>'
CURSOR = '<svg aria-hidden="true" width="20" height="26" viewBox="0 0 20 26" style="position: absolute; left: 412px; top: 96px;"><path d="M2 2l15 12.5-6.6.6 3.9 8.3-2.8 1.3-3.8-8.4L2 20.5z" fill="#111" stroke="#fff" stroke-width="1.5" stroke-linejoin="round"></path></svg>'

# ---------- Finder mock (контекст: меню всплывает у курсора) ----------
def finder():
    files = [("HEIC", "IMG_2048.HEIC", "#C2410C", True), ("MOV", "Отпуск_2026.mov", "#6D28D9", False),
             ("DOCX", "Отчёт за квартал.docx", "#1D4ED8", False), ("XLSX", "Бюджет 2026.xlsx", "#15803D", False),
             ("PPTX", "Лекция 3.pptx", "#C2410C", False), ("PDF", "scan_old.pdf", "#B91C1C", False)]
    tiles = []
    for ext, name, col, sel in files:
        nm = ('<span style="font-size: 11.5px; line-height: 1.3; text-align: center; padding: 1px 6px; border-radius: 4px; '
              + ('background: #2563EB; color: #FFFFFF;' if sel else 'color: #1F2937;') + '">' + name + '</span>')
        tiles.append(
            '<div style="display: flex; flex-direction: column; align-items: center; gap: 6px; width: 104px;">'
            '<div style="width: 64px; height: 64px; border-radius: 8px; display: flex; align-items: center; justify-content: center; '
            + ('background: rgba(0,0,0,0.07);' if sel else '') + '">'
            '<div style="width: 44px; height: 54px; background: #FFFFFF; border: 1px solid #D4D4D8; border-radius: 4px; display: flex; align-items: flex-end; justify-content: center; padding-bottom: 7px; box-sizing: border-box; box-shadow: 0 1px 2px rgba(0,0,0,0.08);">'
            '<span style="font-family: \'JetBrains Mono\', monospace; font-size: 9px; font-weight: 600; color: ' + col + ';">' + ext + '</span></div></div>'
            + nm + '</div>')
    side = "".join('<div style="font-size: 12px; color: #374151; padding: 4px 8px; border-radius: 5px;%s">%s</div>'
                   % (" background: rgba(0,0,0,0.07);" if i == 0 else "", n)
                   for i, n in enumerate(["Загрузки", "Документы", "Рабочий стол", "Фото"]))
    return ('<div style="position: absolute; left: 36px; top: 40px; width: 560px; height: 430px; background: #FFFFFF; border-radius: 12px; '
            'box-shadow: 0 0 0 1px rgba(0,0,0,0.12), 0 20px 50px rgba(0,0,0,0.30); display: flex; overflow: hidden;">'
            '<div style="width: 150px; background: #F3F3F5; padding: 14px 10px; box-sizing: border-box; display: flex; flex-direction: column; gap: 2px;">'
            '<div style="display: flex; gap: 7px; margin-bottom: 18px;"><span style="width: 12px; height: 12px; border-radius: 6px; background: #FF5F57;"></span><span style="width: 12px; height: 12px; border-radius: 6px; background: #FEBC2E;"></span><span style="width: 12px; height: 12px; border-radius: 6px; background: #28C840;"></span></div>'
            '<div style="font-size: 11px; font-weight: 600; color: #6B7280; padding: 0 8px 4px;">Избранное</div>' + side + '</div>'
            '<div style="flex: 1; display: flex; flex-direction: column;">'
            '<div style="height: 50px; display: flex; align-items: center; padding: 0 18px; font-size: 13px; font-weight: 600; color: #111827; border-bottom: 1px solid #ECECEF;">Загрузки</div>'
            '<div style="display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 22px 8px; padding: 22px 16px;">' + "".join(tiles) + '</div>'
            '</div></div>\n')

# ---------- Экран 1: меню выбора формата ----------
MENU_JS = r"""
class Component extends DCLogic {
  constructor(p) { super(p); this.state = { q: '', sel: 0, more: false, done: false }; }
  renderVals() {
    const T = %TOKENS%;
    const all = [
      { ext: 'JPG', d: 'Совместимо везде', g: 'fav' },
      { ext: 'PNG', d: 'Без потерь, с прозрачностью', g: 'fav' },
      { ext: 'WEBP', d: 'Лёгкий, для сайтов', g: 'pop' },
      { ext: 'AVIF', d: 'Самый компактный', g: 'pop' },
      { ext: 'PDF', d: 'Документ из фото', g: 'pop' },
      { ext: 'TIFF', d: 'Для печати и архива', g: 'pop' },
      { ext: 'GIF', d: '256 цветов', g: 'more' },
      { ext: 'BMP', d: 'Без сжатия', g: 'more' },
      { ext: 'ICO', d: 'Иконка 16–256 px', g: 'more' },
      { ext: 'PSD', d: 'Для Photoshop', g: 'more' }
    ];
    const s = this.state;
    const q = s.q.trim().toLowerCase();
    let visible;
    if (q) visible = all.filter(x => x.ext.toLowerCase().includes(q) || x.d.toLowerCase().includes(q));
    else visible = all.filter(x => x.g !== 'more' || s.more);
    const sel = Math.min(s.sel, Math.max(visible.length - 1, 0));
    const deco = (x, i) => {
      const on = i === sel;
      return Object.assign({}, x, {
        key: i < 9 ? String(i + 1) : '',
        rowStyle: 'display: flex; align-items: center; gap: 12px; width: 100%; height: 34px; padding: 0 10px; box-sizing: border-box; border: 0; cursor: pointer; text-align: left; border-radius: ' + T.row_radius + '; background: ' + (on ? T.sel_bg : 'transparent') + '; box-shadow: ' + (on ? T.sel_shadow : 'none') + '; color: ' + (on ? T.sel_text : T.text) + ';',
        extStyle: 'font-family: "JetBrains Mono", monospace; font-size: 11.5px; font-weight: 600; width: 42px; padding: 3px 0; text-align: center; border-radius: 5px; background: ' + (on ? T.accent : T.ext_bg) + '; color: ' + (on ? T.on_accent : T.ext_text) + ';',
        pick: () => this.setState({ sel: i, done: false })
      });
    };
    const rows = visible.map(deco);
    const cur = rows[sel] || null;
    return {
      q: s.q,
      searching: !!q,
      notSearching: !q,
      found: rows,
      fav: rows.filter(x => x.g === 'fav'),
      pop: rows.filter(x => x.g === 'pop'),
      more: rows.filter(x => x.g === 'more'),
      showMoreToggle: !q && !s.more,
      moreOpen: !q && s.more,
      empty: rows.length === 0,
      hasCur: !!cur,
      curExt: cur ? cur.ext : '',
      done: s.done,
      notDone: !s.done,
      openMore: () => this.setState({ more: true }),
      onInput: (e) => this.setState({ q: e.target.value, sel: 0, done: false }),
      onKey: (e) => {
        if (e.key === 'ArrowDown') { e.preventDefault(); this.setState({ sel: Math.min(sel + 1, rows.length - 1), done: false }); }
        else if (e.key === 'ArrowUp') { e.preventDefault(); this.setState({ sel: Math.max(sel - 1, 0), done: false }); }
        else if (e.key === 'Enter') { e.preventDefault(); this.setState({ done: true }); }
        else if (e.key === 'Escape') { this.setState({ q: '', sel: 0, done: false }); }
      },
      convert: () => this.setState({ done: true })
    };
  }
}
"""

def row_loop(lst):
    return ('<sc-for list="{{%s}}" as="it" hint-placeholder-count="2">'
            '<button type="button" onClick="{{it.pick}}" style="{{it.rowStyle}}">'
            '<span style="{{it.extStyle}}">{{it.ext}}</span>'
            '<span style="flex: 1; font-size: 13px;">{{it.d}}</span>'
            '<span style="font-family: \'JetBrains Mono\', monospace; font-size: 11px; color: %%FAINT%%;">{{it.key}}</span>'
            '</button></sc-for>\n') % lst

def label(t):
    return '<div style="font-size: 11px; font-weight: 600; letter-spacing: 0.04em; color: %%MUTED%%; padding: 10px 10px 4px;">%s</div>\n' % t

def menu(t):
    body = stage_open() + finder() + CURSOR + (
        '<div role="dialog" aria-label="Конвертировать в…" style="position: absolute; left: 430px; top: 112px; width: 344px; ' + WINDOW + ' overflow: hidden;">\n'
        # header
        '<div style="display: flex; align-items: center; gap: 12px; padding: 14px 16px 12px;">' + ICON_FILE +
        '<div style="display: flex; flex-direction: column; gap: 2px; min-width: 0;">'
        '<div style="font-size: 13.5px; font-weight: 600;">IMG_2048.HEIC</div>'
        '<div style="font-size: 12px; color: %MUTED%;">Фото HEIC · 3,4 МБ · 4032 × 3024</div></div></div>\n'
        # search
        '<div style="padding: 0 12px 6px;"><label style="display: flex; align-items: center; gap: 8px; height: 34px; padding: 0 10px; border-radius: %BTN_RADIUS%; background: %INPUT_BG%; border: %INPUT_BORDER%; color: %MUTED%;">'
        + ICON_SEARCH + '<input aria-label="Найти формат" placeholder="Конвертировать в… начните печатать" value="{{q}}" onChange="{{onInput}}" onKeyDown="{{onKey}}" style="flex: 1; border: 0; outline: none; background: transparent; font: inherit; font-size: 13px; color: %TEXT%;">'
        '</label></div>\n'
        '<div style="padding: 0 6px 6px; height: 268px; overflow: auto;">\n'
        '<sc-if value="{{notSearching}}" hint-placeholder-val="{{ true }}">' + label("ИЗБРАННОЕ") + row_loop("fav") + label("ПОПУЛЯРНЫЕ") + row_loop("pop") +
        '<sc-if value="{{showMoreToggle}}" hint-placeholder-val="{{ true }}"><button type="button" onClick="{{openMore}}" style="display: flex; align-items: center; gap: 8px; width: 100%; height: 34px; padding: 0 10px; border: 0; background: transparent; color: %MUTED%; font-size: 13px; cursor: pointer;">Ещё 4 формата' + ICON_CHEV + '</button></sc-if>'
        '<sc-if value="{{moreOpen}}" hint-placeholder-val="{{ false }}">' + label("ЕЩЁ") + row_loop("more") + '</sc-if>'
        '</sc-if>\n'
        '<sc-if value="{{searching}}" hint-placeholder-val="{{ false }}">' + label("НАЙДЕНО") + row_loop("found") + '</sc-if>\n'
        '<sc-if value="{{empty}}" hint-placeholder-val="{{ false }}"><div style="padding: 18px 10px; font-size: 13px; color: %MUTED%;">Такого формата нет для фото. Попробуйте «jpg» или «pdf».</div></sc-if>\n'
        '</div>\n'
        # options
        '<sc-if value="{{hasCur}}" hint-placeholder-val="{{ true }}"><div style="border-top: 1px solid %HAIR%; padding: 10px 16px; display: flex; flex-direction: column; gap: 8px;">'
        '<div style="display: flex; align-items: center; justify-content: space-between; font-size: 12.5px;"><span style="color: %MUTED%;">Качество</span>'
        '<span style="display: flex; align-items: center; gap: 10px;"><span style="width: 120px; height: 4px; border-radius: 2px; background: %BAR_BG%; position: relative;"><span style="position: absolute; left: 0; top: 0; bottom: 0; width: 85%; border-radius: 2px; background: %ACCENT%;"></span></span>'
        '<span style="font-family: \'JetBrains Mono\', monospace; font-size: 12px; width: 22px; text-align: right;">85</span></span></div>'
        '<div style="display: flex; align-items: center; justify-content: space-between; font-size: 12.5px;"><span style="color: %MUTED%;">Размер</span><span>Как у исходника</span></div>'
        '<div style="display: flex; align-items: center; justify-content: space-between; font-size: 12.5px;"><span style="color: %MUTED%;">Убрать метаданные (EXIF, GPS)</span>'
        '<span style="width: 30px; height: 18px; border-radius: 9px; background: %ACCENT%; position: relative;"><span style="position: absolute; right: 2px; top: 2px; width: 14px; height: 14px; border-radius: 7px; background: #FFFFFF;"></span></span></div>'
        '</div></sc-if>\n'
        # footer
        '<div style="border-top: 1px solid %HAIR%; padding: 10px 12px 10px 16px; display: flex; align-items: center; justify-content: space-between; gap: 10px;">'
        '<sc-if value="{{notDone}}" hint-placeholder-val="{{ true }}"><span style="font-size: 11.5px; color: %FAINT%;">↑↓ выбор · Tab параметры · Esc</span>'
        '<button type="button" onClick="{{convert}}" style="height: 32px; padding: 0 14px; border: 0; border-radius: %BTN_RADIUS%; background: %ACCENT%; color: %ON_ACCENT%; font-size: 13px; font-weight: 600; cursor: pointer;">В {{curExt}} ↵</button></sc-if>'
        '<sc-if value="{{done}}" hint-placeholder-val="{{ false }}"><span style="display: flex; align-items: center; gap: 6px; font-size: 12.5px; color: %OK%;">' + ICON_CHECK + 'IMG_2048.{{curExt}} сохранён рядом</span>'
        '<a href="#" style="font-size: 12.5px;">Показать в папке</a></sc-if>'
        '</div>\n'
        '</div>\n</div>\n')
    tokens = json.dumps({k: t[k] for k in ("row_radius", "sel_bg", "sel_shadow", "sel_text", "text", "accent", "on_accent", "ext_bg", "ext_text")}, ensure_ascii=False)
    return sub(HEAD, t, {"TITLE": "Меню формата · " + t["name"]}) + sub(body, t) + sub(TAIL, t, {"W": W, "H": H, "JS": MENU_JS.replace("%TOKENS%", tokens)})

# ---------- Экран 2: прогресс ----------
PROG_JS = r"""
class Component extends DCLogic {
  constructor(p) { super(p); this.state = { cancelled: false }; }
  renderVals() {
    return {
      running: !this.state.cancelled,
      cancelled: this.state.cancelled,
      cancel: () => this.setState({ cancelled: true }),
      undo: () => this.setState({ cancelled: false })
    };
  }
}
"""

def ext_chip(e):
    return '<span style="font-family: \'JetBrains Mono\', monospace; font-size: 10.5px; font-weight: 600; padding: 2px 6px; border-radius: 5px; background: %EXT_BG%; color: %EXT_TEXT%;">' + e + '</span>'

def job_head(name, src, dst):
    return ('<div style="display: flex; align-items: center; gap: 8px; min-width: 0;">'
            '<span style="font-size: 13px; font-weight: 600; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; flex: 1;">' + name + '</span>'
            + ext_chip(src) + '<span aria-hidden="true" style="color: %FAINT%; font-size: 12px;">→</span>' + ext_chip(dst) + '</div>')

def bar(pct, color="%ACCENT%"):
    return ('<div style="height: %BAR_H%; border-radius: 3px; background: %BAR_BG%; overflow: hidden;" role="progressbar" aria-valuenow="' + str(pct) + '" aria-valuemin="0" aria-valuemax="100">'
            '<div style="width: ' + str(pct) + '%; height: 100%; border-radius: 3px; background: ' + color + ';"></div></div>')

def icon_btn(icon, label, extra=""):
    return ('<button type="button" aria-label="' + label + '" ' + extra + ' style="width: 28px; height: 28px; border: 0; border-radius: %BTN_RADIUS%; background: %INPUT_BG%; color: %MUTED%; display: flex; align-items: center; justify-content: center; cursor: pointer; flex: none;">' + icon + '</button>')

def progress(t):
    sep = '<div style="height: 1px; background: %HAIR%; margin: 0 16px;"></div>'
    job1 = ('<div style="padding: 12px 16px; display: flex; gap: 12px; align-items: center;"><div style="flex: 1; display: flex; flex-direction: column; gap: 8px; min-width: 0;">'
            + job_head("Отпуск_2026.mov", "MOV", "MP4") +
            '<sc-if value="{{running}}" hint-placeholder-val="{{ true }}">' + bar(62) +
            '<div style="display: flex; justify-content: space-between; font-size: 12px; color: %MUTED%;"><span>62% · осталось ~1 мин 40 с</span><span>1,8 ГБ → ~410 МБ</span></div></sc-if>'
            '<sc-if value="{{cancelled}}" hint-placeholder-val="{{ false }}"><div style="display: flex; justify-content: space-between; font-size: 12px; color: %MUTED%;"><span>Отменено, временные файлы удалены</span><button type="button" onClick="{{undo}}" style="border: 0; background: transparent; color: %ACCENT%; font-size: 12px; cursor: pointer; padding: 0;">Повторить</button></div></sc-if>'
            '</div><sc-if value="{{running}}" hint-placeholder-val="{{ true }}">' + icon_btn(ICON_X, "Отменить конвертацию", 'onClick="{{cancel}}"') + '</sc-if></div>')
    job2 = ('<div style="padding: 12px 16px; display: flex; flex-direction: column; gap: 6px;">' + job_head("Отчёт за квартал.docx", "DOCX", "PDF") +
            '<div style="font-size: 12px; color: %MUTED%;">В очереди · ждёт LibreOffice</div></div>')
    job3 = ('<div style="padding: 12px 16px; display: flex; flex-direction: column; gap: 6px;">' + job_head("IMG_2048.HEIC", "HEIC", "JPG") +
            '<div style="display: flex; justify-content: space-between; align-items: center; font-size: 12px;"><span style="display: flex; align-items: center; gap: 6px; color: %OK%;">' + ICON_CHECK + 'Готово · 3,4 МБ → 1,1 МБ</span><a href="#">Показать в папке</a></div></div>')
    job4 = ('<div style="padding: 12px 16px; display: flex; flex-direction: column; gap: 6px;">' + job_head("scan_old.pdf", "PDF", "PNG") +
            '<div style="display: flex; justify-content: space-between; align-items: center; font-size: 12px;"><span style="display: flex; align-items: center; gap: 6px; color: %ERR%;">' + ICON_WARN + 'Не удалось открыть файл: он повреждён</span><a href="#">Подробнее</a></div></div>')
    panel = ('<div role="region" aria-label="Задачи конвертации" style="position: absolute; right: 28px; bottom: 28px; width: 392px; ' + WINDOW + ' overflow: hidden;">'
             '<div style="display: flex; align-items: center; justify-content: space-between; padding: 14px 16px 10px;">'
             '<div style="display: flex; flex-direction: column; gap: 2px;"><span style="font-size: 14px; font-weight: 600;">Конвертация</span><span style="font-size: 12px; color: %MUTED%;">1 из 4 готово · общий прогресс 41%</span></div>'
             + icon_btn('<svg aria-hidden="true" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M5 12h14"></path></svg>', "Свернуть панель") + '</div>'
             '<div style="padding: 0 16px 6px;">' + bar(41) + '</div>'
             + job1 + sep + job2 + sep + job3 + sep + job4 +
             '<div style="border-top: 1px solid %HAIR%; padding: 10px 16px; display: flex; justify-content: space-between; font-size: 12.5px;">'
             '<button type="button" style="border: 0; background: transparent; color: %ERR%; cursor: pointer; padding: 0; font-size: 12.5px;">Отменить всё</button>'
             '<button type="button" style="border: 0; background: transparent; color: %MUTED%; cursor: pointer; padding: 0; font-size: 12.5px;">Очистить завершённые</button></div></div>\n')
    toast = ('<div role="status" style="position: absolute; right: 28px; top: 28px; width: 340px; ' + WINDOW + ' padding: 12px 14px; display: flex; gap: 12px; align-items: center;">'
             '<div aria-hidden="true" style="width: 34px; height: 34px; border-radius: 9px; background: %ACCENT%; color: %ON_ACCENT%; display: flex; align-items: center; justify-content: center; font-weight: 700; font-size: 15px;">M</div>'
             '<div style="display: flex; flex-direction: column; gap: 2px; flex: 1;"><span style="font-size: 13px; font-weight: 600;">Готово: IMG_2048.jpg</span><span style="font-size: 12px; color: %MUTED%;">Сохранено в «Загрузки» · нажмите, чтобы показать</span></div></div>\n')
    caption = ('<div style="position: absolute; left: 32px; top: 32px; max-width: 360px; color: #FFFFFF; font-size: 13px; line-height: 1.5; text-shadow: 0 1px 2px rgba(0,0,0,0.45);">'
               'Панель прогресса всплывает в углу экрана, когда задача длится дольше 1,5 с. Справа сверху — системное уведомление по завершении.</div>\n')
    body = stage_open() + caption + toast + panel + '</div>\n'
    return sub(HEAD, t, {"TITLE": "Прогресс · " + t["name"]}) + sub(body, t) + sub(TAIL, t, {"W": W, "H": H, "JS": PROG_JS})

# ---------- Экран 3: настройки ----------
SET_JS = r"""
class Component extends DCLogic {
  constructor(p) {
    super(p);
    this.state = { tab: 'general', tg: { autostart: true, notify: true, reduce: false, followSys: true, meta: true, bom: true, motion: true },
      seg: { save: 'near', conflict: 'suffix', theme: 'system', hk: 'A' }, opacity: 60, blur: 30 };
  }
  renderVals() {
    const T = %TOKENS%;
    const s = this.state;
    const tabs = [['general', 'Основные'], ['hotkey', 'Горячая клавиша'], ['quality', 'Качество'], ['formats', 'Форматы'], ['look', 'Внешний вид'], ['engines', 'Компоненты'], ['history', 'История']];
    const tg = {};
    Object.keys(s.tg).forEach(k => {
      const on = s.tg[k];
      tg[k] = {
        pressed: on ? 'true' : 'false',
        track: 'flex: none; width: 36px; height: 22px; border-radius: 11px; border: 0; padding: 0; position: relative; cursor: pointer; background: ' + (on ? T.accent : T.track_off) + ';',
        knob: 'position: absolute; top: 3px; left: ' + (on ? '17px' : '3px') + '; width: 16px; height: 16px; border-radius: 8px; background: #FFFFFF; box-shadow: 0 1px 2px rgba(0,0,0,0.25);',
        flip: () => this.setState({ tg: Object.assign({}, s.tg, { [k]: !on }) })
      };
    });
    const seg = {};
    const segDef = { save: ['near', 'pick'], conflict: ['suffix', 'over', 'ask'], theme: ['light', 'dark', 'system'], hk: ['A', 'B', 'C'] };
    Object.keys(segDef).forEach(g => {
      seg[g] = {};
      segDef[g].forEach(v => {
        const on = s.seg[g] === v;
        seg[g][v] = {
          pressed: on ? 'true' : 'false',
          style: 'flex: 1; height: 30px; padding: 0 12px; border: 0; cursor: pointer; font-size: 12.5px; border-radius: ' + T.seg_radius + '; background: ' + (on ? T.sel_bg : 'transparent') + '; box-shadow: ' + (on ? T.seg_shadow : 'none') + '; color: ' + (on ? T.text : T.muted) + '; font-weight: ' + (on ? '600' : '500') + ';',
          card: 'display: flex; align-items: center; gap: 14px; width: 100%; padding: 12px 14px; cursor: pointer; text-align: left; border-radius: ' + T.row_radius + '; background: ' + (on ? T.sel_bg : 'transparent') + '; border: ' + (on ? '1.5px solid ' + T.accent : '1px solid ' + T.hair) + '; color: ' + T.text + ';',
          pick: () => this.setState({ seg: Object.assign({}, s.seg, { [g]: v }) })
        };
      });
    });
    const nav = tabs.map(([id, title]) => ({
      title,
      current: s.tab === id ? 'page' : 'false',
      style: 'display: block; width: 100%; text-align: left; height: 32px; padding: 0 10px; border: 0; cursor: pointer; font-size: 13px; border-radius: ' + T.row_radius + '; background: ' + (s.tab === id ? T.sel_bg : 'transparent') + '; box-shadow: ' + (s.tab === id ? T.sel_shadow : 'none') + '; color: ' + (s.tab === id ? T.sel_text : T.text) + '; font-weight: ' + (s.tab === id ? '600' : '500') + ';',
      go: () => this.setState({ tab: id })
    }));
    const is = {}; tabs.forEach(([id]) => { is[id] = s.tab === id; });
    return {
      nav, tg, seg, is,
      opacity: s.opacity, blur: s.blur,
      setOpacity: (e) => this.setState({ opacity: Number(e.target.value) }),
      setBlur: (e) => this.setState({ blur: Number(e.target.value) })
    };
  }
}
"""

def toggle(k, label, hint=""):
    h = ('<span style="font-size: 12px; color: %MUTED%;">' + hint + '</span>') if hint else ""
    return ('<div style="display: flex; align-items: center; justify-content: space-between; gap: 16px; padding: 10px 0; border-bottom: 1px solid %HAIR%;">'
            '<div style="display: flex; flex-direction: column; gap: 2px;"><span id="lbl-' + k + '" style="font-size: 13px;">' + label + '</span>' + h + '</div>'
            '<button type="button" aria-labelledby="lbl-' + k + '" aria-pressed="{{tg.' + k + '.pressed}}" onClick="{{tg.' + k + '.flip}}" style="{{tg.' + k + '.track}}"><span style="{{tg.' + k + '.knob}}"></span></button></div>')

def segrow(g, label, opts):
    btns = "".join('<button type="button" aria-pressed="{{seg.%s.%s.pressed}}" onClick="{{seg.%s.%s.pick}}" style="{{seg.%s.%s.style}}">%s</button>' % (g, v, g, v, g, v, t) for v, t in opts)
    return ('<div style="display: flex; flex-direction: column; gap: 8px; padding: 12px 0; border-bottom: 1px solid %HAIR%;">'
            '<span style="font-size: 13px;">' + label + '</span>'
            '<div role="group" aria-label="' + label + '" style="display: flex; gap: 2px; padding: 2px; border-radius: %SEG_OUTER%; background: %INPUT_BG%; border: %INPUT_BORDER%;">' + btns + '</div></div>')

def kbd(k):
    return '<span style="font-family: \'JetBrains Mono\', monospace; font-size: 12px; font-weight: 600; min-width: 22px; height: 24px; padding: 0 6px; box-sizing: border-box; display: inline-flex; align-items: center; justify-content: center; border-radius: 6px; background: %EXT_BG%; border: %CARD_BORDER%; box-shadow: 0 1px 0 %HAIR%;">' + k + '</span>'

def hk_card(v, keys_mac, keys_win, title, why):
    return ('<button type="button" aria-pressed="{{seg.hk.' + v + '.pressed}}" onClick="{{seg.hk.' + v + '.pick}}" style="{{seg.hk.' + v + '.card}}">'
            '<div style="display: flex; gap: 4px; width: 120px; flex: none;">' + "".join(kbd(k) for k in keys_mac) + '</div>'
            '<div style="display: flex; flex-direction: column; gap: 3px;"><span style="font-size: 13px; font-weight: 600;">' + title + '</span>'
            '<span style="font-size: 12px; color: %MUTED%; line-height: 1.4;">' + why + '</span>'
            '<span style="font-size: 11.5px; color: %FAINT%;">Windows: ' + keys_win + '</span></div></button>')

def section(title, inner):
    return '<div style="display: flex; flex-direction: column;"><h2 style="margin: 0 0 6px; font-size: 18px; font-weight: 600;">' + title + '</h2>' + inner + '</div>'

def slider(label, val, minv, maxv, handler, unit):
    return ('<label style="display: flex; flex-direction: column; gap: 6px; padding: 12px 0; border-bottom: 1px solid %HAIR%;">'
            '<span style="display: flex; justify-content: space-between; font-size: 13px;"><span>' + label + '</span><span style="font-family: \'JetBrains Mono\', monospace; font-size: 12px; color: %MUTED%;">{{' + val + '}}' + unit + '</span></span>'
            '<input type="range" min="' + str(minv) + '" max="' + str(maxv) + '" value="{{' + val + '}}" onChange="{{' + handler + '}}" style="width: 100%; accent-color: %ACCENT%;"></label>')

def settings(t):
    glass = t["key"] == "glass"
    general = section("Основные",
        toggle("autostart", "Запускать при входе в систему", "Morph живёт в строке меню и почти не тратит ресурсы")
        + segrow("save", "Куда сохранять", [("near", "Рядом с исходником"), ("pick", "В папку…")])
        + segrow("conflict", "Если файл с таким именем уже есть", [("suffix", "Добавить « (1)»"), ("over", "Перезаписать"), ("ask", "Спросить")])
        + toggle("notify", "Уведомлять о завершении", "Только для задач дольше 10 секунд")
        + '<div style="display: flex; justify-content: space-between; align-items: center; padding: 12px 0;"><label for="lang-' + t["key"] + '" style="font-size: 13px;">Язык интерфейса</label>'
          '<select id="lang-' + t["key"] + '" style="font: inherit; font-size: 13px; height: 30px; padding: 0 8px; border-radius: %BTN_RADIUS%; border: %INPUT_BORDER%; background: %INPUT_BG%; color: %TEXT%;"><option>Русский</option><option>English</option></select></div>')
    hotkey = section("Горячая клавиша",
        '<p style="margin: 0 0 12px; font-size: 12.5px; color: %MUTED%; line-height: 1.5;">Выделите файлы в Finder и нажмите сочетание — меню появится у курсора. Все варианты нажимаются левой рукой.</p>'
        '<div style="display: flex; flex-direction: column; gap: 8px;">'
        + hk_card("A", ["⌃", "⌥", "⌘", "X"], "Win + Shift + X", "Вариант A · рекомендуем", "Тройной модификатор почти никто не занимает: ни Photoshop, ни браузеры, ни IDE, ни Office.")
        + hk_card("B", ["⌃", "⌘", "X"], "Ctrl + Win + X", "Вариант B · удобнее", "Две клавиши-модификатора. Небольшой риск совпасть с редкой утилитой.")
        + hk_card("C", ["Только", "Finder"], "—", "Вариант C · через Службы macOS", "Работает только в Finder, конфликтов нет вовсе. Сочетание задаётся в системных настройках.")
        + '</div><div style="display: flex; gap: 10px; align-items: center; margin-top: 14px;"><button type="button" style="height: 32px; padding: 0 14px; border-radius: %BTN_RADIUS%; border: %CARD_BORDER%; background: %CARD_BG%; color: %TEXT%; font-size: 13px; cursor: pointer;">Записать своё сочетание…</button>'
        '<span style="font-size: 12px; color: %OK%; display: flex; gap: 6px; align-items: center;">' + ICON_CHECK + 'Сочетание свободно</span></div>')
    def qrow(k, v):
        return '<div style="display: flex; justify-content: space-between; padding: 11px 0; border-bottom: 1px solid %HAIR%; font-size: 13px;"><span>' + k + '</span><span style="color: %MUTED%;">' + v + '</span></div>'
    quality = section("Качество по умолчанию",
        qrow("Фото: JPG / WEBP / AVIF", "85 / 82 / 60") + qrow("Видео", "Баланс · H.264 CRF 23") + qrow("Аудио MP3 / AAC / OPUS", "192 / 192 / 128 кбит/с")
        + toggle("meta", "Удалять метаданные фото", "EXIF, геопозиция, модель камеры") + toggle("bom", "CSV для Excel (UTF-8 с BOM)", "Кириллица откроется в Excel без «кракозябр»"))
    chips = "".join('<span style="display: inline-flex; align-items: center; gap: 6px; height: 28px; padding: 0 10px; border-radius: %BTN_RADIUS%; background: %SEL_BG%; border: %CARD_BORDER%; font-family: \'JetBrains Mono\', monospace; font-size: 12px; font-weight: 600;">' + e + '<span aria-hidden="true" style="color: %ACCENT%;">★</span></span>' for e in ["JPG", "PNG", "PDF", "MP4", "MP3", "DOCX", "XLSX"])
    formats = section("Избранные форматы",
        '<p style="margin: 0 0 12px; font-size: 12.5px; color: %MUTED%; line-height: 1.5;">Избранное всегда первым в меню. Добавить: звёздочка у формата в меню или ⌘D на выделенной строке.</p>'
        '<div style="display: flex; flex-wrap: wrap; gap: 8px;">' + chips + '</div>')
    if glass:
        look = section("Внешний вид",
            segrow("theme", "Тема", [("light", "Светлая"), ("dark", "Тёмная"), ("system", "Как в системе")])
            + slider("Прозрачность стекла", "opacity", 20, 90, "setOpacity", "%")
            + slider("Размытие фона", "blur", 0, 60, "setBlur", " px")
            + toggle("reduce", "Уменьшить прозрачность", "Плотные непрозрачные панели. Лучше для читаемости и слабых ПК")
            + toggle("followSys", "Учитывать настройки доступности системы", "«Уменьшить прозрачность», «Увеличить контраст», «Уменьшить движение»"))
    else:
        sw = "".join('<span aria-hidden="true" style="width: 22px; height: 22px; border-radius: 11px; background: ' + c + ';' + (' box-shadow: 0 0 0 2px #FFFFFF, 0 0 0 4px ' + c + ';' if i == 0 else '') + '"></span>' for i, c in enumerate(["#2B4FE0", "#0F7B6C", "#C2410C", "#7C3AED", "#141416"]))
        look = section("Внешний вид",
            segrow("theme", "Тема", [("light", "Светлая"), ("dark", "Тёмная"), ("system", "Как в системе")])
            + '<div style="display: flex; justify-content: space-between; align-items: center; padding: 12px 0; border-bottom: 1px solid %HAIR%;"><span style="font-size: 13px;">Акцентный цвет</span><div style="display: flex; gap: 10px;">' + sw + '</div></div>'
            + toggle("motion", "Анимации", "Короткие, 120–180 мс. Отключаются при «Уменьшить движение»"))
    def eng(name, what, status, ok, action=""):
        col = "%OK%" if ok else "%MUTED%"
        act = ('<button type="button" style="height: 28px; padding: 0 12px; border-radius: %BTN_RADIUS%; border: 0; background: %ACCENT%; color: %ON_ACCENT%; font-size: 12.5px; font-weight: 600; cursor: pointer;">' + action + '</button>') if action else ""
        return ('<div style="display: flex; align-items: center; gap: 12px; padding: 10px 0; border-bottom: 1px solid %HAIR%;">'
                '<div style="flex: 1; display: flex; flex-direction: column; gap: 2px;"><span style="font-size: 13px; font-weight: 600;">' + name + '</span><span style="font-size: 12px; color: %MUTED%;">' + what + '</span></div>'
                '<span style="font-size: 12px; color: ' + col + ';">' + status + '</span>' + act + '</div>')
    engines = section("Компоненты",
        eng("FFmpeg 7.1", "Видео, аудио, GIF", "Встроен", True) + eng("ImageMagick 7.1", "Фото, HEIC, RAW, SVG, ICO", "Встроен", True)
        + eng("LibreOffice", "Word, Excel, PowerPoint → PDF и обратно", "Не установлен · 350 МБ", False, "Установить")
        + eng("Pandoc 3.6", "Markdown, HTML, EPUB, FB2", "Загружен", True)
        + eng("Calibre", "MOBI, AZW3 (необязательно)", "Не найден", False, "Подробнее"))
    def hist(n, a, b, when):
        return ('<div style="display: flex; align-items: center; gap: 10px; padding: 10px 0; border-bottom: 1px solid %HAIR%;">'
                '<div style="flex: 1; display: flex; flex-direction: column; gap: 3px; min-width: 0;"><span style="font-size: 13px;">' + n + '</span><span style="display: flex; gap: 6px; align-items: center; font-size: 12px; color: %MUTED%;">' + ext_chip(a) + '→' + ext_chip(b) + ' · ' + when + '</span></div>'
                '<a href="#" style="font-size: 12.5px;">Показать в папке</a></div>')
    history = section("История",
        hist("IMG_2048.jpg", "HEIC", "JPG", "сегодня, 17:02") + hist("Отпуск_2026.mp4", "MOV", "MP4", "сегодня, 16:48")
        + hist("Бюджет 2026 (1).xlsx", "CSV", "XLSX", "вчера") + hist("Лекция 3.pdf", "PPTX", "PDF", "вчера")
        + '<div style="padding-top: 12px;"><button type="button" style="border: 0; background: transparent; color: %MUTED%; font-size: 12.5px; cursor: pointer; padding: 0;">Очистить историю</button></div>')
    panes = "".join('<sc-if value="{{is.%s}}" hint-placeholder-val="{{ %s }}">%s</sc-if>' % (k, "true" if k == "general" else "false", v)
                    for k, v in [("general", general), ("hotkey", hotkey), ("quality", quality), ("formats", formats), ("look", look), ("engines", engines), ("history", history)])
    win = ('<div role="dialog" aria-label="Настройки Morph" style="position: absolute; left: 50px; top: 40px; width: 860px; height: 580px; ' + WINDOW + ' display: flex; overflow: hidden;">'
           '<nav aria-label="Разделы настроек" style="width: 210px; flex: none; background: %SIDE_BG%; border-right: 1px solid %HAIR%; padding: 18px 10px; box-sizing: border-box; display: flex; flex-direction: column; gap: 2px;">'
           '<div style="display: flex; gap: 7px; padding: 0 6px 18px;"><span style="width: 12px; height: 12px; border-radius: 6px; background: #FF5F57;"></span><span style="width: 12px; height: 12px; border-radius: 6px; background: #FEBC2E;"></span><span style="width: 12px; height: 12px; border-radius: 6px; background: #28C840;"></span></div>'
           '<sc-for list="{{nav}}" as="n" hint-placeholder-count="7"><button type="button" aria-current="{{n.current}}" onClick="{{n.go}}" style="{{n.style}}">{{n.title}}</button></sc-for>'
           '<div style="margin-top: auto; padding: 0 10px; font-size: 11.5px; color: %FAINT%;">Morph 1.0 · всё локально</div></nav>'
           '<main style="flex: 1; padding: 26px 32px; overflow: auto; box-sizing: border-box;">' + panes + '</main></div>\n')
    body = stage_open() + win + '</div>\n'
    extra = {"SEG_OUTER": "10px" if glass else "8px"}
    tk = {k: t[k] for k in ("row_radius", "sel_bg", "sel_shadow", "sel_text", "text", "muted", "accent", "track_off", "hair")}
    tk["seg_radius"] = "999px" if glass else "6px"
    tk["seg_shadow"] = t["sel_shadow"] if glass else "0 1px 2px rgba(0,0,0,0.10)"
    if not glass:
        tk["sel_bg"] = "#FFFFFF"  # сегменты: белая плашка на сером
    js = SET_JS.replace("%TOKENS%", json.dumps(tk, ensure_ascii=False))
    nav_fix = {}
    out = sub(HEAD, t, {"TITLE": "Настройки · " + t["name"]}) + sub(body, t, extra) + sub(TAIL, t, {"W": W, "H": H, "JS": js})
    if not glass:
        # навигация в минимализме — выделение акцентным фоном, а не белым
        out = out.replace('"sel_bg": "#FFFFFF"', '"sel_bg": "#FFFFFF", "nav_bg": "#EDF0FE"')
        out = out.replace("(s.tab === id ? T.sel_bg : 'transparent')", "(s.tab === id ? (T.nav_bg || T.sel_bg) : 'transparent')")
    return out

def main():
    os.makedirs(os.path.join(ROOT, "project"), exist_ok=True)
    files = {}
    rows = [(MIN, 0), (GLASS, 1)]
    boards, order, notes = {}, [], {}
    for t, r in rows:
        y = r * (H + 120 + 300)
        for c, (fn, title, maker) in enumerate([("Menu", "Меню формата", menu), ("Progress", "Прогресс", progress), ("Settings", "Настройки", settings)]):
            name = ("Main.dc.html" if (r == 0 and c == 0) else "%s-%s.dc.html" % (t["key"], fn))
            files[name] = maker(t)
            boards[name] = {"x": c * (W + 80), "y": y, "w": W, "h": H, "title": "%s — %s" % (t["name"], title), "is_interactive": True}
            order.append(name)
        notes["row%d" % r] = {"x": 0, "y": y - 260, "text": ("Концепт 1 · Минимализм" if r == 0 else "Концепт 2 · Liquid Glass"), "kind": "title1", "maxW": 3 * W + 160}
    canvas = {"v": 3, "createdOnFiles": {"v": 1, "at": datetime.datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")},
              "title": "Morph — концепты интерфейса", "launch": {"view": "canvas"}, "pages": [], "boards": boards,
              "order": order, "notes": notes, "designSystems": []}
    for n, s in files.items():
        with open(os.path.join(ROOT, "project", n), "w", encoding="utf-8") as f:
            f.write(s)
    with open(os.path.join(ROOT, "project", "canvas.json"), "w", encoding="utf-8") as f:
        json.dump(canvas, f, ensure_ascii=False, indent=1)
    print(order)

main()
